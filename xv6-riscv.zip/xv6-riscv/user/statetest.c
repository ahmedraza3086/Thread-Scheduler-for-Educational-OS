#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void
delay(int n)
{
  for(volatile int i = 0; i < n; i++);
}

int
main(int argc, char *argv[])
{
  int pid, status;
  int pipefd[2];
  int choice = 1;
  
  if (argc > 1) {
    if (atoi(argv[1]) > 3 || atoi(argv[1]) < 0) {
      printf("\nError! Invalid test number: defaulting to 1...\n");
    } else {
      choice = atoi(argv[1]);
    }
  }

  if (choice == 1) {
    printf("Test 1: Create process\n");
    printf("Before fork:\n");
    ps();
    
    pid = fork();
    if(pid == 0) {
      // Child: now RUNNING
      printf("Child %d -> RUNNING\n", getpid());
      ps();  // Show child is RUNNING
      exit(0);
    }
    
    // Parent waits for child to become ZOMBIE
    delay(500000);
    
    printf("After child exit\n");
    ps();
    
    // Reap the zombie
    wait(&status);
    printf("After wait\n");
    ps();
    printf("\n");
  } else if (choice == 2) {
    printf("\nTest 2: Block on pipe\n");
    
    pipe(pipefd);
    
    pid = fork();
    if(pid == 0) {
      // Child: block on read
      char buf[10];
      printf("Child %d -> SLEEP\n", getpid());
      read(pipefd[0], buf, sizeof(buf));  // BLOCKS HERE
      printf("Child %d -> WOKE UP, got '%s'\n", getpid(), buf);
      close(pipefd[0]);
      exit(0);
    }
    
    // Let child block
    delay(500000);
    
    printf("Child -> SLEEP\n");
    ps();
    
    printf("Writing to pipe to wake child...\n");
    write(pipefd[1], "Wake up message", 2);
    
    delay(500000);
    
    wait(&status);
    printf("Child done:\n");
    ps();
    printf("\n");
    
    close(pipefd[0]);
    close(pipefd[1]);
  } else {  
    printf("Test 3: Preemption\n");
    printf("Creating 2 CPU-heavy processes\n");
    
    for(int i = 0; i < 2; i++) {
      pid = fork();
      if(pid == 0) {
        for(int j = 0; j < 20; j++) {
          printf("%d", getpid() % 10);
          delay(5000000);
          if (j % 10 == 0) {
            ps();
          }
        }
        printf("\nProcess %d done\n", getpid());
        exit(0);
      }
    }
    
    printf("During execution (states should alternate RUNNING/RUNNABLE):\n");
  }
  // Wait for all children
  for(int i = 0; i < 2; i++)
    wait(&status);
  

  printf("\nAfter all done:\n");
  ps();
  
  printf("\n");
  exit(0);
}