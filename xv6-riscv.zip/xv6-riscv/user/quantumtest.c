#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[]) {
  int pid;
  int p_time = 50;
  int c_time = 50;

  if(argc > 1) {
    int q = atoi(argv[1]);
    if(setquantum(q) < 0) {
      printf("Failed to set quantum\n");
      exit(1);
    }
    printf("Quantum set to %d ticks\n", q);
  }

  if (argc > 2) {
    if (atoi(argv[2]) <= 0) {
      printf("Burst Time invalid!\n");
    } else {
      p_time = atoi(argv[2]);
      printf("Parent Burst Time set to %d ticks\n", p_time);
    }
  }

  if (argc > 3) {
    if (atoi(argv[3]) <= 0) {
      printf("Burst Time invalid!\n");
    } else {
      c_time = atoi(argv[3]);
      printf("Child Burst Time set to %d ticks\n", c_time);
    }
  }

  printf("\n");

  // Fork to create multiple processes
  pid = fork();
  if(pid == 0) {
    // Child process
    for(int i = 0; i < c_time; i++) {
      printf("C");
      // Busy loop to consume CPU
      for(int j = 0; j < 100000000; j++);
    }
    exit(0);
  } else {
    // Parent process
    for(int i = 0; i < p_time; i++) {
      printf("P");
      for(int j = 0; j < 100000000; j++);
    }
    wait(0);
    printf("\n");
    exit(0);
  }
}
