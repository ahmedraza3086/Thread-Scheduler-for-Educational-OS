user/quantumtest.o: user/quantumtest.c kernel/types.h kernel/stat.h \
 user/user.h
