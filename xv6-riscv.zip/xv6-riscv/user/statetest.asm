
user/_statetest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <delay>:
#include "kernel/stat.h"
#include "user/user.h"

void
delay(int n)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec22                	sd	s0,24(sp)
   4:	1000                	addi	s0,sp,32
  for(volatile int i = 0; i < n; i++);
   6:	fe042623          	sw	zero,-20(s0)
   a:	fec42783          	lw	a5,-20(s0)
   e:	872a                	mv	a4,a0
  10:	00a7dc63          	bge	a5,a0,28 <delay+0x28>
  14:	fec42783          	lw	a5,-20(s0)
  18:	2785                	addiw	a5,a5,1
  1a:	fef42623          	sw	a5,-20(s0)
  1e:	fec42783          	lw	a5,-20(s0)
  22:	2781                	sext.w	a5,a5
  24:	fee7c8e3          	blt	a5,a4,14 <delay+0x14>
}
  28:	6462                	ld	s0,24(sp)
  2a:	6105                	addi	sp,sp,32
  2c:	8082                	ret

000000000000002e <main>:

int
main(int argc, char *argv[])
{
  2e:	711d                	addi	sp,sp,-96
  30:	ec86                	sd	ra,88(sp)
  32:	e8a2                	sd	s0,80(sp)
  34:	e4a6                	sd	s1,72(sp)
  36:	1080                	addi	s0,sp,96
  int pid, status;
  int pipefd[2];
  int choice = 1;
  
  if (argc > 1) {
  38:	4785                	li	a5,1
  3a:	02a7d463          	bge	a5,a0,62 <main+0x34>
  3e:	84ae                	mv	s1,a1
    if (atoi(argv[1]) > 3 || atoi(argv[1]) < 0) {
  40:	6588                	ld	a0,8(a1)
  42:	3da000ef          	jal	41c <atoi>
  46:	478d                	li	a5,3
  48:	00a7c763          	blt	a5,a0,56 <main+0x28>
  4c:	6488                	ld	a0,8(s1)
  4e:	3ce000ef          	jal	41c <atoi>
  52:	04055b63          	bgez	a0,a8 <main+0x7a>
      printf("\nError! Invalid test number: defaulting to 1...\n");
  56:	00001517          	auipc	a0,0x1
  5a:	ada50513          	addi	a0,a0,-1318 # b30 <malloc+0x106>
  5e:	119000ef          	jal	976 <printf>
      choice = atoi(argv[1]);
    }
  }

  if (choice == 1) {
    printf("Test 1: Create process\n");
  62:	00001517          	auipc	a0,0x1
  66:	b0650513          	addi	a0,a0,-1274 # b68 <malloc+0x13e>
  6a:	10d000ef          	jal	976 <printf>
    printf("Before fork:\n");
  6e:	00001517          	auipc	a0,0x1
  72:	b1250513          	addi	a0,a0,-1262 # b80 <malloc+0x156>
  76:	101000ef          	jal	976 <printf>
    ps();
  7a:	56c000ef          	jal	5e6 <ps>
    
    pid = fork();
  7e:	4b8000ef          	jal	536 <fork>
    if(pid == 0) {
  82:	e53d                	bnez	a0,f0 <main+0xc2>
  84:	e0ca                	sd	s2,64(sp)
  86:	fc4e                	sd	s3,56(sp)
  88:	f852                	sd	s4,48(sp)
  8a:	f456                	sd	s5,40(sp)
      // Child: now RUNNING
      printf("Child %d -> RUNNING\n", getpid());
  8c:	532000ef          	jal	5be <getpid>
  90:	85aa                	mv	a1,a0
  92:	00001517          	auipc	a0,0x1
  96:	afe50513          	addi	a0,a0,-1282 # b90 <malloc+0x166>
  9a:	0dd000ef          	jal	976 <printf>
      ps();  // Show child is RUNNING
  9e:	548000ef          	jal	5e6 <ps>
      exit(0);
  a2:	4501                	li	a0,0
  a4:	49a000ef          	jal	53e <exit>
      choice = atoi(argv[1]);
  a8:	6488                	ld	a0,8(s1)
  aa:	372000ef          	jal	41c <atoi>
  if (choice == 1) {
  ae:	4785                	li	a5,1
  b0:	faf509e3          	beq	a0,a5,62 <main+0x34>
    // Reap the zombie
    wait(&status);
    printf("After wait\n");
    ps();
    printf("\n");
  } else if (choice == 2) {
  b4:	4789                	li	a5,2
  b6:	0af50a63          	beq	a0,a5,16a <main+0x13c>
    printf("\n");
    
    close(pipefd[0]);
    close(pipefd[1]);
  } else {  
    printf("Test 3: Preemption\n");
  ba:	00001517          	auipc	a0,0x1
  be:	bde50513          	addi	a0,a0,-1058 # c98 <malloc+0x26e>
  c2:	0b5000ef          	jal	976 <printf>
    printf("Creating 2 CPU-heavy processes\n");
  c6:	00001517          	auipc	a0,0x1
  ca:	bea50513          	addi	a0,a0,-1046 # cb0 <malloc+0x286>
  ce:	0a9000ef          	jal	976 <printf>
    
    for(int i = 0; i < 2; i++) {
      pid = fork();
  d2:	464000ef          	jal	536 <fork>
      if(pid == 0) {
  d6:	16050b63          	beqz	a0,24c <main+0x21e>
      pid = fork();
  da:	45c000ef          	jal	536 <fork>
      if(pid == 0) {
  de:	16050763          	beqz	a0,24c <main+0x21e>
        printf("\nProcess %d done\n", getpid());
        exit(0);
      }
    }
    
    printf("During execution (states should alternate RUNNING/RUNNABLE):\n");
  e2:	00001517          	auipc	a0,0x1
  e6:	c0e50513          	addi	a0,a0,-1010 # cf0 <malloc+0x2c6>
  ea:	08d000ef          	jal	976 <printf>
  ee:	a089                	j	130 <main+0x102>
    delay(500000);
  f0:	0007a537          	lui	a0,0x7a
  f4:	12050513          	addi	a0,a0,288 # 7a120 <base+0x78110>
  f8:	f09ff0ef          	jal	0 <delay>
    printf("After child exit\n");
  fc:	00001517          	auipc	a0,0x1
 100:	aac50513          	addi	a0,a0,-1364 # ba8 <malloc+0x17e>
 104:	073000ef          	jal	976 <printf>
    ps();
 108:	4de000ef          	jal	5e6 <ps>
    wait(&status);
 10c:	fbc40513          	addi	a0,s0,-68
 110:	436000ef          	jal	546 <wait>
    printf("After wait\n");
 114:	00001517          	auipc	a0,0x1
 118:	aac50513          	addi	a0,a0,-1364 # bc0 <malloc+0x196>
 11c:	05b000ef          	jal	976 <printf>
    ps();
 120:	4c6000ef          	jal	5e6 <ps>
    printf("\n");
 124:	00001517          	auipc	a0,0x1
 128:	aac50513          	addi	a0,a0,-1364 # bd0 <malloc+0x1a6>
 12c:	04b000ef          	jal	976 <printf>
 130:	e0ca                	sd	s2,64(sp)
 132:	fc4e                	sd	s3,56(sp)
 134:	f852                	sd	s4,48(sp)
 136:	f456                	sd	s5,40(sp)
  }
  // Wait for all children
  for(int i = 0; i < 2; i++)
    wait(&status);
 138:	fbc40513          	addi	a0,s0,-68
 13c:	40a000ef          	jal	546 <wait>
 140:	fbc40513          	addi	a0,s0,-68
 144:	402000ef          	jal	546 <wait>
  

  printf("\nAfter all done:\n");
 148:	00001517          	auipc	a0,0x1
 14c:	b3850513          	addi	a0,a0,-1224 # c80 <malloc+0x256>
 150:	027000ef          	jal	976 <printf>
  ps();
 154:	492000ef          	jal	5e6 <ps>
  
  printf("\n");
 158:	00001517          	auipc	a0,0x1
 15c:	a7850513          	addi	a0,a0,-1416 # bd0 <malloc+0x1a6>
 160:	017000ef          	jal	976 <printf>
  exit(0);
 164:	4501                	li	a0,0
 166:	3d8000ef          	jal	53e <exit>
    printf("\nTest 2: Block on pipe\n");
 16a:	00001517          	auipc	a0,0x1
 16e:	a6e50513          	addi	a0,a0,-1426 # bd8 <malloc+0x1ae>
 172:	005000ef          	jal	976 <printf>
    pipe(pipefd);
 176:	fb040513          	addi	a0,s0,-80
 17a:	3d4000ef          	jal	54e <pipe>
    pid = fork();
 17e:	3b8000ef          	jal	536 <fork>
    if(pid == 0) {
 182:	e539                	bnez	a0,1d0 <main+0x1a2>
 184:	e0ca                	sd	s2,64(sp)
 186:	fc4e                	sd	s3,56(sp)
 188:	f852                	sd	s4,48(sp)
 18a:	f456                	sd	s5,40(sp)
      printf("Child %d -> SLEEP\n", getpid());
 18c:	432000ef          	jal	5be <getpid>
 190:	85aa                	mv	a1,a0
 192:	00001517          	auipc	a0,0x1
 196:	a5e50513          	addi	a0,a0,-1442 # bf0 <malloc+0x1c6>
 19a:	7dc000ef          	jal	976 <printf>
      read(pipefd[0], buf, sizeof(buf));  // BLOCKS HERE
 19e:	4629                	li	a2,10
 1a0:	fa040593          	addi	a1,s0,-96
 1a4:	fb042503          	lw	a0,-80(s0)
 1a8:	3ae000ef          	jal	556 <read>
      printf("Child %d -> WOKE UP, got '%s'\n", getpid(), buf);
 1ac:	412000ef          	jal	5be <getpid>
 1b0:	85aa                	mv	a1,a0
 1b2:	fa040613          	addi	a2,s0,-96
 1b6:	00001517          	auipc	a0,0x1
 1ba:	a5250513          	addi	a0,a0,-1454 # c08 <malloc+0x1de>
 1be:	7b8000ef          	jal	976 <printf>
      close(pipefd[0]);
 1c2:	fb042503          	lw	a0,-80(s0)
 1c6:	3a0000ef          	jal	566 <close>
      exit(0);
 1ca:	4501                	li	a0,0
 1cc:	372000ef          	jal	53e <exit>
    delay(500000);
 1d0:	0007a537          	lui	a0,0x7a
 1d4:	12050513          	addi	a0,a0,288 # 7a120 <base+0x78110>
 1d8:	e29ff0ef          	jal	0 <delay>
    printf("Child -> SLEEP\n");
 1dc:	00001517          	auipc	a0,0x1
 1e0:	a4c50513          	addi	a0,a0,-1460 # c28 <malloc+0x1fe>
 1e4:	792000ef          	jal	976 <printf>
    ps();
 1e8:	3fe000ef          	jal	5e6 <ps>
    printf("Writing to pipe to wake child...\n");
 1ec:	00001517          	auipc	a0,0x1
 1f0:	a4c50513          	addi	a0,a0,-1460 # c38 <malloc+0x20e>
 1f4:	782000ef          	jal	976 <printf>
    write(pipefd[1], "Wake up message", 2);
 1f8:	4609                	li	a2,2
 1fa:	00001597          	auipc	a1,0x1
 1fe:	a6658593          	addi	a1,a1,-1434 # c60 <malloc+0x236>
 202:	fb442503          	lw	a0,-76(s0)
 206:	358000ef          	jal	55e <write>
    delay(500000);
 20a:	0007a537          	lui	a0,0x7a
 20e:	12050513          	addi	a0,a0,288 # 7a120 <base+0x78110>
 212:	defff0ef          	jal	0 <delay>
    wait(&status);
 216:	fbc40513          	addi	a0,s0,-68
 21a:	32c000ef          	jal	546 <wait>
    printf("Child done:\n");
 21e:	00001517          	auipc	a0,0x1
 222:	a5250513          	addi	a0,a0,-1454 # c70 <malloc+0x246>
 226:	750000ef          	jal	976 <printf>
    ps();
 22a:	3bc000ef          	jal	5e6 <ps>
    printf("\n");
 22e:	00001517          	auipc	a0,0x1
 232:	9a250513          	addi	a0,a0,-1630 # bd0 <malloc+0x1a6>
 236:	740000ef          	jal	976 <printf>
    close(pipefd[0]);
 23a:	fb042503          	lw	a0,-80(s0)
 23e:	328000ef          	jal	566 <close>
    close(pipefd[1]);
 242:	fb442503          	lw	a0,-76(s0)
 246:	320000ef          	jal	566 <close>
 24a:	b5dd                	j	130 <main+0x102>
 24c:	e0ca                	sd	s2,64(sp)
 24e:	fc4e                	sd	s3,56(sp)
 250:	f852                	sd	s4,48(sp)
 252:	f456                	sd	s5,40(sp)
        for(int j = 0; j < 20; j++) {
 254:	4481                	li	s1,0
          printf("%d", getpid() % 10);
 256:	4929                	li	s2,10
 258:	00001a97          	auipc	s5,0x1
 25c:	a78a8a93          	addi	s5,s5,-1416 # cd0 <malloc+0x2a6>
          delay(5000000);
 260:	004c59b7          	lui	s3,0x4c5
 264:	b4098993          	addi	s3,s3,-1216 # 4c4b40 <base+0x4c2b30>
        for(int j = 0; j < 20; j++) {
 268:	4a51                	li	s4,20
 26a:	a021                	j	272 <main+0x244>
 26c:	2485                	addiw	s1,s1,1
 26e:	03448263          	beq	s1,s4,292 <main+0x264>
          printf("%d", getpid() % 10);
 272:	34c000ef          	jal	5be <getpid>
 276:	032565bb          	remw	a1,a0,s2
 27a:	8556                	mv	a0,s5
 27c:	6fa000ef          	jal	976 <printf>
          delay(5000000);
 280:	854e                	mv	a0,s3
 282:	d7fff0ef          	jal	0 <delay>
          if (j % 10 == 0) {
 286:	0324e7bb          	remw	a5,s1,s2
 28a:	f3ed                	bnez	a5,26c <main+0x23e>
            ps();
 28c:	35a000ef          	jal	5e6 <ps>
 290:	bff1                	j	26c <main+0x23e>
        printf("\nProcess %d done\n", getpid());
 292:	32c000ef          	jal	5be <getpid>
 296:	85aa                	mv	a1,a0
 298:	00001517          	auipc	a0,0x1
 29c:	a4050513          	addi	a0,a0,-1472 # cd8 <malloc+0x2ae>
 2a0:	6d6000ef          	jal	976 <printf>
        exit(0);
 2a4:	4501                	li	a0,0
 2a6:	298000ef          	jal	53e <exit>

00000000000002aa <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 2aa:	1141                	addi	sp,sp,-16
 2ac:	e406                	sd	ra,8(sp)
 2ae:	e022                	sd	s0,0(sp)
 2b0:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 2b2:	d7dff0ef          	jal	2e <main>
  exit(r);
 2b6:	288000ef          	jal	53e <exit>

00000000000002ba <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 2ba:	1141                	addi	sp,sp,-16
 2bc:	e422                	sd	s0,8(sp)
 2be:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 2c0:	87aa                	mv	a5,a0
 2c2:	0585                	addi	a1,a1,1
 2c4:	0785                	addi	a5,a5,1
 2c6:	fff5c703          	lbu	a4,-1(a1)
 2ca:	fee78fa3          	sb	a4,-1(a5)
 2ce:	fb75                	bnez	a4,2c2 <strcpy+0x8>
    ;
  return os;
}
 2d0:	6422                	ld	s0,8(sp)
 2d2:	0141                	addi	sp,sp,16
 2d4:	8082                	ret

00000000000002d6 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 2d6:	1141                	addi	sp,sp,-16
 2d8:	e422                	sd	s0,8(sp)
 2da:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 2dc:	00054783          	lbu	a5,0(a0)
 2e0:	cb91                	beqz	a5,2f4 <strcmp+0x1e>
 2e2:	0005c703          	lbu	a4,0(a1)
 2e6:	00f71763          	bne	a4,a5,2f4 <strcmp+0x1e>
    p++, q++;
 2ea:	0505                	addi	a0,a0,1
 2ec:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2ee:	00054783          	lbu	a5,0(a0)
 2f2:	fbe5                	bnez	a5,2e2 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 2f4:	0005c503          	lbu	a0,0(a1)
}
 2f8:	40a7853b          	subw	a0,a5,a0
 2fc:	6422                	ld	s0,8(sp)
 2fe:	0141                	addi	sp,sp,16
 300:	8082                	ret

0000000000000302 <strlen>:

uint
strlen(const char *s)
{
 302:	1141                	addi	sp,sp,-16
 304:	e422                	sd	s0,8(sp)
 306:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 308:	00054783          	lbu	a5,0(a0)
 30c:	cf91                	beqz	a5,328 <strlen+0x26>
 30e:	0505                	addi	a0,a0,1
 310:	87aa                	mv	a5,a0
 312:	86be                	mv	a3,a5
 314:	0785                	addi	a5,a5,1
 316:	fff7c703          	lbu	a4,-1(a5)
 31a:	ff65                	bnez	a4,312 <strlen+0x10>
 31c:	40a6853b          	subw	a0,a3,a0
 320:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 322:	6422                	ld	s0,8(sp)
 324:	0141                	addi	sp,sp,16
 326:	8082                	ret
  for(n = 0; s[n]; n++)
 328:	4501                	li	a0,0
 32a:	bfe5                	j	322 <strlen+0x20>

000000000000032c <memset>:

void*
memset(void *dst, int c, uint n)
{
 32c:	1141                	addi	sp,sp,-16
 32e:	e422                	sd	s0,8(sp)
 330:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 332:	ca19                	beqz	a2,348 <memset+0x1c>
 334:	87aa                	mv	a5,a0
 336:	1602                	slli	a2,a2,0x20
 338:	9201                	srli	a2,a2,0x20
 33a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 33e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 342:	0785                	addi	a5,a5,1
 344:	fee79de3          	bne	a5,a4,33e <memset+0x12>
  }
  return dst;
}
 348:	6422                	ld	s0,8(sp)
 34a:	0141                	addi	sp,sp,16
 34c:	8082                	ret

000000000000034e <strchr>:

char*
strchr(const char *s, char c)
{
 34e:	1141                	addi	sp,sp,-16
 350:	e422                	sd	s0,8(sp)
 352:	0800                	addi	s0,sp,16
  for(; *s; s++)
 354:	00054783          	lbu	a5,0(a0)
 358:	cb99                	beqz	a5,36e <strchr+0x20>
    if(*s == c)
 35a:	00f58763          	beq	a1,a5,368 <strchr+0x1a>
  for(; *s; s++)
 35e:	0505                	addi	a0,a0,1
 360:	00054783          	lbu	a5,0(a0)
 364:	fbfd                	bnez	a5,35a <strchr+0xc>
      return (char*)s;
  return 0;
 366:	4501                	li	a0,0
}
 368:	6422                	ld	s0,8(sp)
 36a:	0141                	addi	sp,sp,16
 36c:	8082                	ret
  return 0;
 36e:	4501                	li	a0,0
 370:	bfe5                	j	368 <strchr+0x1a>

0000000000000372 <gets>:

char*
gets(char *buf, int max)
{
 372:	711d                	addi	sp,sp,-96
 374:	ec86                	sd	ra,88(sp)
 376:	e8a2                	sd	s0,80(sp)
 378:	e4a6                	sd	s1,72(sp)
 37a:	e0ca                	sd	s2,64(sp)
 37c:	fc4e                	sd	s3,56(sp)
 37e:	f852                	sd	s4,48(sp)
 380:	f456                	sd	s5,40(sp)
 382:	f05a                	sd	s6,32(sp)
 384:	ec5e                	sd	s7,24(sp)
 386:	1080                	addi	s0,sp,96
 388:	8baa                	mv	s7,a0
 38a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 38c:	892a                	mv	s2,a0
 38e:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 390:	4aa9                	li	s5,10
 392:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 394:	89a6                	mv	s3,s1
 396:	2485                	addiw	s1,s1,1
 398:	0344d663          	bge	s1,s4,3c4 <gets+0x52>
    cc = read(0, &c, 1);
 39c:	4605                	li	a2,1
 39e:	faf40593          	addi	a1,s0,-81
 3a2:	4501                	li	a0,0
 3a4:	1b2000ef          	jal	556 <read>
    if(cc < 1)
 3a8:	00a05e63          	blez	a0,3c4 <gets+0x52>
    buf[i++] = c;
 3ac:	faf44783          	lbu	a5,-81(s0)
 3b0:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 3b4:	01578763          	beq	a5,s5,3c2 <gets+0x50>
 3b8:	0905                	addi	s2,s2,1
 3ba:	fd679de3          	bne	a5,s6,394 <gets+0x22>
    buf[i++] = c;
 3be:	89a6                	mv	s3,s1
 3c0:	a011                	j	3c4 <gets+0x52>
 3c2:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 3c4:	99de                	add	s3,s3,s7
 3c6:	00098023          	sb	zero,0(s3)
  return buf;
}
 3ca:	855e                	mv	a0,s7
 3cc:	60e6                	ld	ra,88(sp)
 3ce:	6446                	ld	s0,80(sp)
 3d0:	64a6                	ld	s1,72(sp)
 3d2:	6906                	ld	s2,64(sp)
 3d4:	79e2                	ld	s3,56(sp)
 3d6:	7a42                	ld	s4,48(sp)
 3d8:	7aa2                	ld	s5,40(sp)
 3da:	7b02                	ld	s6,32(sp)
 3dc:	6be2                	ld	s7,24(sp)
 3de:	6125                	addi	sp,sp,96
 3e0:	8082                	ret

00000000000003e2 <stat>:

int
stat(const char *n, struct stat *st)
{
 3e2:	1101                	addi	sp,sp,-32
 3e4:	ec06                	sd	ra,24(sp)
 3e6:	e822                	sd	s0,16(sp)
 3e8:	e04a                	sd	s2,0(sp)
 3ea:	1000                	addi	s0,sp,32
 3ec:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3ee:	4581                	li	a1,0
 3f0:	18e000ef          	jal	57e <open>
  if(fd < 0)
 3f4:	02054263          	bltz	a0,418 <stat+0x36>
 3f8:	e426                	sd	s1,8(sp)
 3fa:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3fc:	85ca                	mv	a1,s2
 3fe:	198000ef          	jal	596 <fstat>
 402:	892a                	mv	s2,a0
  close(fd);
 404:	8526                	mv	a0,s1
 406:	160000ef          	jal	566 <close>
  return r;
 40a:	64a2                	ld	s1,8(sp)
}
 40c:	854a                	mv	a0,s2
 40e:	60e2                	ld	ra,24(sp)
 410:	6442                	ld	s0,16(sp)
 412:	6902                	ld	s2,0(sp)
 414:	6105                	addi	sp,sp,32
 416:	8082                	ret
    return -1;
 418:	597d                	li	s2,-1
 41a:	bfcd                	j	40c <stat+0x2a>

000000000000041c <atoi>:

int
atoi(const char *s)
{
 41c:	1141                	addi	sp,sp,-16
 41e:	e422                	sd	s0,8(sp)
 420:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 422:	00054683          	lbu	a3,0(a0)
 426:	fd06879b          	addiw	a5,a3,-48
 42a:	0ff7f793          	zext.b	a5,a5
 42e:	4625                	li	a2,9
 430:	02f66863          	bltu	a2,a5,460 <atoi+0x44>
 434:	872a                	mv	a4,a0
  n = 0;
 436:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 438:	0705                	addi	a4,a4,1
 43a:	0025179b          	slliw	a5,a0,0x2
 43e:	9fa9                	addw	a5,a5,a0
 440:	0017979b          	slliw	a5,a5,0x1
 444:	9fb5                	addw	a5,a5,a3
 446:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 44a:	00074683          	lbu	a3,0(a4)
 44e:	fd06879b          	addiw	a5,a3,-48
 452:	0ff7f793          	zext.b	a5,a5
 456:	fef671e3          	bgeu	a2,a5,438 <atoi+0x1c>
  return n;
}
 45a:	6422                	ld	s0,8(sp)
 45c:	0141                	addi	sp,sp,16
 45e:	8082                	ret
  n = 0;
 460:	4501                	li	a0,0
 462:	bfe5                	j	45a <atoi+0x3e>

0000000000000464 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 464:	1141                	addi	sp,sp,-16
 466:	e422                	sd	s0,8(sp)
 468:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 46a:	02b57463          	bgeu	a0,a1,492 <memmove+0x2e>
    while(n-- > 0)
 46e:	00c05f63          	blez	a2,48c <memmove+0x28>
 472:	1602                	slli	a2,a2,0x20
 474:	9201                	srli	a2,a2,0x20
 476:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 47a:	872a                	mv	a4,a0
      *dst++ = *src++;
 47c:	0585                	addi	a1,a1,1
 47e:	0705                	addi	a4,a4,1
 480:	fff5c683          	lbu	a3,-1(a1)
 484:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 488:	fef71ae3          	bne	a4,a5,47c <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 48c:	6422                	ld	s0,8(sp)
 48e:	0141                	addi	sp,sp,16
 490:	8082                	ret
    dst += n;
 492:	00c50733          	add	a4,a0,a2
    src += n;
 496:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 498:	fec05ae3          	blez	a2,48c <memmove+0x28>
 49c:	fff6079b          	addiw	a5,a2,-1
 4a0:	1782                	slli	a5,a5,0x20
 4a2:	9381                	srli	a5,a5,0x20
 4a4:	fff7c793          	not	a5,a5
 4a8:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 4aa:	15fd                	addi	a1,a1,-1
 4ac:	177d                	addi	a4,a4,-1
 4ae:	0005c683          	lbu	a3,0(a1)
 4b2:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 4b6:	fee79ae3          	bne	a5,a4,4aa <memmove+0x46>
 4ba:	bfc9                	j	48c <memmove+0x28>

00000000000004bc <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 4bc:	1141                	addi	sp,sp,-16
 4be:	e422                	sd	s0,8(sp)
 4c0:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 4c2:	ca05                	beqz	a2,4f2 <memcmp+0x36>
 4c4:	fff6069b          	addiw	a3,a2,-1
 4c8:	1682                	slli	a3,a3,0x20
 4ca:	9281                	srli	a3,a3,0x20
 4cc:	0685                	addi	a3,a3,1
 4ce:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 4d0:	00054783          	lbu	a5,0(a0)
 4d4:	0005c703          	lbu	a4,0(a1)
 4d8:	00e79863          	bne	a5,a4,4e8 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 4dc:	0505                	addi	a0,a0,1
    p2++;
 4de:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4e0:	fed518e3          	bne	a0,a3,4d0 <memcmp+0x14>
  }
  return 0;
 4e4:	4501                	li	a0,0
 4e6:	a019                	j	4ec <memcmp+0x30>
      return *p1 - *p2;
 4e8:	40e7853b          	subw	a0,a5,a4
}
 4ec:	6422                	ld	s0,8(sp)
 4ee:	0141                	addi	sp,sp,16
 4f0:	8082                	ret
  return 0;
 4f2:	4501                	li	a0,0
 4f4:	bfe5                	j	4ec <memcmp+0x30>

00000000000004f6 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4f6:	1141                	addi	sp,sp,-16
 4f8:	e406                	sd	ra,8(sp)
 4fa:	e022                	sd	s0,0(sp)
 4fc:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4fe:	f67ff0ef          	jal	464 <memmove>
}
 502:	60a2                	ld	ra,8(sp)
 504:	6402                	ld	s0,0(sp)
 506:	0141                	addi	sp,sp,16
 508:	8082                	ret

000000000000050a <sbrk>:

char *
sbrk(int n) {
 50a:	1141                	addi	sp,sp,-16
 50c:	e406                	sd	ra,8(sp)
 50e:	e022                	sd	s0,0(sp)
 510:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 512:	4585                	li	a1,1
 514:	0b2000ef          	jal	5c6 <sys_sbrk>
}
 518:	60a2                	ld	ra,8(sp)
 51a:	6402                	ld	s0,0(sp)
 51c:	0141                	addi	sp,sp,16
 51e:	8082                	ret

0000000000000520 <sbrklazy>:

char *
sbrklazy(int n) {
 520:	1141                	addi	sp,sp,-16
 522:	e406                	sd	ra,8(sp)
 524:	e022                	sd	s0,0(sp)
 526:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 528:	4589                	li	a1,2
 52a:	09c000ef          	jal	5c6 <sys_sbrk>
}
 52e:	60a2                	ld	ra,8(sp)
 530:	6402                	ld	s0,0(sp)
 532:	0141                	addi	sp,sp,16
 534:	8082                	ret

0000000000000536 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 536:	4885                	li	a7,1
 ecall
 538:	00000073          	ecall
 ret
 53c:	8082                	ret

000000000000053e <exit>:
.global exit
exit:
 li a7, SYS_exit
 53e:	4889                	li	a7,2
 ecall
 540:	00000073          	ecall
 ret
 544:	8082                	ret

0000000000000546 <wait>:
.global wait
wait:
 li a7, SYS_wait
 546:	488d                	li	a7,3
 ecall
 548:	00000073          	ecall
 ret
 54c:	8082                	ret

000000000000054e <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 54e:	4891                	li	a7,4
 ecall
 550:	00000073          	ecall
 ret
 554:	8082                	ret

0000000000000556 <read>:
.global read
read:
 li a7, SYS_read
 556:	4895                	li	a7,5
 ecall
 558:	00000073          	ecall
 ret
 55c:	8082                	ret

000000000000055e <write>:
.global write
write:
 li a7, SYS_write
 55e:	48c1                	li	a7,16
 ecall
 560:	00000073          	ecall
 ret
 564:	8082                	ret

0000000000000566 <close>:
.global close
close:
 li a7, SYS_close
 566:	48d5                	li	a7,21
 ecall
 568:	00000073          	ecall
 ret
 56c:	8082                	ret

000000000000056e <kill>:
.global kill
kill:
 li a7, SYS_kill
 56e:	4899                	li	a7,6
 ecall
 570:	00000073          	ecall
 ret
 574:	8082                	ret

0000000000000576 <exec>:
.global exec
exec:
 li a7, SYS_exec
 576:	489d                	li	a7,7
 ecall
 578:	00000073          	ecall
 ret
 57c:	8082                	ret

000000000000057e <open>:
.global open
open:
 li a7, SYS_open
 57e:	48bd                	li	a7,15
 ecall
 580:	00000073          	ecall
 ret
 584:	8082                	ret

0000000000000586 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 586:	48c5                	li	a7,17
 ecall
 588:	00000073          	ecall
 ret
 58c:	8082                	ret

000000000000058e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 58e:	48c9                	li	a7,18
 ecall
 590:	00000073          	ecall
 ret
 594:	8082                	ret

0000000000000596 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 596:	48a1                	li	a7,8
 ecall
 598:	00000073          	ecall
 ret
 59c:	8082                	ret

000000000000059e <link>:
.global link
link:
 li a7, SYS_link
 59e:	48cd                	li	a7,19
 ecall
 5a0:	00000073          	ecall
 ret
 5a4:	8082                	ret

00000000000005a6 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 5a6:	48d1                	li	a7,20
 ecall
 5a8:	00000073          	ecall
 ret
 5ac:	8082                	ret

00000000000005ae <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 5ae:	48a5                	li	a7,9
 ecall
 5b0:	00000073          	ecall
 ret
 5b4:	8082                	ret

00000000000005b6 <dup>:
.global dup
dup:
 li a7, SYS_dup
 5b6:	48a9                	li	a7,10
 ecall
 5b8:	00000073          	ecall
 ret
 5bc:	8082                	ret

00000000000005be <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 5be:	48ad                	li	a7,11
 ecall
 5c0:	00000073          	ecall
 ret
 5c4:	8082                	ret

00000000000005c6 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 5c6:	48b1                	li	a7,12
 ecall
 5c8:	00000073          	ecall
 ret
 5cc:	8082                	ret

00000000000005ce <pause>:
.global pause
pause:
 li a7, SYS_pause
 5ce:	48b5                	li	a7,13
 ecall
 5d0:	00000073          	ecall
 ret
 5d4:	8082                	ret

00000000000005d6 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 5d6:	48b9                	li	a7,14
 ecall
 5d8:	00000073          	ecall
 ret
 5dc:	8082                	ret

00000000000005de <setquantum>:
.global setquantum
setquantum:
 li a7, SYS_setquantum
 5de:	48d9                	li	a7,22
 ecall
 5e0:	00000073          	ecall
 ret
 5e4:	8082                	ret

00000000000005e6 <ps>:
.global ps
ps:
 li a7, SYS_ps
 5e6:	48dd                	li	a7,23
 ecall
 5e8:	00000073          	ecall
 ret
 5ec:	8082                	ret

00000000000005ee <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 5ee:	1101                	addi	sp,sp,-32
 5f0:	ec06                	sd	ra,24(sp)
 5f2:	e822                	sd	s0,16(sp)
 5f4:	1000                	addi	s0,sp,32
 5f6:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 5fa:	4605                	li	a2,1
 5fc:	fef40593          	addi	a1,s0,-17
 600:	f5fff0ef          	jal	55e <write>
}
 604:	60e2                	ld	ra,24(sp)
 606:	6442                	ld	s0,16(sp)
 608:	6105                	addi	sp,sp,32
 60a:	8082                	ret

000000000000060c <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 60c:	715d                	addi	sp,sp,-80
 60e:	e486                	sd	ra,72(sp)
 610:	e0a2                	sd	s0,64(sp)
 612:	f84a                	sd	s2,48(sp)
 614:	0880                	addi	s0,sp,80
 616:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 618:	c299                	beqz	a3,61e <printint+0x12>
 61a:	0805c363          	bltz	a1,6a0 <printint+0x94>
  neg = 0;
 61e:	4881                	li	a7,0
 620:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 624:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 626:	00000517          	auipc	a0,0x0
 62a:	71250513          	addi	a0,a0,1810 # d38 <digits>
 62e:	883e                	mv	a6,a5
 630:	2785                	addiw	a5,a5,1
 632:	02c5f733          	remu	a4,a1,a2
 636:	972a                	add	a4,a4,a0
 638:	00074703          	lbu	a4,0(a4)
 63c:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 640:	872e                	mv	a4,a1
 642:	02c5d5b3          	divu	a1,a1,a2
 646:	0685                	addi	a3,a3,1
 648:	fec773e3          	bgeu	a4,a2,62e <printint+0x22>
  if(neg)
 64c:	00088b63          	beqz	a7,662 <printint+0x56>
    buf[i++] = '-';
 650:	fd078793          	addi	a5,a5,-48
 654:	97a2                	add	a5,a5,s0
 656:	02d00713          	li	a4,45
 65a:	fee78423          	sb	a4,-24(a5)
 65e:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 662:	02f05a63          	blez	a5,696 <printint+0x8a>
 666:	fc26                	sd	s1,56(sp)
 668:	f44e                	sd	s3,40(sp)
 66a:	fb840713          	addi	a4,s0,-72
 66e:	00f704b3          	add	s1,a4,a5
 672:	fff70993          	addi	s3,a4,-1
 676:	99be                	add	s3,s3,a5
 678:	37fd                	addiw	a5,a5,-1
 67a:	1782                	slli	a5,a5,0x20
 67c:	9381                	srli	a5,a5,0x20
 67e:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 682:	fff4c583          	lbu	a1,-1(s1)
 686:	854a                	mv	a0,s2
 688:	f67ff0ef          	jal	5ee <putc>
  while(--i >= 0)
 68c:	14fd                	addi	s1,s1,-1
 68e:	ff349ae3          	bne	s1,s3,682 <printint+0x76>
 692:	74e2                	ld	s1,56(sp)
 694:	79a2                	ld	s3,40(sp)
}
 696:	60a6                	ld	ra,72(sp)
 698:	6406                	ld	s0,64(sp)
 69a:	7942                	ld	s2,48(sp)
 69c:	6161                	addi	sp,sp,80
 69e:	8082                	ret
    x = -xx;
 6a0:	40b005b3          	neg	a1,a1
    neg = 1;
 6a4:	4885                	li	a7,1
    x = -xx;
 6a6:	bfad                	j	620 <printint+0x14>

00000000000006a8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 6a8:	711d                	addi	sp,sp,-96
 6aa:	ec86                	sd	ra,88(sp)
 6ac:	e8a2                	sd	s0,80(sp)
 6ae:	e0ca                	sd	s2,64(sp)
 6b0:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 6b2:	0005c903          	lbu	s2,0(a1)
 6b6:	28090663          	beqz	s2,942 <vprintf+0x29a>
 6ba:	e4a6                	sd	s1,72(sp)
 6bc:	fc4e                	sd	s3,56(sp)
 6be:	f852                	sd	s4,48(sp)
 6c0:	f456                	sd	s5,40(sp)
 6c2:	f05a                	sd	s6,32(sp)
 6c4:	ec5e                	sd	s7,24(sp)
 6c6:	e862                	sd	s8,16(sp)
 6c8:	e466                	sd	s9,8(sp)
 6ca:	8b2a                	mv	s6,a0
 6cc:	8a2e                	mv	s4,a1
 6ce:	8bb2                	mv	s7,a2
  state = 0;
 6d0:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 6d2:	4481                	li	s1,0
 6d4:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 6d6:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 6da:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 6de:	06c00c93          	li	s9,108
 6e2:	a005                	j	702 <vprintf+0x5a>
        putc(fd, c0);
 6e4:	85ca                	mv	a1,s2
 6e6:	855a                	mv	a0,s6
 6e8:	f07ff0ef          	jal	5ee <putc>
 6ec:	a019                	j	6f2 <vprintf+0x4a>
    } else if(state == '%'){
 6ee:	03598263          	beq	s3,s5,712 <vprintf+0x6a>
  for(i = 0; fmt[i]; i++){
 6f2:	2485                	addiw	s1,s1,1
 6f4:	8726                	mv	a4,s1
 6f6:	009a07b3          	add	a5,s4,s1
 6fa:	0007c903          	lbu	s2,0(a5)
 6fe:	22090a63          	beqz	s2,932 <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 702:	0009079b          	sext.w	a5,s2
    if(state == 0){
 706:	fe0994e3          	bnez	s3,6ee <vprintf+0x46>
      if(c0 == '%'){
 70a:	fd579de3          	bne	a5,s5,6e4 <vprintf+0x3c>
        state = '%';
 70e:	89be                	mv	s3,a5
 710:	b7cd                	j	6f2 <vprintf+0x4a>
      if(c0) c1 = fmt[i+1] & 0xff;
 712:	00ea06b3          	add	a3,s4,a4
 716:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 71a:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 71c:	c681                	beqz	a3,724 <vprintf+0x7c>
 71e:	9752                	add	a4,a4,s4
 720:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 724:	05878363          	beq	a5,s8,76a <vprintf+0xc2>
      } else if(c0 == 'l' && c1 == 'd'){
 728:	05978d63          	beq	a5,s9,782 <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 72c:	07500713          	li	a4,117
 730:	0ee78763          	beq	a5,a4,81e <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 734:	07800713          	li	a4,120
 738:	12e78963          	beq	a5,a4,86a <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 73c:	07000713          	li	a4,112
 740:	14e78e63          	beq	a5,a4,89c <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 744:	06300713          	li	a4,99
 748:	18e78e63          	beq	a5,a4,8e4 <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 74c:	07300713          	li	a4,115
 750:	1ae78463          	beq	a5,a4,8f8 <vprintf+0x250>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 754:	02500713          	li	a4,37
 758:	04e79563          	bne	a5,a4,7a2 <vprintf+0xfa>
        putc(fd, '%');
 75c:	02500593          	li	a1,37
 760:	855a                	mv	a0,s6
 762:	e8dff0ef          	jal	5ee <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 766:	4981                	li	s3,0
 768:	b769                	j	6f2 <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 76a:	008b8913          	addi	s2,s7,8
 76e:	4685                	li	a3,1
 770:	4629                	li	a2,10
 772:	000ba583          	lw	a1,0(s7)
 776:	855a                	mv	a0,s6
 778:	e95ff0ef          	jal	60c <printint>
 77c:	8bca                	mv	s7,s2
      state = 0;
 77e:	4981                	li	s3,0
 780:	bf8d                	j	6f2 <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'd'){
 782:	06400793          	li	a5,100
 786:	02f68963          	beq	a3,a5,7b8 <vprintf+0x110>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 78a:	06c00793          	li	a5,108
 78e:	04f68263          	beq	a3,a5,7d2 <vprintf+0x12a>
      } else if(c0 == 'l' && c1 == 'u'){
 792:	07500793          	li	a5,117
 796:	0af68063          	beq	a3,a5,836 <vprintf+0x18e>
      } else if(c0 == 'l' && c1 == 'x'){
 79a:	07800793          	li	a5,120
 79e:	0ef68263          	beq	a3,a5,882 <vprintf+0x1da>
        putc(fd, '%');
 7a2:	02500593          	li	a1,37
 7a6:	855a                	mv	a0,s6
 7a8:	e47ff0ef          	jal	5ee <putc>
        putc(fd, c0);
 7ac:	85ca                	mv	a1,s2
 7ae:	855a                	mv	a0,s6
 7b0:	e3fff0ef          	jal	5ee <putc>
      state = 0;
 7b4:	4981                	li	s3,0
 7b6:	bf35                	j	6f2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 7b8:	008b8913          	addi	s2,s7,8
 7bc:	4685                	li	a3,1
 7be:	4629                	li	a2,10
 7c0:	000bb583          	ld	a1,0(s7)
 7c4:	855a                	mv	a0,s6
 7c6:	e47ff0ef          	jal	60c <printint>
        i += 1;
 7ca:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 7cc:	8bca                	mv	s7,s2
      state = 0;
 7ce:	4981                	li	s3,0
        i += 1;
 7d0:	b70d                	j	6f2 <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 7d2:	06400793          	li	a5,100
 7d6:	02f60763          	beq	a2,a5,804 <vprintf+0x15c>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 7da:	07500793          	li	a5,117
 7de:	06f60963          	beq	a2,a5,850 <vprintf+0x1a8>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 7e2:	07800793          	li	a5,120
 7e6:	faf61ee3          	bne	a2,a5,7a2 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ea:	008b8913          	addi	s2,s7,8
 7ee:	4681                	li	a3,0
 7f0:	4641                	li	a2,16
 7f2:	000bb583          	ld	a1,0(s7)
 7f6:	855a                	mv	a0,s6
 7f8:	e15ff0ef          	jal	60c <printint>
        i += 2;
 7fc:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 7fe:	8bca                	mv	s7,s2
      state = 0;
 800:	4981                	li	s3,0
        i += 2;
 802:	bdc5                	j	6f2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 804:	008b8913          	addi	s2,s7,8
 808:	4685                	li	a3,1
 80a:	4629                	li	a2,10
 80c:	000bb583          	ld	a1,0(s7)
 810:	855a                	mv	a0,s6
 812:	dfbff0ef          	jal	60c <printint>
        i += 2;
 816:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 818:	8bca                	mv	s7,s2
      state = 0;
 81a:	4981                	li	s3,0
        i += 2;
 81c:	bdd9                	j	6f2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 81e:	008b8913          	addi	s2,s7,8
 822:	4681                	li	a3,0
 824:	4629                	li	a2,10
 826:	000be583          	lwu	a1,0(s7)
 82a:	855a                	mv	a0,s6
 82c:	de1ff0ef          	jal	60c <printint>
 830:	8bca                	mv	s7,s2
      state = 0;
 832:	4981                	li	s3,0
 834:	bd7d                	j	6f2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 836:	008b8913          	addi	s2,s7,8
 83a:	4681                	li	a3,0
 83c:	4629                	li	a2,10
 83e:	000bb583          	ld	a1,0(s7)
 842:	855a                	mv	a0,s6
 844:	dc9ff0ef          	jal	60c <printint>
        i += 1;
 848:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 84a:	8bca                	mv	s7,s2
      state = 0;
 84c:	4981                	li	s3,0
        i += 1;
 84e:	b555                	j	6f2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 850:	008b8913          	addi	s2,s7,8
 854:	4681                	li	a3,0
 856:	4629                	li	a2,10
 858:	000bb583          	ld	a1,0(s7)
 85c:	855a                	mv	a0,s6
 85e:	dafff0ef          	jal	60c <printint>
        i += 2;
 862:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 864:	8bca                	mv	s7,s2
      state = 0;
 866:	4981                	li	s3,0
        i += 2;
 868:	b569                	j	6f2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 86a:	008b8913          	addi	s2,s7,8
 86e:	4681                	li	a3,0
 870:	4641                	li	a2,16
 872:	000be583          	lwu	a1,0(s7)
 876:	855a                	mv	a0,s6
 878:	d95ff0ef          	jal	60c <printint>
 87c:	8bca                	mv	s7,s2
      state = 0;
 87e:	4981                	li	s3,0
 880:	bd8d                	j	6f2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 882:	008b8913          	addi	s2,s7,8
 886:	4681                	li	a3,0
 888:	4641                	li	a2,16
 88a:	000bb583          	ld	a1,0(s7)
 88e:	855a                	mv	a0,s6
 890:	d7dff0ef          	jal	60c <printint>
        i += 1;
 894:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 896:	8bca                	mv	s7,s2
      state = 0;
 898:	4981                	li	s3,0
        i += 1;
 89a:	bda1                	j	6f2 <vprintf+0x4a>
 89c:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 89e:	008b8d13          	addi	s10,s7,8
 8a2:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 8a6:	03000593          	li	a1,48
 8aa:	855a                	mv	a0,s6
 8ac:	d43ff0ef          	jal	5ee <putc>
  putc(fd, 'x');
 8b0:	07800593          	li	a1,120
 8b4:	855a                	mv	a0,s6
 8b6:	d39ff0ef          	jal	5ee <putc>
 8ba:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 8bc:	00000b97          	auipc	s7,0x0
 8c0:	47cb8b93          	addi	s7,s7,1148 # d38 <digits>
 8c4:	03c9d793          	srli	a5,s3,0x3c
 8c8:	97de                	add	a5,a5,s7
 8ca:	0007c583          	lbu	a1,0(a5)
 8ce:	855a                	mv	a0,s6
 8d0:	d1fff0ef          	jal	5ee <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 8d4:	0992                	slli	s3,s3,0x4
 8d6:	397d                	addiw	s2,s2,-1
 8d8:	fe0916e3          	bnez	s2,8c4 <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 8dc:	8bea                	mv	s7,s10
      state = 0;
 8de:	4981                	li	s3,0
 8e0:	6d02                	ld	s10,0(sp)
 8e2:	bd01                	j	6f2 <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 8e4:	008b8913          	addi	s2,s7,8
 8e8:	000bc583          	lbu	a1,0(s7)
 8ec:	855a                	mv	a0,s6
 8ee:	d01ff0ef          	jal	5ee <putc>
 8f2:	8bca                	mv	s7,s2
      state = 0;
 8f4:	4981                	li	s3,0
 8f6:	bbf5                	j	6f2 <vprintf+0x4a>
        if((s = va_arg(ap, char*)) == 0)
 8f8:	008b8993          	addi	s3,s7,8
 8fc:	000bb903          	ld	s2,0(s7)
 900:	00090f63          	beqz	s2,91e <vprintf+0x276>
        for(; *s; s++)
 904:	00094583          	lbu	a1,0(s2)
 908:	c195                	beqz	a1,92c <vprintf+0x284>
          putc(fd, *s);
 90a:	855a                	mv	a0,s6
 90c:	ce3ff0ef          	jal	5ee <putc>
        for(; *s; s++)
 910:	0905                	addi	s2,s2,1
 912:	00094583          	lbu	a1,0(s2)
 916:	f9f5                	bnez	a1,90a <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 918:	8bce                	mv	s7,s3
      state = 0;
 91a:	4981                	li	s3,0
 91c:	bbd9                	j	6f2 <vprintf+0x4a>
          s = "(null)";
 91e:	00000917          	auipc	s2,0x0
 922:	41290913          	addi	s2,s2,1042 # d30 <malloc+0x306>
        for(; *s; s++)
 926:	02800593          	li	a1,40
 92a:	b7c5                	j	90a <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 92c:	8bce                	mv	s7,s3
      state = 0;
 92e:	4981                	li	s3,0
 930:	b3c9                	j	6f2 <vprintf+0x4a>
 932:	64a6                	ld	s1,72(sp)
 934:	79e2                	ld	s3,56(sp)
 936:	7a42                	ld	s4,48(sp)
 938:	7aa2                	ld	s5,40(sp)
 93a:	7b02                	ld	s6,32(sp)
 93c:	6be2                	ld	s7,24(sp)
 93e:	6c42                	ld	s8,16(sp)
 940:	6ca2                	ld	s9,8(sp)
    }
  }
}
 942:	60e6                	ld	ra,88(sp)
 944:	6446                	ld	s0,80(sp)
 946:	6906                	ld	s2,64(sp)
 948:	6125                	addi	sp,sp,96
 94a:	8082                	ret

000000000000094c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 94c:	715d                	addi	sp,sp,-80
 94e:	ec06                	sd	ra,24(sp)
 950:	e822                	sd	s0,16(sp)
 952:	1000                	addi	s0,sp,32
 954:	e010                	sd	a2,0(s0)
 956:	e414                	sd	a3,8(s0)
 958:	e818                	sd	a4,16(s0)
 95a:	ec1c                	sd	a5,24(s0)
 95c:	03043023          	sd	a6,32(s0)
 960:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 964:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 968:	8622                	mv	a2,s0
 96a:	d3fff0ef          	jal	6a8 <vprintf>
}
 96e:	60e2                	ld	ra,24(sp)
 970:	6442                	ld	s0,16(sp)
 972:	6161                	addi	sp,sp,80
 974:	8082                	ret

0000000000000976 <printf>:

void
printf(const char *fmt, ...)
{
 976:	711d                	addi	sp,sp,-96
 978:	ec06                	sd	ra,24(sp)
 97a:	e822                	sd	s0,16(sp)
 97c:	1000                	addi	s0,sp,32
 97e:	e40c                	sd	a1,8(s0)
 980:	e810                	sd	a2,16(s0)
 982:	ec14                	sd	a3,24(s0)
 984:	f018                	sd	a4,32(s0)
 986:	f41c                	sd	a5,40(s0)
 988:	03043823          	sd	a6,48(s0)
 98c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 990:	00840613          	addi	a2,s0,8
 994:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 998:	85aa                	mv	a1,a0
 99a:	4505                	li	a0,1
 99c:	d0dff0ef          	jal	6a8 <vprintf>
}
 9a0:	60e2                	ld	ra,24(sp)
 9a2:	6442                	ld	s0,16(sp)
 9a4:	6125                	addi	sp,sp,96
 9a6:	8082                	ret

00000000000009a8 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 9a8:	1141                	addi	sp,sp,-16
 9aa:	e422                	sd	s0,8(sp)
 9ac:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 9ae:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9b2:	00001797          	auipc	a5,0x1
 9b6:	64e7b783          	ld	a5,1614(a5) # 2000 <freep>
 9ba:	a02d                	j	9e4 <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 9bc:	4618                	lw	a4,8(a2)
 9be:	9f2d                	addw	a4,a4,a1
 9c0:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 9c4:	6398                	ld	a4,0(a5)
 9c6:	6310                	ld	a2,0(a4)
 9c8:	a83d                	j	a06 <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 9ca:	ff852703          	lw	a4,-8(a0)
 9ce:	9f31                	addw	a4,a4,a2
 9d0:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 9d2:	ff053683          	ld	a3,-16(a0)
 9d6:	a091                	j	a1a <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9d8:	6398                	ld	a4,0(a5)
 9da:	00e7e463          	bltu	a5,a4,9e2 <free+0x3a>
 9de:	00e6ea63          	bltu	a3,a4,9f2 <free+0x4a>
{
 9e2:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9e4:	fed7fae3          	bgeu	a5,a3,9d8 <free+0x30>
 9e8:	6398                	ld	a4,0(a5)
 9ea:	00e6e463          	bltu	a3,a4,9f2 <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9ee:	fee7eae3          	bltu	a5,a4,9e2 <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 9f2:	ff852583          	lw	a1,-8(a0)
 9f6:	6390                	ld	a2,0(a5)
 9f8:	02059813          	slli	a6,a1,0x20
 9fc:	01c85713          	srli	a4,a6,0x1c
 a00:	9736                	add	a4,a4,a3
 a02:	fae60de3          	beq	a2,a4,9bc <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 a06:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 a0a:	4790                	lw	a2,8(a5)
 a0c:	02061593          	slli	a1,a2,0x20
 a10:	01c5d713          	srli	a4,a1,0x1c
 a14:	973e                	add	a4,a4,a5
 a16:	fae68ae3          	beq	a3,a4,9ca <free+0x22>
    p->s.ptr = bp->s.ptr;
 a1a:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 a1c:	00001717          	auipc	a4,0x1
 a20:	5ef73223          	sd	a5,1508(a4) # 2000 <freep>
}
 a24:	6422                	ld	s0,8(sp)
 a26:	0141                	addi	sp,sp,16
 a28:	8082                	ret

0000000000000a2a <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a2a:	7139                	addi	sp,sp,-64
 a2c:	fc06                	sd	ra,56(sp)
 a2e:	f822                	sd	s0,48(sp)
 a30:	f426                	sd	s1,40(sp)
 a32:	ec4e                	sd	s3,24(sp)
 a34:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a36:	02051493          	slli	s1,a0,0x20
 a3a:	9081                	srli	s1,s1,0x20
 a3c:	04bd                	addi	s1,s1,15
 a3e:	8091                	srli	s1,s1,0x4
 a40:	0014899b          	addiw	s3,s1,1
 a44:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 a46:	00001517          	auipc	a0,0x1
 a4a:	5ba53503          	ld	a0,1466(a0) # 2000 <freep>
 a4e:	c915                	beqz	a0,a82 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a50:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a52:	4798                	lw	a4,8(a5)
 a54:	08977a63          	bgeu	a4,s1,ae8 <malloc+0xbe>
 a58:	f04a                	sd	s2,32(sp)
 a5a:	e852                	sd	s4,16(sp)
 a5c:	e456                	sd	s5,8(sp)
 a5e:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a60:	8a4e                	mv	s4,s3
 a62:	0009871b          	sext.w	a4,s3
 a66:	6685                	lui	a3,0x1
 a68:	00d77363          	bgeu	a4,a3,a6e <malloc+0x44>
 a6c:	6a05                	lui	s4,0x1
 a6e:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a72:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a76:	00001917          	auipc	s2,0x1
 a7a:	58a90913          	addi	s2,s2,1418 # 2000 <freep>
  if(p == SBRK_ERROR)
 a7e:	5afd                	li	s5,-1
 a80:	a081                	j	ac0 <malloc+0x96>
 a82:	f04a                	sd	s2,32(sp)
 a84:	e852                	sd	s4,16(sp)
 a86:	e456                	sd	s5,8(sp)
 a88:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 a8a:	00001797          	auipc	a5,0x1
 a8e:	58678793          	addi	a5,a5,1414 # 2010 <base>
 a92:	00001717          	auipc	a4,0x1
 a96:	56f73723          	sd	a5,1390(a4) # 2000 <freep>
 a9a:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a9c:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 aa0:	b7c1                	j	a60 <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 aa2:	6398                	ld	a4,0(a5)
 aa4:	e118                	sd	a4,0(a0)
 aa6:	a8a9                	j	b00 <malloc+0xd6>
  hp->s.size = nu;
 aa8:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 aac:	0541                	addi	a0,a0,16
 aae:	efbff0ef          	jal	9a8 <free>
  return freep;
 ab2:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 ab6:	c12d                	beqz	a0,b18 <malloc+0xee>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ab8:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 aba:	4798                	lw	a4,8(a5)
 abc:	02977263          	bgeu	a4,s1,ae0 <malloc+0xb6>
    if(p == freep)
 ac0:	00093703          	ld	a4,0(s2)
 ac4:	853e                	mv	a0,a5
 ac6:	fef719e3          	bne	a4,a5,ab8 <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 aca:	8552                	mv	a0,s4
 acc:	a3fff0ef          	jal	50a <sbrk>
  if(p == SBRK_ERROR)
 ad0:	fd551ce3          	bne	a0,s5,aa8 <malloc+0x7e>
        return 0;
 ad4:	4501                	li	a0,0
 ad6:	7902                	ld	s2,32(sp)
 ad8:	6a42                	ld	s4,16(sp)
 ada:	6aa2                	ld	s5,8(sp)
 adc:	6b02                	ld	s6,0(sp)
 ade:	a03d                	j	b0c <malloc+0xe2>
 ae0:	7902                	ld	s2,32(sp)
 ae2:	6a42                	ld	s4,16(sp)
 ae4:	6aa2                	ld	s5,8(sp)
 ae6:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 ae8:	fae48de3          	beq	s1,a4,aa2 <malloc+0x78>
        p->s.size -= nunits;
 aec:	4137073b          	subw	a4,a4,s3
 af0:	c798                	sw	a4,8(a5)
        p += p->s.size;
 af2:	02071693          	slli	a3,a4,0x20
 af6:	01c6d713          	srli	a4,a3,0x1c
 afa:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 afc:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 b00:	00001717          	auipc	a4,0x1
 b04:	50a73023          	sd	a0,1280(a4) # 2000 <freep>
      return (void*)(p + 1);
 b08:	01078513          	addi	a0,a5,16
  }
}
 b0c:	70e2                	ld	ra,56(sp)
 b0e:	7442                	ld	s0,48(sp)
 b10:	74a2                	ld	s1,40(sp)
 b12:	69e2                	ld	s3,24(sp)
 b14:	6121                	addi	sp,sp,64
 b16:	8082                	ret
 b18:	7902                	ld	s2,32(sp)
 b1a:	6a42                	ld	s4,16(sp)
 b1c:	6aa2                	ld	s5,8(sp)
 b1e:	6b02                	ld	s6,0(sp)
 b20:	b7f5                	j	b0c <malloc+0xe2>
