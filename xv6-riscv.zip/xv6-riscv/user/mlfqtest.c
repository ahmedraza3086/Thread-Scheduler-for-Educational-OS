#include "kernel/types.h"
#include "user/user.h"

void delay(int n) {
  for(volatile int i = 0; i < n; i++);
}

int main() {
  int pid, status;
  
  printf("\n=== MLFQ TEST ===\n\n");
  
  // Create CPU-bound process (uses full quantum -> demotes)
  pid = fork();
  if(pid == 0) {
    printf("CPU-bound [%d] starting\n", getpid());
    for(int i = 0; i < 20; i++) {
      printf("C");
      delay(5000000);  // Long CPU burst - will use full quantum
    }
    printf(" CPU done\n");
    exit(0);
  }
  
  delay(500000);
  
  // Create I/O-bound process (yields early -> stays high)
  pid = fork();
  if(pid == 0) {
    printf("I/O-bound [%d] starting\n", getpid());
    for(int i = 0; i < 20; i++) {
      printf("I");
      delay(500000);   // Short burst
      
      // Simulate I/O by yielding
      int pipefd[2];
      pipe(pipefd);
      if(fork() == 0) {
        write(pipefd[1], "x", 1);
        exit(0);
      }
      char buf[1];
      read(pipefd[0], buf, 1);  // This blocks briefly
      wait(0);
      close(pipefd[0]);
      close(pipefd[1]);
    }
    printf(" I/O done\n");
    exit(0);
  }
  
  // Wait for both
  wait(&status);
  wait(&status);
  
  printf("\nLook at output above:\n");
  printf("- 'I' should appear more than 'C' (higher priority)\n");
  printf("- 'C' should show demotion messages\n");
  printf("- 'I' should show promotion messages\n");
  
  exit(0);
}