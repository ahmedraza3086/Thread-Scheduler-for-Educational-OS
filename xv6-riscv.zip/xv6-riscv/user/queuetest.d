user/queuetest.o: user/queuetest.c kernel/types.h kernel/stat.h \
 user/user.h
