#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void
delay(int n)
{
  for(volatile int i = 0; i < n; i++);
}

int
main(int argc, char *argv[])
{
  int pid, status;

  if(argc > 1) {
    int q = atoi(argv[1]);
    if(setquantum(q) < 0) {
      printf("Failed to set quantum\n");
      exit(1);
    }
    printf("Quantum set to %d ticks\n", q);
  }
  printf("\nFour Processes will be made\n");
  
  pid = fork();
  if(pid == 0) {
    printf("\nA process arrived\n");
    for(int i = 0; i < 60; i++) {
      printf("A");
      delay(2000000);  // Short
    }
    printf("\nA-done\n");
    exit(0);
  }
  
  pid = fork();
  if(pid == 0) {
    printf("\nB process arrived\n");
    for(int i = 0; i < 60; i++) {
      printf("B");
      delay(4000000);  // Medium
    }
    printf("\nB-done\n");
    exit(0);
  }
  
  pid = fork();
  if(pid == 0) {
    printf("\nC process arrived\n");
    for(int i = 0; i < 60; i++) {
      printf("C");
      delay(4000000);  // Medium
    }
    printf("\nC-done\n");
    exit(0);
  }
  
  pid = fork();
  if(pid == 0) {
    printf("\nD process arrived\n");
    for(int i = 0; i < 60; i++) {
      printf("D");
      delay(300000);  // Short
    }
    printf("\nD-done\n");
    exit(0);
  }
  
  // Wait for all
  for(int i = 0; i < 4; i++)
    wait(&status);
  
  exit(0);
}