
user/_quantumtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[]) {
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	e052                	sd	s4,0(sp)
   e:	1800                	addi	s0,sp,48
  int pid;
  int p_time = 50;
  int c_time = 50;

  if(argc > 1) {
  10:	4785                	li	a5,1
  12:	04a7cc63          	blt	a5,a0,6a <main+0x6a>
      c_time = atoi(argv[3]);
      printf("Child Burst Time set to %d ticks\n", c_time);
    }
  }

  printf("\n");
  16:	00001517          	auipc	a0,0x1
  1a:	a8250513          	addi	a0,a0,-1406 # a98 <malloc+0x1aa>
  1e:	01d000ef          	jal	83a <printf>

  // Fork to create multiple processes
  pid = fork();
  22:	3d8000ef          	jal	3fa <fork>
  int p_time = 50;
  26:	03200913          	li	s2,50
  if(pid == 0) {
  2a:	10050663          	beqz	a0,136 <main+0x136>
  int p_time = 50;
  2e:	4481                	li	s1,0
    }
    exit(0);
  } else {
    // Parent process
    for(int i = 0; i < p_time; i++) {
      printf("P");
  30:	00001a17          	auipc	s4,0x1
  34:	a78a0a13          	addi	s4,s4,-1416 # aa8 <malloc+0x1ba>
  38:	05f5e9b7          	lui	s3,0x5f5e
  3c:	10098993          	addi	s3,s3,256 # 5f5e100 <base+0x5f5d0f0>
  40:	8552                	mv	a0,s4
  42:	7f8000ef          	jal	83a <printf>
  46:	87ce                	mv	a5,s3
      for(int j = 0; j < 100000000; j++);
  48:	37fd                	addiw	a5,a5,-1
  4a:	fffd                	bnez	a5,48 <main+0x48>
    for(int i = 0; i < p_time; i++) {
  4c:	2485                	addiw	s1,s1,1
  4e:	ff2499e3          	bne	s1,s2,40 <main+0x40>
    }
    wait(0);
  52:	4501                	li	a0,0
  54:	3b6000ef          	jal	40a <wait>
    printf("\n");
  58:	00001517          	auipc	a0,0x1
  5c:	a4050513          	addi	a0,a0,-1472 # a98 <malloc+0x1aa>
  60:	7da000ef          	jal	83a <printf>
    exit(0);
  64:	4501                	li	a0,0
  66:	39c000ef          	jal	402 <exit>
  6a:	89aa                	mv	s3,a0
  6c:	84ae                	mv	s1,a1
    int q = atoi(argv[1]);
  6e:	6588                	ld	a0,8(a1)
  70:	270000ef          	jal	2e0 <atoi>
  74:	892a                	mv	s2,a0
    if(setquantum(q) < 0) {
  76:	42c000ef          	jal	4a2 <setquantum>
  7a:	02054a63          	bltz	a0,ae <main+0xae>
    printf("Quantum set to %d ticks\n", q);
  7e:	85ca                	mv	a1,s2
  80:	00001517          	auipc	a0,0x1
  84:	99050513          	addi	a0,a0,-1648 # a10 <malloc+0x122>
  88:	7b2000ef          	jal	83a <printf>
  if (argc > 2) {
  8c:	4789                	li	a5,2
  int p_time = 50;
  8e:	03200913          	li	s2,50
  if (argc > 2) {
  92:	0337c763          	blt	a5,s3,c0 <main+0xc0>
  printf("\n");
  96:	00001517          	auipc	a0,0x1
  9a:	a0250513          	addi	a0,a0,-1534 # a98 <malloc+0x1aa>
  9e:	79c000ef          	jal	83a <printf>
  pid = fork();
  a2:	358000ef          	jal	3fa <fork>
  if(pid == 0) {
  a6:	c169                	beqz	a0,168 <main+0x168>
    for(int i = 0; i < p_time; i++) {
  a8:	f92043e3          	bgtz	s2,2e <main+0x2e>
  ac:	b75d                	j	52 <main+0x52>
      printf("Failed to set quantum\n");
  ae:	00001517          	auipc	a0,0x1
  b2:	94250513          	addi	a0,a0,-1726 # 9f0 <malloc+0x102>
  b6:	784000ef          	jal	83a <printf>
      exit(1);
  ba:	4505                	li	a0,1
  bc:	346000ef          	jal	402 <exit>
    if (atoi(argv[2]) <= 0) {
  c0:	6888                	ld	a0,16(s1)
  c2:	21e000ef          	jal	2e0 <atoi>
  c6:	04a05a63          	blez	a0,11a <main+0x11a>
      p_time = atoi(argv[2]);
  ca:	6888                	ld	a0,16(s1)
  cc:	214000ef          	jal	2e0 <atoi>
  d0:	892a                	mv	s2,a0
      printf("Parent Burst Time set to %d ticks\n", p_time);
  d2:	85aa                	mv	a1,a0
  d4:	00001517          	auipc	a0,0x1
  d8:	97450513          	addi	a0,a0,-1676 # a48 <malloc+0x15a>
  dc:	75e000ef          	jal	83a <printf>
  if (argc > 3) {
  e0:	478d                	li	a5,3
  e2:	fb37dae3          	bge	a5,s3,96 <main+0x96>
    if (atoi(argv[3]) <= 0) {
  e6:	6c88                	ld	a0,24(s1)
  e8:	1f8000ef          	jal	2e0 <atoi>
  ec:	02a05e63          	blez	a0,128 <main+0x128>
      c_time = atoi(argv[3]);
  f0:	6c88                	ld	a0,24(s1)
  f2:	1ee000ef          	jal	2e0 <atoi>
  f6:	89aa                	mv	s3,a0
      printf("Child Burst Time set to %d ticks\n", c_time);
  f8:	85aa                	mv	a1,a0
  fa:	00001517          	auipc	a0,0x1
  fe:	97650513          	addi	a0,a0,-1674 # a70 <malloc+0x182>
 102:	738000ef          	jal	83a <printf>
  printf("\n");
 106:	00001517          	auipc	a0,0x1
 10a:	99250513          	addi	a0,a0,-1646 # a98 <malloc+0x1aa>
 10e:	72c000ef          	jal	83a <printf>
  pid = fork();
 112:	2e8000ef          	jal	3fa <fork>
  if(pid == 0) {
 116:	c115                	beqz	a0,13a <main+0x13a>
 118:	bf41                	j	a8 <main+0xa8>
      printf("Burst Time invalid!\n");
 11a:	00001517          	auipc	a0,0x1
 11e:	91650513          	addi	a0,a0,-1770 # a30 <malloc+0x142>
 122:	718000ef          	jal	83a <printf>
 126:	bf6d                	j	e0 <main+0xe0>
      printf("Burst Time invalid!\n");
 128:	00001517          	auipc	a0,0x1
 12c:	90850513          	addi	a0,a0,-1784 # a30 <malloc+0x142>
 130:	70a000ef          	jal	83a <printf>
 134:	b78d                	j	96 <main+0x96>
  int c_time = 50;
 136:	03200993          	li	s3,50
    for(int i = 0; i < c_time; i++) {
 13a:	03305463          	blez	s3,162 <main+0x162>
  if(pid == 0) {
 13e:	4481                	li	s1,0
      printf("C");
 140:	00001a17          	auipc	s4,0x1
 144:	960a0a13          	addi	s4,s4,-1696 # aa0 <malloc+0x1b2>
 148:	05f5e937          	lui	s2,0x5f5e
 14c:	10090913          	addi	s2,s2,256 # 5f5e100 <base+0x5f5d0f0>
 150:	8552                	mv	a0,s4
 152:	6e8000ef          	jal	83a <printf>
 156:	87ca                	mv	a5,s2
      for(int j = 0; j < 100000000; j++);
 158:	37fd                	addiw	a5,a5,-1
 15a:	fffd                	bnez	a5,158 <main+0x158>
    for(int i = 0; i < c_time; i++) {
 15c:	2485                	addiw	s1,s1,1
 15e:	ff3499e3          	bne	s1,s3,150 <main+0x150>
    exit(0);
 162:	4501                	li	a0,0
 164:	29e000ef          	jal	402 <exit>
  if(pid == 0) {
 168:	03200993          	li	s3,50
 16c:	bfc9                	j	13e <main+0x13e>

000000000000016e <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 16e:	1141                	addi	sp,sp,-16
 170:	e406                	sd	ra,8(sp)
 172:	e022                	sd	s0,0(sp)
 174:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 176:	e8bff0ef          	jal	0 <main>
  exit(r);
 17a:	288000ef          	jal	402 <exit>

000000000000017e <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 17e:	1141                	addi	sp,sp,-16
 180:	e422                	sd	s0,8(sp)
 182:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 184:	87aa                	mv	a5,a0
 186:	0585                	addi	a1,a1,1
 188:	0785                	addi	a5,a5,1
 18a:	fff5c703          	lbu	a4,-1(a1)
 18e:	fee78fa3          	sb	a4,-1(a5)
 192:	fb75                	bnez	a4,186 <strcpy+0x8>
    ;
  return os;
}
 194:	6422                	ld	s0,8(sp)
 196:	0141                	addi	sp,sp,16
 198:	8082                	ret

000000000000019a <strcmp>:

int
strcmp(const char *p, const char *q)
{
 19a:	1141                	addi	sp,sp,-16
 19c:	e422                	sd	s0,8(sp)
 19e:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 1a0:	00054783          	lbu	a5,0(a0)
 1a4:	cb91                	beqz	a5,1b8 <strcmp+0x1e>
 1a6:	0005c703          	lbu	a4,0(a1)
 1aa:	00f71763          	bne	a4,a5,1b8 <strcmp+0x1e>
    p++, q++;
 1ae:	0505                	addi	a0,a0,1
 1b0:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 1b2:	00054783          	lbu	a5,0(a0)
 1b6:	fbe5                	bnez	a5,1a6 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 1b8:	0005c503          	lbu	a0,0(a1)
}
 1bc:	40a7853b          	subw	a0,a5,a0
 1c0:	6422                	ld	s0,8(sp)
 1c2:	0141                	addi	sp,sp,16
 1c4:	8082                	ret

00000000000001c6 <strlen>:

uint
strlen(const char *s)
{
 1c6:	1141                	addi	sp,sp,-16
 1c8:	e422                	sd	s0,8(sp)
 1ca:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 1cc:	00054783          	lbu	a5,0(a0)
 1d0:	cf91                	beqz	a5,1ec <strlen+0x26>
 1d2:	0505                	addi	a0,a0,1
 1d4:	87aa                	mv	a5,a0
 1d6:	86be                	mv	a3,a5
 1d8:	0785                	addi	a5,a5,1
 1da:	fff7c703          	lbu	a4,-1(a5)
 1de:	ff65                	bnez	a4,1d6 <strlen+0x10>
 1e0:	40a6853b          	subw	a0,a3,a0
 1e4:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 1e6:	6422                	ld	s0,8(sp)
 1e8:	0141                	addi	sp,sp,16
 1ea:	8082                	ret
  for(n = 0; s[n]; n++)
 1ec:	4501                	li	a0,0
 1ee:	bfe5                	j	1e6 <strlen+0x20>

00000000000001f0 <memset>:

void*
memset(void *dst, int c, uint n)
{
 1f0:	1141                	addi	sp,sp,-16
 1f2:	e422                	sd	s0,8(sp)
 1f4:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 1f6:	ca19                	beqz	a2,20c <memset+0x1c>
 1f8:	87aa                	mv	a5,a0
 1fa:	1602                	slli	a2,a2,0x20
 1fc:	9201                	srli	a2,a2,0x20
 1fe:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 202:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 206:	0785                	addi	a5,a5,1
 208:	fee79de3          	bne	a5,a4,202 <memset+0x12>
  }
  return dst;
}
 20c:	6422                	ld	s0,8(sp)
 20e:	0141                	addi	sp,sp,16
 210:	8082                	ret

0000000000000212 <strchr>:

char*
strchr(const char *s, char c)
{
 212:	1141                	addi	sp,sp,-16
 214:	e422                	sd	s0,8(sp)
 216:	0800                	addi	s0,sp,16
  for(; *s; s++)
 218:	00054783          	lbu	a5,0(a0)
 21c:	cb99                	beqz	a5,232 <strchr+0x20>
    if(*s == c)
 21e:	00f58763          	beq	a1,a5,22c <strchr+0x1a>
  for(; *s; s++)
 222:	0505                	addi	a0,a0,1
 224:	00054783          	lbu	a5,0(a0)
 228:	fbfd                	bnez	a5,21e <strchr+0xc>
      return (char*)s;
  return 0;
 22a:	4501                	li	a0,0
}
 22c:	6422                	ld	s0,8(sp)
 22e:	0141                	addi	sp,sp,16
 230:	8082                	ret
  return 0;
 232:	4501                	li	a0,0
 234:	bfe5                	j	22c <strchr+0x1a>

0000000000000236 <gets>:

char*
gets(char *buf, int max)
{
 236:	711d                	addi	sp,sp,-96
 238:	ec86                	sd	ra,88(sp)
 23a:	e8a2                	sd	s0,80(sp)
 23c:	e4a6                	sd	s1,72(sp)
 23e:	e0ca                	sd	s2,64(sp)
 240:	fc4e                	sd	s3,56(sp)
 242:	f852                	sd	s4,48(sp)
 244:	f456                	sd	s5,40(sp)
 246:	f05a                	sd	s6,32(sp)
 248:	ec5e                	sd	s7,24(sp)
 24a:	1080                	addi	s0,sp,96
 24c:	8baa                	mv	s7,a0
 24e:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 250:	892a                	mv	s2,a0
 252:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 254:	4aa9                	li	s5,10
 256:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 258:	89a6                	mv	s3,s1
 25a:	2485                	addiw	s1,s1,1
 25c:	0344d663          	bge	s1,s4,288 <gets+0x52>
    cc = read(0, &c, 1);
 260:	4605                	li	a2,1
 262:	faf40593          	addi	a1,s0,-81
 266:	4501                	li	a0,0
 268:	1b2000ef          	jal	41a <read>
    if(cc < 1)
 26c:	00a05e63          	blez	a0,288 <gets+0x52>
    buf[i++] = c;
 270:	faf44783          	lbu	a5,-81(s0)
 274:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 278:	01578763          	beq	a5,s5,286 <gets+0x50>
 27c:	0905                	addi	s2,s2,1
 27e:	fd679de3          	bne	a5,s6,258 <gets+0x22>
    buf[i++] = c;
 282:	89a6                	mv	s3,s1
 284:	a011                	j	288 <gets+0x52>
 286:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 288:	99de                	add	s3,s3,s7
 28a:	00098023          	sb	zero,0(s3)
  return buf;
}
 28e:	855e                	mv	a0,s7
 290:	60e6                	ld	ra,88(sp)
 292:	6446                	ld	s0,80(sp)
 294:	64a6                	ld	s1,72(sp)
 296:	6906                	ld	s2,64(sp)
 298:	79e2                	ld	s3,56(sp)
 29a:	7a42                	ld	s4,48(sp)
 29c:	7aa2                	ld	s5,40(sp)
 29e:	7b02                	ld	s6,32(sp)
 2a0:	6be2                	ld	s7,24(sp)
 2a2:	6125                	addi	sp,sp,96
 2a4:	8082                	ret

00000000000002a6 <stat>:

int
stat(const char *n, struct stat *st)
{
 2a6:	1101                	addi	sp,sp,-32
 2a8:	ec06                	sd	ra,24(sp)
 2aa:	e822                	sd	s0,16(sp)
 2ac:	e04a                	sd	s2,0(sp)
 2ae:	1000                	addi	s0,sp,32
 2b0:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2b2:	4581                	li	a1,0
 2b4:	18e000ef          	jal	442 <open>
  if(fd < 0)
 2b8:	02054263          	bltz	a0,2dc <stat+0x36>
 2bc:	e426                	sd	s1,8(sp)
 2be:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 2c0:	85ca                	mv	a1,s2
 2c2:	198000ef          	jal	45a <fstat>
 2c6:	892a                	mv	s2,a0
  close(fd);
 2c8:	8526                	mv	a0,s1
 2ca:	160000ef          	jal	42a <close>
  return r;
 2ce:	64a2                	ld	s1,8(sp)
}
 2d0:	854a                	mv	a0,s2
 2d2:	60e2                	ld	ra,24(sp)
 2d4:	6442                	ld	s0,16(sp)
 2d6:	6902                	ld	s2,0(sp)
 2d8:	6105                	addi	sp,sp,32
 2da:	8082                	ret
    return -1;
 2dc:	597d                	li	s2,-1
 2de:	bfcd                	j	2d0 <stat+0x2a>

00000000000002e0 <atoi>:

int
atoi(const char *s)
{
 2e0:	1141                	addi	sp,sp,-16
 2e2:	e422                	sd	s0,8(sp)
 2e4:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2e6:	00054683          	lbu	a3,0(a0)
 2ea:	fd06879b          	addiw	a5,a3,-48
 2ee:	0ff7f793          	zext.b	a5,a5
 2f2:	4625                	li	a2,9
 2f4:	02f66863          	bltu	a2,a5,324 <atoi+0x44>
 2f8:	872a                	mv	a4,a0
  n = 0;
 2fa:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 2fc:	0705                	addi	a4,a4,1
 2fe:	0025179b          	slliw	a5,a0,0x2
 302:	9fa9                	addw	a5,a5,a0
 304:	0017979b          	slliw	a5,a5,0x1
 308:	9fb5                	addw	a5,a5,a3
 30a:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 30e:	00074683          	lbu	a3,0(a4)
 312:	fd06879b          	addiw	a5,a3,-48
 316:	0ff7f793          	zext.b	a5,a5
 31a:	fef671e3          	bgeu	a2,a5,2fc <atoi+0x1c>
  return n;
}
 31e:	6422                	ld	s0,8(sp)
 320:	0141                	addi	sp,sp,16
 322:	8082                	ret
  n = 0;
 324:	4501                	li	a0,0
 326:	bfe5                	j	31e <atoi+0x3e>

0000000000000328 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 328:	1141                	addi	sp,sp,-16
 32a:	e422                	sd	s0,8(sp)
 32c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 32e:	02b57463          	bgeu	a0,a1,356 <memmove+0x2e>
    while(n-- > 0)
 332:	00c05f63          	blez	a2,350 <memmove+0x28>
 336:	1602                	slli	a2,a2,0x20
 338:	9201                	srli	a2,a2,0x20
 33a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 33e:	872a                	mv	a4,a0
      *dst++ = *src++;
 340:	0585                	addi	a1,a1,1
 342:	0705                	addi	a4,a4,1
 344:	fff5c683          	lbu	a3,-1(a1)
 348:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 34c:	fef71ae3          	bne	a4,a5,340 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 350:	6422                	ld	s0,8(sp)
 352:	0141                	addi	sp,sp,16
 354:	8082                	ret
    dst += n;
 356:	00c50733          	add	a4,a0,a2
    src += n;
 35a:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 35c:	fec05ae3          	blez	a2,350 <memmove+0x28>
 360:	fff6079b          	addiw	a5,a2,-1
 364:	1782                	slli	a5,a5,0x20
 366:	9381                	srli	a5,a5,0x20
 368:	fff7c793          	not	a5,a5
 36c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 36e:	15fd                	addi	a1,a1,-1
 370:	177d                	addi	a4,a4,-1
 372:	0005c683          	lbu	a3,0(a1)
 376:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 37a:	fee79ae3          	bne	a5,a4,36e <memmove+0x46>
 37e:	bfc9                	j	350 <memmove+0x28>

0000000000000380 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 380:	1141                	addi	sp,sp,-16
 382:	e422                	sd	s0,8(sp)
 384:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 386:	ca05                	beqz	a2,3b6 <memcmp+0x36>
 388:	fff6069b          	addiw	a3,a2,-1
 38c:	1682                	slli	a3,a3,0x20
 38e:	9281                	srli	a3,a3,0x20
 390:	0685                	addi	a3,a3,1
 392:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 394:	00054783          	lbu	a5,0(a0)
 398:	0005c703          	lbu	a4,0(a1)
 39c:	00e79863          	bne	a5,a4,3ac <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 3a0:	0505                	addi	a0,a0,1
    p2++;
 3a2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 3a4:	fed518e3          	bne	a0,a3,394 <memcmp+0x14>
  }
  return 0;
 3a8:	4501                	li	a0,0
 3aa:	a019                	j	3b0 <memcmp+0x30>
      return *p1 - *p2;
 3ac:	40e7853b          	subw	a0,a5,a4
}
 3b0:	6422                	ld	s0,8(sp)
 3b2:	0141                	addi	sp,sp,16
 3b4:	8082                	ret
  return 0;
 3b6:	4501                	li	a0,0
 3b8:	bfe5                	j	3b0 <memcmp+0x30>

00000000000003ba <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3ba:	1141                	addi	sp,sp,-16
 3bc:	e406                	sd	ra,8(sp)
 3be:	e022                	sd	s0,0(sp)
 3c0:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3c2:	f67ff0ef          	jal	328 <memmove>
}
 3c6:	60a2                	ld	ra,8(sp)
 3c8:	6402                	ld	s0,0(sp)
 3ca:	0141                	addi	sp,sp,16
 3cc:	8082                	ret

00000000000003ce <sbrk>:

char *
sbrk(int n) {
 3ce:	1141                	addi	sp,sp,-16
 3d0:	e406                	sd	ra,8(sp)
 3d2:	e022                	sd	s0,0(sp)
 3d4:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 3d6:	4585                	li	a1,1
 3d8:	0b2000ef          	jal	48a <sys_sbrk>
}
 3dc:	60a2                	ld	ra,8(sp)
 3de:	6402                	ld	s0,0(sp)
 3e0:	0141                	addi	sp,sp,16
 3e2:	8082                	ret

00000000000003e4 <sbrklazy>:

char *
sbrklazy(int n) {
 3e4:	1141                	addi	sp,sp,-16
 3e6:	e406                	sd	ra,8(sp)
 3e8:	e022                	sd	s0,0(sp)
 3ea:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 3ec:	4589                	li	a1,2
 3ee:	09c000ef          	jal	48a <sys_sbrk>
}
 3f2:	60a2                	ld	ra,8(sp)
 3f4:	6402                	ld	s0,0(sp)
 3f6:	0141                	addi	sp,sp,16
 3f8:	8082                	ret

00000000000003fa <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3fa:	4885                	li	a7,1
 ecall
 3fc:	00000073          	ecall
 ret
 400:	8082                	ret

0000000000000402 <exit>:
.global exit
exit:
 li a7, SYS_exit
 402:	4889                	li	a7,2
 ecall
 404:	00000073          	ecall
 ret
 408:	8082                	ret

000000000000040a <wait>:
.global wait
wait:
 li a7, SYS_wait
 40a:	488d                	li	a7,3
 ecall
 40c:	00000073          	ecall
 ret
 410:	8082                	ret

0000000000000412 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 412:	4891                	li	a7,4
 ecall
 414:	00000073          	ecall
 ret
 418:	8082                	ret

000000000000041a <read>:
.global read
read:
 li a7, SYS_read
 41a:	4895                	li	a7,5
 ecall
 41c:	00000073          	ecall
 ret
 420:	8082                	ret

0000000000000422 <write>:
.global write
write:
 li a7, SYS_write
 422:	48c1                	li	a7,16
 ecall
 424:	00000073          	ecall
 ret
 428:	8082                	ret

000000000000042a <close>:
.global close
close:
 li a7, SYS_close
 42a:	48d5                	li	a7,21
 ecall
 42c:	00000073          	ecall
 ret
 430:	8082                	ret

0000000000000432 <kill>:
.global kill
kill:
 li a7, SYS_kill
 432:	4899                	li	a7,6
 ecall
 434:	00000073          	ecall
 ret
 438:	8082                	ret

000000000000043a <exec>:
.global exec
exec:
 li a7, SYS_exec
 43a:	489d                	li	a7,7
 ecall
 43c:	00000073          	ecall
 ret
 440:	8082                	ret

0000000000000442 <open>:
.global open
open:
 li a7, SYS_open
 442:	48bd                	li	a7,15
 ecall
 444:	00000073          	ecall
 ret
 448:	8082                	ret

000000000000044a <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 44a:	48c5                	li	a7,17
 ecall
 44c:	00000073          	ecall
 ret
 450:	8082                	ret

0000000000000452 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 452:	48c9                	li	a7,18
 ecall
 454:	00000073          	ecall
 ret
 458:	8082                	ret

000000000000045a <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 45a:	48a1                	li	a7,8
 ecall
 45c:	00000073          	ecall
 ret
 460:	8082                	ret

0000000000000462 <link>:
.global link
link:
 li a7, SYS_link
 462:	48cd                	li	a7,19
 ecall
 464:	00000073          	ecall
 ret
 468:	8082                	ret

000000000000046a <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 46a:	48d1                	li	a7,20
 ecall
 46c:	00000073          	ecall
 ret
 470:	8082                	ret

0000000000000472 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 472:	48a5                	li	a7,9
 ecall
 474:	00000073          	ecall
 ret
 478:	8082                	ret

000000000000047a <dup>:
.global dup
dup:
 li a7, SYS_dup
 47a:	48a9                	li	a7,10
 ecall
 47c:	00000073          	ecall
 ret
 480:	8082                	ret

0000000000000482 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 482:	48ad                	li	a7,11
 ecall
 484:	00000073          	ecall
 ret
 488:	8082                	ret

000000000000048a <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 48a:	48b1                	li	a7,12
 ecall
 48c:	00000073          	ecall
 ret
 490:	8082                	ret

0000000000000492 <pause>:
.global pause
pause:
 li a7, SYS_pause
 492:	48b5                	li	a7,13
 ecall
 494:	00000073          	ecall
 ret
 498:	8082                	ret

000000000000049a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 49a:	48b9                	li	a7,14
 ecall
 49c:	00000073          	ecall
 ret
 4a0:	8082                	ret

00000000000004a2 <setquantum>:
.global setquantum
setquantum:
 li a7, SYS_setquantum
 4a2:	48d9                	li	a7,22
 ecall
 4a4:	00000073          	ecall
 ret
 4a8:	8082                	ret

00000000000004aa <ps>:
.global ps
ps:
 li a7, SYS_ps
 4aa:	48dd                	li	a7,23
 ecall
 4ac:	00000073          	ecall
 ret
 4b0:	8082                	ret

00000000000004b2 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4b2:	1101                	addi	sp,sp,-32
 4b4:	ec06                	sd	ra,24(sp)
 4b6:	e822                	sd	s0,16(sp)
 4b8:	1000                	addi	s0,sp,32
 4ba:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 4be:	4605                	li	a2,1
 4c0:	fef40593          	addi	a1,s0,-17
 4c4:	f5fff0ef          	jal	422 <write>
}
 4c8:	60e2                	ld	ra,24(sp)
 4ca:	6442                	ld	s0,16(sp)
 4cc:	6105                	addi	sp,sp,32
 4ce:	8082                	ret

00000000000004d0 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 4d0:	715d                	addi	sp,sp,-80
 4d2:	e486                	sd	ra,72(sp)
 4d4:	e0a2                	sd	s0,64(sp)
 4d6:	f84a                	sd	s2,48(sp)
 4d8:	0880                	addi	s0,sp,80
 4da:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 4dc:	c299                	beqz	a3,4e2 <printint+0x12>
 4de:	0805c363          	bltz	a1,564 <printint+0x94>
  neg = 0;
 4e2:	4881                	li	a7,0
 4e4:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 4e8:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 4ea:	00000517          	auipc	a0,0x0
 4ee:	5ce50513          	addi	a0,a0,1486 # ab8 <digits>
 4f2:	883e                	mv	a6,a5
 4f4:	2785                	addiw	a5,a5,1
 4f6:	02c5f733          	remu	a4,a1,a2
 4fa:	972a                	add	a4,a4,a0
 4fc:	00074703          	lbu	a4,0(a4)
 500:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 504:	872e                	mv	a4,a1
 506:	02c5d5b3          	divu	a1,a1,a2
 50a:	0685                	addi	a3,a3,1
 50c:	fec773e3          	bgeu	a4,a2,4f2 <printint+0x22>
  if(neg)
 510:	00088b63          	beqz	a7,526 <printint+0x56>
    buf[i++] = '-';
 514:	fd078793          	addi	a5,a5,-48
 518:	97a2                	add	a5,a5,s0
 51a:	02d00713          	li	a4,45
 51e:	fee78423          	sb	a4,-24(a5)
 522:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 526:	02f05a63          	blez	a5,55a <printint+0x8a>
 52a:	fc26                	sd	s1,56(sp)
 52c:	f44e                	sd	s3,40(sp)
 52e:	fb840713          	addi	a4,s0,-72
 532:	00f704b3          	add	s1,a4,a5
 536:	fff70993          	addi	s3,a4,-1
 53a:	99be                	add	s3,s3,a5
 53c:	37fd                	addiw	a5,a5,-1
 53e:	1782                	slli	a5,a5,0x20
 540:	9381                	srli	a5,a5,0x20
 542:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 546:	fff4c583          	lbu	a1,-1(s1)
 54a:	854a                	mv	a0,s2
 54c:	f67ff0ef          	jal	4b2 <putc>
  while(--i >= 0)
 550:	14fd                	addi	s1,s1,-1
 552:	ff349ae3          	bne	s1,s3,546 <printint+0x76>
 556:	74e2                	ld	s1,56(sp)
 558:	79a2                	ld	s3,40(sp)
}
 55a:	60a6                	ld	ra,72(sp)
 55c:	6406                	ld	s0,64(sp)
 55e:	7942                	ld	s2,48(sp)
 560:	6161                	addi	sp,sp,80
 562:	8082                	ret
    x = -xx;
 564:	40b005b3          	neg	a1,a1
    neg = 1;
 568:	4885                	li	a7,1
    x = -xx;
 56a:	bfad                	j	4e4 <printint+0x14>

000000000000056c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 56c:	711d                	addi	sp,sp,-96
 56e:	ec86                	sd	ra,88(sp)
 570:	e8a2                	sd	s0,80(sp)
 572:	e0ca                	sd	s2,64(sp)
 574:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 576:	0005c903          	lbu	s2,0(a1)
 57a:	28090663          	beqz	s2,806 <vprintf+0x29a>
 57e:	e4a6                	sd	s1,72(sp)
 580:	fc4e                	sd	s3,56(sp)
 582:	f852                	sd	s4,48(sp)
 584:	f456                	sd	s5,40(sp)
 586:	f05a                	sd	s6,32(sp)
 588:	ec5e                	sd	s7,24(sp)
 58a:	e862                	sd	s8,16(sp)
 58c:	e466                	sd	s9,8(sp)
 58e:	8b2a                	mv	s6,a0
 590:	8a2e                	mv	s4,a1
 592:	8bb2                	mv	s7,a2
  state = 0;
 594:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 596:	4481                	li	s1,0
 598:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 59a:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 59e:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5a2:	06c00c93          	li	s9,108
 5a6:	a005                	j	5c6 <vprintf+0x5a>
        putc(fd, c0);
 5a8:	85ca                	mv	a1,s2
 5aa:	855a                	mv	a0,s6
 5ac:	f07ff0ef          	jal	4b2 <putc>
 5b0:	a019                	j	5b6 <vprintf+0x4a>
    } else if(state == '%'){
 5b2:	03598263          	beq	s3,s5,5d6 <vprintf+0x6a>
  for(i = 0; fmt[i]; i++){
 5b6:	2485                	addiw	s1,s1,1
 5b8:	8726                	mv	a4,s1
 5ba:	009a07b3          	add	a5,s4,s1
 5be:	0007c903          	lbu	s2,0(a5)
 5c2:	22090a63          	beqz	s2,7f6 <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 5c6:	0009079b          	sext.w	a5,s2
    if(state == 0){
 5ca:	fe0994e3          	bnez	s3,5b2 <vprintf+0x46>
      if(c0 == '%'){
 5ce:	fd579de3          	bne	a5,s5,5a8 <vprintf+0x3c>
        state = '%';
 5d2:	89be                	mv	s3,a5
 5d4:	b7cd                	j	5b6 <vprintf+0x4a>
      if(c0) c1 = fmt[i+1] & 0xff;
 5d6:	00ea06b3          	add	a3,s4,a4
 5da:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 5de:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 5e0:	c681                	beqz	a3,5e8 <vprintf+0x7c>
 5e2:	9752                	add	a4,a4,s4
 5e4:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 5e8:	05878363          	beq	a5,s8,62e <vprintf+0xc2>
      } else if(c0 == 'l' && c1 == 'd'){
 5ec:	05978d63          	beq	a5,s9,646 <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 5f0:	07500713          	li	a4,117
 5f4:	0ee78763          	beq	a5,a4,6e2 <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 5f8:	07800713          	li	a4,120
 5fc:	12e78963          	beq	a5,a4,72e <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 600:	07000713          	li	a4,112
 604:	14e78e63          	beq	a5,a4,760 <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 608:	06300713          	li	a4,99
 60c:	18e78e63          	beq	a5,a4,7a8 <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 610:	07300713          	li	a4,115
 614:	1ae78463          	beq	a5,a4,7bc <vprintf+0x250>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 618:	02500713          	li	a4,37
 61c:	04e79563          	bne	a5,a4,666 <vprintf+0xfa>
        putc(fd, '%');
 620:	02500593          	li	a1,37
 624:	855a                	mv	a0,s6
 626:	e8dff0ef          	jal	4b2 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 62a:	4981                	li	s3,0
 62c:	b769                	j	5b6 <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 62e:	008b8913          	addi	s2,s7,8
 632:	4685                	li	a3,1
 634:	4629                	li	a2,10
 636:	000ba583          	lw	a1,0(s7)
 63a:	855a                	mv	a0,s6
 63c:	e95ff0ef          	jal	4d0 <printint>
 640:	8bca                	mv	s7,s2
      state = 0;
 642:	4981                	li	s3,0
 644:	bf8d                	j	5b6 <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'd'){
 646:	06400793          	li	a5,100
 64a:	02f68963          	beq	a3,a5,67c <vprintf+0x110>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 64e:	06c00793          	li	a5,108
 652:	04f68263          	beq	a3,a5,696 <vprintf+0x12a>
      } else if(c0 == 'l' && c1 == 'u'){
 656:	07500793          	li	a5,117
 65a:	0af68063          	beq	a3,a5,6fa <vprintf+0x18e>
      } else if(c0 == 'l' && c1 == 'x'){
 65e:	07800793          	li	a5,120
 662:	0ef68263          	beq	a3,a5,746 <vprintf+0x1da>
        putc(fd, '%');
 666:	02500593          	li	a1,37
 66a:	855a                	mv	a0,s6
 66c:	e47ff0ef          	jal	4b2 <putc>
        putc(fd, c0);
 670:	85ca                	mv	a1,s2
 672:	855a                	mv	a0,s6
 674:	e3fff0ef          	jal	4b2 <putc>
      state = 0;
 678:	4981                	li	s3,0
 67a:	bf35                	j	5b6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 67c:	008b8913          	addi	s2,s7,8
 680:	4685                	li	a3,1
 682:	4629                	li	a2,10
 684:	000bb583          	ld	a1,0(s7)
 688:	855a                	mv	a0,s6
 68a:	e47ff0ef          	jal	4d0 <printint>
        i += 1;
 68e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 690:	8bca                	mv	s7,s2
      state = 0;
 692:	4981                	li	s3,0
        i += 1;
 694:	b70d                	j	5b6 <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 696:	06400793          	li	a5,100
 69a:	02f60763          	beq	a2,a5,6c8 <vprintf+0x15c>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 69e:	07500793          	li	a5,117
 6a2:	06f60963          	beq	a2,a5,714 <vprintf+0x1a8>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6a6:	07800793          	li	a5,120
 6aa:	faf61ee3          	bne	a2,a5,666 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ae:	008b8913          	addi	s2,s7,8
 6b2:	4681                	li	a3,0
 6b4:	4641                	li	a2,16
 6b6:	000bb583          	ld	a1,0(s7)
 6ba:	855a                	mv	a0,s6
 6bc:	e15ff0ef          	jal	4d0 <printint>
        i += 2;
 6c0:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6c2:	8bca                	mv	s7,s2
      state = 0;
 6c4:	4981                	li	s3,0
        i += 2;
 6c6:	bdc5                	j	5b6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6c8:	008b8913          	addi	s2,s7,8
 6cc:	4685                	li	a3,1
 6ce:	4629                	li	a2,10
 6d0:	000bb583          	ld	a1,0(s7)
 6d4:	855a                	mv	a0,s6
 6d6:	dfbff0ef          	jal	4d0 <printint>
        i += 2;
 6da:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 6dc:	8bca                	mv	s7,s2
      state = 0;
 6de:	4981                	li	s3,0
        i += 2;
 6e0:	bdd9                	j	5b6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 6e2:	008b8913          	addi	s2,s7,8
 6e6:	4681                	li	a3,0
 6e8:	4629                	li	a2,10
 6ea:	000be583          	lwu	a1,0(s7)
 6ee:	855a                	mv	a0,s6
 6f0:	de1ff0ef          	jal	4d0 <printint>
 6f4:	8bca                	mv	s7,s2
      state = 0;
 6f6:	4981                	li	s3,0
 6f8:	bd7d                	j	5b6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6fa:	008b8913          	addi	s2,s7,8
 6fe:	4681                	li	a3,0
 700:	4629                	li	a2,10
 702:	000bb583          	ld	a1,0(s7)
 706:	855a                	mv	a0,s6
 708:	dc9ff0ef          	jal	4d0 <printint>
        i += 1;
 70c:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 70e:	8bca                	mv	s7,s2
      state = 0;
 710:	4981                	li	s3,0
        i += 1;
 712:	b555                	j	5b6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 714:	008b8913          	addi	s2,s7,8
 718:	4681                	li	a3,0
 71a:	4629                	li	a2,10
 71c:	000bb583          	ld	a1,0(s7)
 720:	855a                	mv	a0,s6
 722:	dafff0ef          	jal	4d0 <printint>
        i += 2;
 726:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 728:	8bca                	mv	s7,s2
      state = 0;
 72a:	4981                	li	s3,0
        i += 2;
 72c:	b569                	j	5b6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 72e:	008b8913          	addi	s2,s7,8
 732:	4681                	li	a3,0
 734:	4641                	li	a2,16
 736:	000be583          	lwu	a1,0(s7)
 73a:	855a                	mv	a0,s6
 73c:	d95ff0ef          	jal	4d0 <printint>
 740:	8bca                	mv	s7,s2
      state = 0;
 742:	4981                	li	s3,0
 744:	bd8d                	j	5b6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 746:	008b8913          	addi	s2,s7,8
 74a:	4681                	li	a3,0
 74c:	4641                	li	a2,16
 74e:	000bb583          	ld	a1,0(s7)
 752:	855a                	mv	a0,s6
 754:	d7dff0ef          	jal	4d0 <printint>
        i += 1;
 758:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 75a:	8bca                	mv	s7,s2
      state = 0;
 75c:	4981                	li	s3,0
        i += 1;
 75e:	bda1                	j	5b6 <vprintf+0x4a>
 760:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 762:	008b8d13          	addi	s10,s7,8
 766:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 76a:	03000593          	li	a1,48
 76e:	855a                	mv	a0,s6
 770:	d43ff0ef          	jal	4b2 <putc>
  putc(fd, 'x');
 774:	07800593          	li	a1,120
 778:	855a                	mv	a0,s6
 77a:	d39ff0ef          	jal	4b2 <putc>
 77e:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 780:	00000b97          	auipc	s7,0x0
 784:	338b8b93          	addi	s7,s7,824 # ab8 <digits>
 788:	03c9d793          	srli	a5,s3,0x3c
 78c:	97de                	add	a5,a5,s7
 78e:	0007c583          	lbu	a1,0(a5)
 792:	855a                	mv	a0,s6
 794:	d1fff0ef          	jal	4b2 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 798:	0992                	slli	s3,s3,0x4
 79a:	397d                	addiw	s2,s2,-1
 79c:	fe0916e3          	bnez	s2,788 <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 7a0:	8bea                	mv	s7,s10
      state = 0;
 7a2:	4981                	li	s3,0
 7a4:	6d02                	ld	s10,0(sp)
 7a6:	bd01                	j	5b6 <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 7a8:	008b8913          	addi	s2,s7,8
 7ac:	000bc583          	lbu	a1,0(s7)
 7b0:	855a                	mv	a0,s6
 7b2:	d01ff0ef          	jal	4b2 <putc>
 7b6:	8bca                	mv	s7,s2
      state = 0;
 7b8:	4981                	li	s3,0
 7ba:	bbf5                	j	5b6 <vprintf+0x4a>
        if((s = va_arg(ap, char*)) == 0)
 7bc:	008b8993          	addi	s3,s7,8
 7c0:	000bb903          	ld	s2,0(s7)
 7c4:	00090f63          	beqz	s2,7e2 <vprintf+0x276>
        for(; *s; s++)
 7c8:	00094583          	lbu	a1,0(s2)
 7cc:	c195                	beqz	a1,7f0 <vprintf+0x284>
          putc(fd, *s);
 7ce:	855a                	mv	a0,s6
 7d0:	ce3ff0ef          	jal	4b2 <putc>
        for(; *s; s++)
 7d4:	0905                	addi	s2,s2,1
 7d6:	00094583          	lbu	a1,0(s2)
 7da:	f9f5                	bnez	a1,7ce <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 7dc:	8bce                	mv	s7,s3
      state = 0;
 7de:	4981                	li	s3,0
 7e0:	bbd9                	j	5b6 <vprintf+0x4a>
          s = "(null)";
 7e2:	00000917          	auipc	s2,0x0
 7e6:	2ce90913          	addi	s2,s2,718 # ab0 <malloc+0x1c2>
        for(; *s; s++)
 7ea:	02800593          	li	a1,40
 7ee:	b7c5                	j	7ce <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 7f0:	8bce                	mv	s7,s3
      state = 0;
 7f2:	4981                	li	s3,0
 7f4:	b3c9                	j	5b6 <vprintf+0x4a>
 7f6:	64a6                	ld	s1,72(sp)
 7f8:	79e2                	ld	s3,56(sp)
 7fa:	7a42                	ld	s4,48(sp)
 7fc:	7aa2                	ld	s5,40(sp)
 7fe:	7b02                	ld	s6,32(sp)
 800:	6be2                	ld	s7,24(sp)
 802:	6c42                	ld	s8,16(sp)
 804:	6ca2                	ld	s9,8(sp)
    }
  }
}
 806:	60e6                	ld	ra,88(sp)
 808:	6446                	ld	s0,80(sp)
 80a:	6906                	ld	s2,64(sp)
 80c:	6125                	addi	sp,sp,96
 80e:	8082                	ret

0000000000000810 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 810:	715d                	addi	sp,sp,-80
 812:	ec06                	sd	ra,24(sp)
 814:	e822                	sd	s0,16(sp)
 816:	1000                	addi	s0,sp,32
 818:	e010                	sd	a2,0(s0)
 81a:	e414                	sd	a3,8(s0)
 81c:	e818                	sd	a4,16(s0)
 81e:	ec1c                	sd	a5,24(s0)
 820:	03043023          	sd	a6,32(s0)
 824:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 828:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 82c:	8622                	mv	a2,s0
 82e:	d3fff0ef          	jal	56c <vprintf>
}
 832:	60e2                	ld	ra,24(sp)
 834:	6442                	ld	s0,16(sp)
 836:	6161                	addi	sp,sp,80
 838:	8082                	ret

000000000000083a <printf>:

void
printf(const char *fmt, ...)
{
 83a:	711d                	addi	sp,sp,-96
 83c:	ec06                	sd	ra,24(sp)
 83e:	e822                	sd	s0,16(sp)
 840:	1000                	addi	s0,sp,32
 842:	e40c                	sd	a1,8(s0)
 844:	e810                	sd	a2,16(s0)
 846:	ec14                	sd	a3,24(s0)
 848:	f018                	sd	a4,32(s0)
 84a:	f41c                	sd	a5,40(s0)
 84c:	03043823          	sd	a6,48(s0)
 850:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 854:	00840613          	addi	a2,s0,8
 858:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 85c:	85aa                	mv	a1,a0
 85e:	4505                	li	a0,1
 860:	d0dff0ef          	jal	56c <vprintf>
}
 864:	60e2                	ld	ra,24(sp)
 866:	6442                	ld	s0,16(sp)
 868:	6125                	addi	sp,sp,96
 86a:	8082                	ret

000000000000086c <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 86c:	1141                	addi	sp,sp,-16
 86e:	e422                	sd	s0,8(sp)
 870:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 872:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 876:	00000797          	auipc	a5,0x0
 87a:	78a7b783          	ld	a5,1930(a5) # 1000 <freep>
 87e:	a02d                	j	8a8 <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 880:	4618                	lw	a4,8(a2)
 882:	9f2d                	addw	a4,a4,a1
 884:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 888:	6398                	ld	a4,0(a5)
 88a:	6310                	ld	a2,0(a4)
 88c:	a83d                	j	8ca <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 88e:	ff852703          	lw	a4,-8(a0)
 892:	9f31                	addw	a4,a4,a2
 894:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 896:	ff053683          	ld	a3,-16(a0)
 89a:	a091                	j	8de <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 89c:	6398                	ld	a4,0(a5)
 89e:	00e7e463          	bltu	a5,a4,8a6 <free+0x3a>
 8a2:	00e6ea63          	bltu	a3,a4,8b6 <free+0x4a>
{
 8a6:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8a8:	fed7fae3          	bgeu	a5,a3,89c <free+0x30>
 8ac:	6398                	ld	a4,0(a5)
 8ae:	00e6e463          	bltu	a3,a4,8b6 <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8b2:	fee7eae3          	bltu	a5,a4,8a6 <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 8b6:	ff852583          	lw	a1,-8(a0)
 8ba:	6390                	ld	a2,0(a5)
 8bc:	02059813          	slli	a6,a1,0x20
 8c0:	01c85713          	srli	a4,a6,0x1c
 8c4:	9736                	add	a4,a4,a3
 8c6:	fae60de3          	beq	a2,a4,880 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 8ca:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 8ce:	4790                	lw	a2,8(a5)
 8d0:	02061593          	slli	a1,a2,0x20
 8d4:	01c5d713          	srli	a4,a1,0x1c
 8d8:	973e                	add	a4,a4,a5
 8da:	fae68ae3          	beq	a3,a4,88e <free+0x22>
    p->s.ptr = bp->s.ptr;
 8de:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 8e0:	00000717          	auipc	a4,0x0
 8e4:	72f73023          	sd	a5,1824(a4) # 1000 <freep>
}
 8e8:	6422                	ld	s0,8(sp)
 8ea:	0141                	addi	sp,sp,16
 8ec:	8082                	ret

00000000000008ee <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8ee:	7139                	addi	sp,sp,-64
 8f0:	fc06                	sd	ra,56(sp)
 8f2:	f822                	sd	s0,48(sp)
 8f4:	f426                	sd	s1,40(sp)
 8f6:	ec4e                	sd	s3,24(sp)
 8f8:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 8fa:	02051493          	slli	s1,a0,0x20
 8fe:	9081                	srli	s1,s1,0x20
 900:	04bd                	addi	s1,s1,15
 902:	8091                	srli	s1,s1,0x4
 904:	0014899b          	addiw	s3,s1,1
 908:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 90a:	00000517          	auipc	a0,0x0
 90e:	6f653503          	ld	a0,1782(a0) # 1000 <freep>
 912:	c915                	beqz	a0,946 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 914:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 916:	4798                	lw	a4,8(a5)
 918:	08977a63          	bgeu	a4,s1,9ac <malloc+0xbe>
 91c:	f04a                	sd	s2,32(sp)
 91e:	e852                	sd	s4,16(sp)
 920:	e456                	sd	s5,8(sp)
 922:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 924:	8a4e                	mv	s4,s3
 926:	0009871b          	sext.w	a4,s3
 92a:	6685                	lui	a3,0x1
 92c:	00d77363          	bgeu	a4,a3,932 <malloc+0x44>
 930:	6a05                	lui	s4,0x1
 932:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 936:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 93a:	00000917          	auipc	s2,0x0
 93e:	6c690913          	addi	s2,s2,1734 # 1000 <freep>
  if(p == SBRK_ERROR)
 942:	5afd                	li	s5,-1
 944:	a081                	j	984 <malloc+0x96>
 946:	f04a                	sd	s2,32(sp)
 948:	e852                	sd	s4,16(sp)
 94a:	e456                	sd	s5,8(sp)
 94c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 94e:	00000797          	auipc	a5,0x0
 952:	6c278793          	addi	a5,a5,1730 # 1010 <base>
 956:	00000717          	auipc	a4,0x0
 95a:	6af73523          	sd	a5,1706(a4) # 1000 <freep>
 95e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 960:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 964:	b7c1                	j	924 <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 966:	6398                	ld	a4,0(a5)
 968:	e118                	sd	a4,0(a0)
 96a:	a8a9                	j	9c4 <malloc+0xd6>
  hp->s.size = nu;
 96c:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 970:	0541                	addi	a0,a0,16
 972:	efbff0ef          	jal	86c <free>
  return freep;
 976:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 97a:	c12d                	beqz	a0,9dc <malloc+0xee>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 97c:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 97e:	4798                	lw	a4,8(a5)
 980:	02977263          	bgeu	a4,s1,9a4 <malloc+0xb6>
    if(p == freep)
 984:	00093703          	ld	a4,0(s2)
 988:	853e                	mv	a0,a5
 98a:	fef719e3          	bne	a4,a5,97c <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 98e:	8552                	mv	a0,s4
 990:	a3fff0ef          	jal	3ce <sbrk>
  if(p == SBRK_ERROR)
 994:	fd551ce3          	bne	a0,s5,96c <malloc+0x7e>
        return 0;
 998:	4501                	li	a0,0
 99a:	7902                	ld	s2,32(sp)
 99c:	6a42                	ld	s4,16(sp)
 99e:	6aa2                	ld	s5,8(sp)
 9a0:	6b02                	ld	s6,0(sp)
 9a2:	a03d                	j	9d0 <malloc+0xe2>
 9a4:	7902                	ld	s2,32(sp)
 9a6:	6a42                	ld	s4,16(sp)
 9a8:	6aa2                	ld	s5,8(sp)
 9aa:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 9ac:	fae48de3          	beq	s1,a4,966 <malloc+0x78>
        p->s.size -= nunits;
 9b0:	4137073b          	subw	a4,a4,s3
 9b4:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9b6:	02071693          	slli	a3,a4,0x20
 9ba:	01c6d713          	srli	a4,a3,0x1c
 9be:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9c0:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9c4:	00000717          	auipc	a4,0x0
 9c8:	62a73e23          	sd	a0,1596(a4) # 1000 <freep>
      return (void*)(p + 1);
 9cc:	01078513          	addi	a0,a5,16
  }
}
 9d0:	70e2                	ld	ra,56(sp)
 9d2:	7442                	ld	s0,48(sp)
 9d4:	74a2                	ld	s1,40(sp)
 9d6:	69e2                	ld	s3,24(sp)
 9d8:	6121                	addi	sp,sp,64
 9da:	8082                	ret
 9dc:	7902                	ld	s2,32(sp)
 9de:	6a42                	ld	s4,16(sp)
 9e0:	6aa2                	ld	s5,8(sp)
 9e2:	6b02                	ld	s6,0(sp)
 9e4:	b7f5                	j	9d0 <malloc+0xe2>
