#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void delay(int n) {
  for(volatile int i = 0; i < n; i++);
}

int main(int argc, char *argv[]) {
  int pid, status;
  int p_count = 3;

  if (argc > 1) {
    if (atoi(argv[1]) > 2) {
      p_count = atoi(argv[1]);
    } else {
      printf("\nProcess count must be higher than 2, defaulting to 3...\n");
    }
  }

  for(int i = 0; i < p_count; i++) {
    pid = fork();
    if(pid == 0) {
      printf("\nProcess %d arrived\n", getpid());
      for(int j = 0; j < 60; j++) {
        printf("%d", getpid() % 10);
        delay(5000000);
      }
      printf("\nProcess %d done\n", getpid());
      exit(0);
    }
  }
  
  for(int i = 0; i < 3; i++)
    wait(&status);
  
  exit(0);
}