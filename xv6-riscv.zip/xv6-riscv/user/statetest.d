user/statetest.o: user/statetest.c kernel/types.h kernel/stat.h \
 user/user.h
