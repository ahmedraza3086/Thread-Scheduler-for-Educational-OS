user/agingtest.o: user/agingtest.c kernel/types.h kernel/stat.h \
 user/user.h
