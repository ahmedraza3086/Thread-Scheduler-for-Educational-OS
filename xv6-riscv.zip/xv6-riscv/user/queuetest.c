#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  int pid;
  int c_count = 3;
  
  printf("Starting queue test...\n");

  if(argc > 1) {
    if(atoi(argv[1]) > 2) {
      printf("\nChild count set to: %d\n", atoi(argv[1]));
      c_count = atoi(argv[1]);
    } else {
      printf("\nChild count must be greater than 2: defaulting to 3...\n");
    }
  }

  for(int i = 0; i < c_count; i++) {
    pid = fork();
    if(pid == 0) {
      // Child process
      printf("\nChild %d starting\n", getpid());
      for(int j = 0; j < 20; j++) {
        printf("%d", getpid() % 10);
        for(int k = 0; k < 100000000; k++);  // Busy loop
      }
      printf("\nChild %d done\n", getpid());
      exit(0);
    } else {
      printf("\nParent created child %d\n", pid);
    }
  }
  
  // Parent waits for all children
  for(int i = 0; i < 3; i++) {
    wait(0);
  }
  
  printf("All children finished\n");
  exit(0);
}
