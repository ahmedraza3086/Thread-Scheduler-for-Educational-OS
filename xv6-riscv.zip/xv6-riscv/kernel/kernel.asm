
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000a117          	auipc	sp,0xa
    80000004:	25813103          	ld	sp,600(sp) # 8000a258 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04a000ef          	jal	80000060 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000022:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000026:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002a:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    8000002e:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000032:	577d                	li	a4,-1
    80000034:	177e                	slli	a4,a4,0x3f
    80000036:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80000038:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000040:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000044:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    80000048:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004c:	000f4737          	lui	a4,0xf4
    80000050:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000054:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000056:	14d79073          	csrw	stimecmp,a5
}
    8000005a:	6422                	ld	s0,8(sp)
    8000005c:	0141                	addi	sp,sp,16
    8000005e:	8082                	ret

0000000080000060 <start>:
{
    80000060:	1141                	addi	sp,sp,-16
    80000062:	e406                	sd	ra,8(sp)
    80000064:	e022                	sd	s0,0(sp)
    80000066:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000068:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000006c:	7779                	lui	a4,0xffffe
    8000006e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdae57>
    80000072:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000074:	6705                	lui	a4,0x1
    80000076:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    8000007c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000080:	00001797          	auipc	a5,0x1
    80000084:	dbc78793          	addi	a5,a5,-580 # 80000e3c <main>
    80000088:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    8000008c:	4781                	li	a5,0
    8000008e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000092:	67c1                	lui	a5,0x10
    80000094:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80000096:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    8000009e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a2:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000a6:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000aa:	57fd                	li	a5,-1
    800000ac:	83a9                	srli	a5,a5,0xa
    800000ae:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b2:	47bd                	li	a5,15
    800000b4:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000b8:	f65ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000bc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c4:	30200073          	mret
}
    800000c8:	60a2                	ld	ra,8(sp)
    800000ca:	6402                	ld	s0,0(sp)
    800000cc:	0141                	addi	sp,sp,16
    800000ce:	8082                	ret

00000000800000d0 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d0:	7119                	addi	sp,sp,-128
    800000d2:	fc86                	sd	ra,120(sp)
    800000d4:	f8a2                	sd	s0,112(sp)
    800000d6:	f4a6                	sd	s1,104(sp)
    800000d8:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while(i < n){
    800000da:	06c05a63          	blez	a2,8000014e <consolewrite+0x7e>
    800000de:	f0ca                	sd	s2,96(sp)
    800000e0:	ecce                	sd	s3,88(sp)
    800000e2:	e8d2                	sd	s4,80(sp)
    800000e4:	e4d6                	sd	s5,72(sp)
    800000e6:	e0da                	sd	s6,64(sp)
    800000e8:	fc5e                	sd	s7,56(sp)
    800000ea:	f862                	sd	s8,48(sp)
    800000ec:	f466                	sd	s9,40(sp)
    800000ee:	8aaa                	mv	s5,a0
    800000f0:	8b2e                	mv	s6,a1
    800000f2:	8a32                	mv	s4,a2
  int i = 0;
    800000f4:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000f6:	02000c13          	li	s8,32
    800000fa:	02000c93          	li	s9,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    800000fe:	5bfd                	li	s7,-1
    80000100:	a035                	j	8000012c <consolewrite+0x5c>
    if(nn > n - i)
    80000102:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000106:	86ce                	mv	a3,s3
    80000108:	01648633          	add	a2,s1,s6
    8000010c:	85d6                	mv	a1,s5
    8000010e:	f8040513          	addi	a0,s0,-128
    80000112:	17e020ef          	jal	80002290 <either_copyin>
    80000116:	03750e63          	beq	a0,s7,80000152 <consolewrite+0x82>
      break;
    uartwrite(buf, nn);
    8000011a:	85ce                	mv	a1,s3
    8000011c:	f8040513          	addi	a0,s0,-128
    80000120:	778000ef          	jal	80000898 <uartwrite>
    i += nn;
    80000124:	009904bb          	addw	s1,s2,s1
  while(i < n){
    80000128:	0144da63          	bge	s1,s4,8000013c <consolewrite+0x6c>
    if(nn > n - i)
    8000012c:	409a093b          	subw	s2,s4,s1
    80000130:	0009079b          	sext.w	a5,s2
    80000134:	fcfc57e3          	bge	s8,a5,80000102 <consolewrite+0x32>
    80000138:	8966                	mv	s2,s9
    8000013a:	b7e1                	j	80000102 <consolewrite+0x32>
    8000013c:	7906                	ld	s2,96(sp)
    8000013e:	69e6                	ld	s3,88(sp)
    80000140:	6a46                	ld	s4,80(sp)
    80000142:	6aa6                	ld	s5,72(sp)
    80000144:	6b06                	ld	s6,64(sp)
    80000146:	7be2                	ld	s7,56(sp)
    80000148:	7c42                	ld	s8,48(sp)
    8000014a:	7ca2                	ld	s9,40(sp)
    8000014c:	a819                	j	80000162 <consolewrite+0x92>
  int i = 0;
    8000014e:	4481                	li	s1,0
    80000150:	a809                	j	80000162 <consolewrite+0x92>
    80000152:	7906                	ld	s2,96(sp)
    80000154:	69e6                	ld	s3,88(sp)
    80000156:	6a46                	ld	s4,80(sp)
    80000158:	6aa6                	ld	s5,72(sp)
    8000015a:	6b06                	ld	s6,64(sp)
    8000015c:	7be2                	ld	s7,56(sp)
    8000015e:	7c42                	ld	s8,48(sp)
    80000160:	7ca2                	ld	s9,40(sp)
  }

  return i;
}
    80000162:	8526                	mv	a0,s1
    80000164:	70e6                	ld	ra,120(sp)
    80000166:	7446                	ld	s0,112(sp)
    80000168:	74a6                	ld	s1,104(sp)
    8000016a:	6109                	addi	sp,sp,128
    8000016c:	8082                	ret

000000008000016e <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000016e:	711d                	addi	sp,sp,-96
    80000170:	ec86                	sd	ra,88(sp)
    80000172:	e8a2                	sd	s0,80(sp)
    80000174:	e4a6                	sd	s1,72(sp)
    80000176:	e0ca                	sd	s2,64(sp)
    80000178:	fc4e                	sd	s3,56(sp)
    8000017a:	f852                	sd	s4,48(sp)
    8000017c:	f456                	sd	s5,40(sp)
    8000017e:	f05a                	sd	s6,32(sp)
    80000180:	1080                	addi	s0,sp,96
    80000182:	8aaa                	mv	s5,a0
    80000184:	8a2e                	mv	s4,a1
    80000186:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000188:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018c:	00012517          	auipc	a0,0x12
    80000190:	11450513          	addi	a0,a0,276 # 800122a0 <cons>
    80000194:	23b000ef          	jal	80000bce <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80000198:	00012497          	auipc	s1,0x12
    8000019c:	10848493          	addi	s1,s1,264 # 800122a0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a0:	00012917          	auipc	s2,0x12
    800001a4:	19890913          	addi	s2,s2,408 # 80012338 <cons+0x98>
  while(n > 0){
    800001a8:	0b305d63          	blez	s3,80000262 <consoleread+0xf4>
    while(cons.r == cons.w){
    800001ac:	0984a783          	lw	a5,152(s1)
    800001b0:	09c4a703          	lw	a4,156(s1)
    800001b4:	0af71263          	bne	a4,a5,80000258 <consoleread+0xea>
      if(killed(myproc())){
    800001b8:	716010ef          	jal	800018ce <myproc>
    800001bc:	767010ef          	jal	80002122 <killed>
    800001c0:	e12d                	bnez	a0,80000222 <consoleread+0xb4>
      sleep(&cons.r, &cons.lock);
    800001c2:	85a6                	mv	a1,s1
    800001c4:	854a                	mv	a0,s2
    800001c6:	525010ef          	jal	80001eea <sleep>
    while(cons.r == cons.w){
    800001ca:	0984a783          	lw	a5,152(s1)
    800001ce:	09c4a703          	lw	a4,156(s1)
    800001d2:	fef703e3          	beq	a4,a5,800001b8 <consoleread+0x4a>
    800001d6:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001d8:	00012717          	auipc	a4,0x12
    800001dc:	0c870713          	addi	a4,a4,200 # 800122a0 <cons>
    800001e0:	0017869b          	addiw	a3,a5,1
    800001e4:	08d72c23          	sw	a3,152(a4)
    800001e8:	07f7f693          	andi	a3,a5,127
    800001ec:	9736                	add	a4,a4,a3
    800001ee:	01874703          	lbu	a4,24(a4)
    800001f2:	00070b9b          	sext.w	s7,a4

    if(c == C('D')){  // end-of-file
    800001f6:	4691                	li	a3,4
    800001f8:	04db8663          	beq	s7,a3,80000244 <consoleread+0xd6>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800001fc:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000200:	4685                	li	a3,1
    80000202:	faf40613          	addi	a2,s0,-81
    80000206:	85d2                	mv	a1,s4
    80000208:	8556                	mv	a0,s5
    8000020a:	03c020ef          	jal	80002246 <either_copyout>
    8000020e:	57fd                	li	a5,-1
    80000210:	04f50863          	beq	a0,a5,80000260 <consoleread+0xf2>
      break;

    dst++;
    80000214:	0a05                	addi	s4,s4,1
    --n;
    80000216:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80000218:	47a9                	li	a5,10
    8000021a:	04fb8d63          	beq	s7,a5,80000274 <consoleread+0x106>
    8000021e:	6be2                	ld	s7,24(sp)
    80000220:	b761                	j	800001a8 <consoleread+0x3a>
        release(&cons.lock);
    80000222:	00012517          	auipc	a0,0x12
    80000226:	07e50513          	addi	a0,a0,126 # 800122a0 <cons>
    8000022a:	23d000ef          	jal	80000c66 <release>
        return -1;
    8000022e:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000230:	60e6                	ld	ra,88(sp)
    80000232:	6446                	ld	s0,80(sp)
    80000234:	64a6                	ld	s1,72(sp)
    80000236:	6906                	ld	s2,64(sp)
    80000238:	79e2                	ld	s3,56(sp)
    8000023a:	7a42                	ld	s4,48(sp)
    8000023c:	7aa2                	ld	s5,40(sp)
    8000023e:	7b02                	ld	s6,32(sp)
    80000240:	6125                	addi	sp,sp,96
    80000242:	8082                	ret
      if(n < target){
    80000244:	0009871b          	sext.w	a4,s3
    80000248:	01677a63          	bgeu	a4,s6,8000025c <consoleread+0xee>
        cons.r--;
    8000024c:	00012717          	auipc	a4,0x12
    80000250:	0ef72623          	sw	a5,236(a4) # 80012338 <cons+0x98>
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	a031                	j	80000262 <consoleread+0xf4>
    80000258:	ec5e                	sd	s7,24(sp)
    8000025a:	bfbd                	j	800001d8 <consoleread+0x6a>
    8000025c:	6be2                	ld	s7,24(sp)
    8000025e:	a011                	j	80000262 <consoleread+0xf4>
    80000260:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    80000262:	00012517          	auipc	a0,0x12
    80000266:	03e50513          	addi	a0,a0,62 # 800122a0 <cons>
    8000026a:	1fd000ef          	jal	80000c66 <release>
  return target - n;
    8000026e:	413b053b          	subw	a0,s6,s3
    80000272:	bf7d                	j	80000230 <consoleread+0xc2>
    80000274:	6be2                	ld	s7,24(sp)
    80000276:	b7f5                	j	80000262 <consoleread+0xf4>

0000000080000278 <consputc>:
{
    80000278:	1141                	addi	sp,sp,-16
    8000027a:	e406                	sd	ra,8(sp)
    8000027c:	e022                	sd	s0,0(sp)
    8000027e:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000280:	10000793          	li	a5,256
    80000284:	00f50863          	beq	a0,a5,80000294 <consputc+0x1c>
    uartputc_sync(c);
    80000288:	6a4000ef          	jal	8000092c <uartputc_sync>
}
    8000028c:	60a2                	ld	ra,8(sp)
    8000028e:	6402                	ld	s0,0(sp)
    80000290:	0141                	addi	sp,sp,16
    80000292:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000294:	4521                	li	a0,8
    80000296:	696000ef          	jal	8000092c <uartputc_sync>
    8000029a:	02000513          	li	a0,32
    8000029e:	68e000ef          	jal	8000092c <uartputc_sync>
    800002a2:	4521                	li	a0,8
    800002a4:	688000ef          	jal	8000092c <uartputc_sync>
    800002a8:	b7d5                	j	8000028c <consputc+0x14>

00000000800002aa <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002aa:	1101                	addi	sp,sp,-32
    800002ac:	ec06                	sd	ra,24(sp)
    800002ae:	e822                	sd	s0,16(sp)
    800002b0:	e426                	sd	s1,8(sp)
    800002b2:	1000                	addi	s0,sp,32
    800002b4:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b6:	00012517          	auipc	a0,0x12
    800002ba:	fea50513          	addi	a0,a0,-22 # 800122a0 <cons>
    800002be:	111000ef          	jal	80000bce <acquire>

  switch(c){
    800002c2:	47d5                	li	a5,21
    800002c4:	08f48f63          	beq	s1,a5,80000362 <consoleintr+0xb8>
    800002c8:	0297c563          	blt	a5,s1,800002f2 <consoleintr+0x48>
    800002cc:	47a1                	li	a5,8
    800002ce:	0ef48463          	beq	s1,a5,800003b6 <consoleintr+0x10c>
    800002d2:	47c1                	li	a5,16
    800002d4:	10f49563          	bne	s1,a5,800003de <consoleintr+0x134>
  case C('P'):  // Print process list.
    procdump();
    800002d8:	002020ef          	jal	800022da <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002dc:	00012517          	auipc	a0,0x12
    800002e0:	fc450513          	addi	a0,a0,-60 # 800122a0 <cons>
    800002e4:	183000ef          	jal	80000c66 <release>
}
    800002e8:	60e2                	ld	ra,24(sp)
    800002ea:	6442                	ld	s0,16(sp)
    800002ec:	64a2                	ld	s1,8(sp)
    800002ee:	6105                	addi	sp,sp,32
    800002f0:	8082                	ret
  switch(c){
    800002f2:	07f00793          	li	a5,127
    800002f6:	0cf48063          	beq	s1,a5,800003b6 <consoleintr+0x10c>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fa:	00012717          	auipc	a4,0x12
    800002fe:	fa670713          	addi	a4,a4,-90 # 800122a0 <cons>
    80000302:	0a072783          	lw	a5,160(a4)
    80000306:	09872703          	lw	a4,152(a4)
    8000030a:	9f99                	subw	a5,a5,a4
    8000030c:	07f00713          	li	a4,127
    80000310:	fcf766e3          	bltu	a4,a5,800002dc <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000314:	47b5                	li	a5,13
    80000316:	0cf48763          	beq	s1,a5,800003e4 <consoleintr+0x13a>
      consputc(c);
    8000031a:	8526                	mv	a0,s1
    8000031c:	f5dff0ef          	jal	80000278 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000320:	00012797          	auipc	a5,0x12
    80000324:	f8078793          	addi	a5,a5,-128 # 800122a0 <cons>
    80000328:	0a07a683          	lw	a3,160(a5)
    8000032c:	0016871b          	addiw	a4,a3,1
    80000330:	0007061b          	sext.w	a2,a4
    80000334:	0ae7a023          	sw	a4,160(a5)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	97b6                	add	a5,a5,a3
    8000033e:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	47a9                	li	a5,10
    80000344:	0cf48563          	beq	s1,a5,8000040e <consoleintr+0x164>
    80000348:	4791                	li	a5,4
    8000034a:	0cf48263          	beq	s1,a5,8000040e <consoleintr+0x164>
    8000034e:	00012797          	auipc	a5,0x12
    80000352:	fea7a783          	lw	a5,-22(a5) # 80012338 <cons+0x98>
    80000356:	9f1d                	subw	a4,a4,a5
    80000358:	08000793          	li	a5,128
    8000035c:	f8f710e3          	bne	a4,a5,800002dc <consoleintr+0x32>
    80000360:	a07d                	j	8000040e <consoleintr+0x164>
    80000362:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000364:	00012717          	auipc	a4,0x12
    80000368:	f3c70713          	addi	a4,a4,-196 # 800122a0 <cons>
    8000036c:	0a072783          	lw	a5,160(a4)
    80000370:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000374:	00012497          	auipc	s1,0x12
    80000378:	f2c48493          	addi	s1,s1,-212 # 800122a0 <cons>
    while(cons.e != cons.w &&
    8000037c:	4929                	li	s2,10
    8000037e:	02f70863          	beq	a4,a5,800003ae <consoleintr+0x104>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000382:	37fd                	addiw	a5,a5,-1
    80000384:	07f7f713          	andi	a4,a5,127
    80000388:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000038a:	01874703          	lbu	a4,24(a4)
    8000038e:	03270263          	beq	a4,s2,800003b2 <consoleintr+0x108>
      cons.e--;
    80000392:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000396:	10000513          	li	a0,256
    8000039a:	edfff0ef          	jal	80000278 <consputc>
    while(cons.e != cons.w &&
    8000039e:	0a04a783          	lw	a5,160(s1)
    800003a2:	09c4a703          	lw	a4,156(s1)
    800003a6:	fcf71ee3          	bne	a4,a5,80000382 <consoleintr+0xd8>
    800003aa:	6902                	ld	s2,0(sp)
    800003ac:	bf05                	j	800002dc <consoleintr+0x32>
    800003ae:	6902                	ld	s2,0(sp)
    800003b0:	b735                	j	800002dc <consoleintr+0x32>
    800003b2:	6902                	ld	s2,0(sp)
    800003b4:	b725                	j	800002dc <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b6:	00012717          	auipc	a4,0x12
    800003ba:	eea70713          	addi	a4,a4,-278 # 800122a0 <cons>
    800003be:	0a072783          	lw	a5,160(a4)
    800003c2:	09c72703          	lw	a4,156(a4)
    800003c6:	f0f70be3          	beq	a4,a5,800002dc <consoleintr+0x32>
      cons.e--;
    800003ca:	37fd                	addiw	a5,a5,-1
    800003cc:	00012717          	auipc	a4,0x12
    800003d0:	f6f72a23          	sw	a5,-140(a4) # 80012340 <cons+0xa0>
      consputc(BACKSPACE);
    800003d4:	10000513          	li	a0,256
    800003d8:	ea1ff0ef          	jal	80000278 <consputc>
    800003dc:	b701                	j	800002dc <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003de:	ee048fe3          	beqz	s1,800002dc <consoleintr+0x32>
    800003e2:	bf21                	j	800002fa <consoleintr+0x50>
      consputc(c);
    800003e4:	4529                	li	a0,10
    800003e6:	e93ff0ef          	jal	80000278 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003ea:	00012797          	auipc	a5,0x12
    800003ee:	eb678793          	addi	a5,a5,-330 # 800122a0 <cons>
    800003f2:	0a07a703          	lw	a4,160(a5)
    800003f6:	0017069b          	addiw	a3,a4,1
    800003fa:	0006861b          	sext.w	a2,a3
    800003fe:	0ad7a023          	sw	a3,160(a5)
    80000402:	07f77713          	andi	a4,a4,127
    80000406:	97ba                	add	a5,a5,a4
    80000408:	4729                	li	a4,10
    8000040a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040e:	00012797          	auipc	a5,0x12
    80000412:	f2c7a723          	sw	a2,-210(a5) # 8001233c <cons+0x9c>
        wakeup(&cons.r);
    80000416:	00012517          	auipc	a0,0x12
    8000041a:	f2250513          	addi	a0,a0,-222 # 80012338 <cons+0x98>
    8000041e:	319010ef          	jal	80001f36 <wakeup>
    80000422:	bd6d                	j	800002dc <consoleintr+0x32>

0000000080000424 <consoleinit>:

void
consoleinit(void)
{
    80000424:	1141                	addi	sp,sp,-16
    80000426:	e406                	sd	ra,8(sp)
    80000428:	e022                	sd	s0,0(sp)
    8000042a:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000042c:	00007597          	auipc	a1,0x7
    80000430:	bd458593          	addi	a1,a1,-1068 # 80007000 <etext>
    80000434:	00012517          	auipc	a0,0x12
    80000438:	e6c50513          	addi	a0,a0,-404 # 800122a0 <cons>
    8000043c:	712000ef          	jal	80000b4e <initlock>

  uartinit();
    80000440:	400000ef          	jal	80000840 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000444:	00022797          	auipc	a5,0x22
    80000448:	3cc78793          	addi	a5,a5,972 # 80022810 <devsw>
    8000044c:	00000717          	auipc	a4,0x0
    80000450:	d2270713          	addi	a4,a4,-734 # 8000016e <consoleread>
    80000454:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000456:	00000717          	auipc	a4,0x0
    8000045a:	c7a70713          	addi	a4,a4,-902 # 800000d0 <consolewrite>
    8000045e:	ef98                	sd	a4,24(a5)
}
    80000460:	60a2                	ld	ra,8(sp)
    80000462:	6402                	ld	s0,0(sp)
    80000464:	0141                	addi	sp,sp,16
    80000466:	8082                	ret

0000000080000468 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000468:	7139                	addi	sp,sp,-64
    8000046a:	fc06                	sd	ra,56(sp)
    8000046c:	f822                	sd	s0,48(sp)
    8000046e:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80000470:	c219                	beqz	a2,80000476 <printint+0xe>
    80000472:	08054063          	bltz	a0,800004f2 <printint+0x8a>
    x = -xx;
  else
    x = xx;
    80000476:	4881                	li	a7,0
    80000478:	fc840693          	addi	a3,s0,-56

  i = 0;
    8000047c:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00007617          	auipc	a2,0x7
    80000482:	2b260613          	addi	a2,a2,690 # 80007730 <digits>
    80000486:	883e                	mv	a6,a5
    80000488:	2785                	addiw	a5,a5,1
    8000048a:	02b57733          	remu	a4,a0,a1
    8000048e:	9732                	add	a4,a4,a2
    80000490:	00074703          	lbu	a4,0(a4)
    80000494:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80000498:	872a                	mv	a4,a0
    8000049a:	02b55533          	divu	a0,a0,a1
    8000049e:	0685                	addi	a3,a3,1
    800004a0:	feb773e3          	bgeu	a4,a1,80000486 <printint+0x1e>

  if(sign)
    800004a4:	00088a63          	beqz	a7,800004b8 <printint+0x50>
    buf[i++] = '-';
    800004a8:	1781                	addi	a5,a5,-32
    800004aa:	97a2                	add	a5,a5,s0
    800004ac:	02d00713          	li	a4,45
    800004b0:	fee78423          	sb	a4,-24(a5)
    800004b4:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    800004b8:	02f05963          	blez	a5,800004ea <printint+0x82>
    800004bc:	f426                	sd	s1,40(sp)
    800004be:	f04a                	sd	s2,32(sp)
    800004c0:	fc840713          	addi	a4,s0,-56
    800004c4:	00f704b3          	add	s1,a4,a5
    800004c8:	fff70913          	addi	s2,a4,-1
    800004cc:	993e                	add	s2,s2,a5
    800004ce:	37fd                	addiw	a5,a5,-1
    800004d0:	1782                	slli	a5,a5,0x20
    800004d2:	9381                	srli	a5,a5,0x20
    800004d4:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004d8:	fff4c503          	lbu	a0,-1(s1)
    800004dc:	d9dff0ef          	jal	80000278 <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x70>
    800004e6:	74a2                	ld	s1,40(sp)
    800004e8:	7902                	ld	s2,32(sp)
}
    800004ea:	70e2                	ld	ra,56(sp)
    800004ec:	7442                	ld	s0,48(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4885                	li	a7,1
    x = -xx;
    800004f8:	b741                	j	80000478 <printint+0x10>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	e8d2                	sd	s4,80(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	8a2a                	mv	s4,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    80000518:	0000a797          	auipc	a5,0xa
    8000051c:	d5c7a783          	lw	a5,-676(a5) # 8000a274 <panicking>
    80000520:	c3a1                	beqz	a5,80000560 <printf+0x66>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	000a4503          	lbu	a0,0(s4)
    8000052e:	28050763          	beqz	a0,800007bc <printf+0x2c2>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	f0ca                	sd	s2,96(sp)
    80000536:	ecce                	sd	s3,88(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	f862                	sd	s8,48(sp)
    8000053e:	f466                	sd	s9,40(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4981                	li	s3,0
    if(cx != '%'){
    80000546:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    8000054a:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    8000054e:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80000552:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000556:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    8000055a:	07000d93          	li	s11,112
    8000055e:	a01d                	j	80000584 <printf+0x8a>
    acquire(&pr.lock);
    80000560:	00012517          	auipc	a0,0x12
    80000564:	de850513          	addi	a0,a0,-536 # 80012348 <pr>
    80000568:	666000ef          	jal	80000bce <acquire>
    8000056c:	bf5d                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056e:	d0bff0ef          	jal	80000278 <consputc>
      continue;
    80000572:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000574:	0014899b          	addiw	s3,s1,1
    80000578:	013a07b3          	add	a5,s4,s3
    8000057c:	0007c503          	lbu	a0,0(a5)
    80000580:	20050b63          	beqz	a0,80000796 <printf+0x29c>
    if(cx != '%'){
    80000584:	ff5515e3          	bne	a0,s5,8000056e <printf+0x74>
    i++;
    80000588:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    8000058c:	009a07b3          	add	a5,s4,s1
    80000590:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000594:	20090b63          	beqz	s2,800007aa <printf+0x2b0>
    80000598:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000059c:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059e:	c789                	beqz	a5,800005a8 <printf+0xae>
    800005a0:	009a0733          	add	a4,s4,s1
    800005a4:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    800005a8:	03690963          	beq	s2,s6,800005da <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    800005ac:	05890363          	beq	s2,s8,800005f2 <printf+0xf8>
    } else if(c0 == 'u'){
    800005b0:	0d990663          	beq	s2,s9,8000067c <printf+0x182>
    } else if(c0 == 'x'){
    800005b4:	11a90d63          	beq	s2,s10,800006ce <printf+0x1d4>
    } else if(c0 == 'p'){
    800005b8:	15b90663          	beq	s2,s11,80000704 <printf+0x20a>
      printptr(va_arg(ap, uint64));
    } else if(c0 == 'c'){
    800005bc:	06300793          	li	a5,99
    800005c0:	18f90563          	beq	s2,a5,8000074a <printf+0x250>
      consputc(va_arg(ap, uint));
    } else if(c0 == 's'){
    800005c4:	07300793          	li	a5,115
    800005c8:	18f90b63          	beq	s2,a5,8000075e <printf+0x264>
      if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
    } else if(c0 == '%'){
    800005cc:	03591b63          	bne	s2,s5,80000602 <printf+0x108>
      consputc('%');
    800005d0:	02500513          	li	a0,37
    800005d4:	ca5ff0ef          	jal	80000278 <consputc>
    800005d8:	bf71                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, int), 10, 1);
    800005da:	f8843783          	ld	a5,-120(s0)
    800005de:	00878713          	addi	a4,a5,8
    800005e2:	f8e43423          	sd	a4,-120(s0)
    800005e6:	4605                	li	a2,1
    800005e8:	45a9                	li	a1,10
    800005ea:	4388                	lw	a0,0(a5)
    800005ec:	e7dff0ef          	jal	80000468 <printint>
    800005f0:	b751                	j	80000574 <printf+0x7a>
    } else if(c0 == 'l' && c1 == 'd'){
    800005f2:	01678f63          	beq	a5,s6,80000610 <printf+0x116>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005f6:	03878b63          	beq	a5,s8,8000062c <printf+0x132>
    } else if(c0 == 'l' && c1 == 'u'){
    800005fa:	09978e63          	beq	a5,s9,80000696 <printf+0x19c>
    } else if(c0 == 'l' && c1 == 'x'){
    800005fe:	0fa78563          	beq	a5,s10,800006e8 <printf+0x1ee>
    } else if(c0 == 0){
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    80000602:	8556                	mv	a0,s5
    80000604:	c75ff0ef          	jal	80000278 <consputc>
      consputc(c0);
    80000608:	854a                	mv	a0,s2
    8000060a:	c6fff0ef          	jal	80000278 <consputc>
    8000060e:	b79d                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000610:	f8843783          	ld	a5,-120(s0)
    80000614:	00878713          	addi	a4,a5,8
    80000618:	f8e43423          	sd	a4,-120(s0)
    8000061c:	4605                	li	a2,1
    8000061e:	45a9                	li	a1,10
    80000620:	6388                	ld	a0,0(a5)
    80000622:	e47ff0ef          	jal	80000468 <printint>
      i += 1;
    80000626:	0029849b          	addiw	s1,s3,2
    8000062a:	b7a9                	j	80000574 <printf+0x7a>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000062c:	06400793          	li	a5,100
    80000630:	02f68863          	beq	a3,a5,80000660 <printf+0x166>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80000634:	07500793          	li	a5,117
    80000638:	06f68d63          	beq	a3,a5,800006b2 <printf+0x1b8>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    8000063c:	07800793          	li	a5,120
    80000640:	fcf691e3          	bne	a3,a5,80000602 <printf+0x108>
      printint(va_arg(ap, uint64), 16, 0);
    80000644:	f8843783          	ld	a5,-120(s0)
    80000648:	00878713          	addi	a4,a5,8
    8000064c:	f8e43423          	sd	a4,-120(s0)
    80000650:	4601                	li	a2,0
    80000652:	45c1                	li	a1,16
    80000654:	6388                	ld	a0,0(a5)
    80000656:	e13ff0ef          	jal	80000468 <printint>
      i += 2;
    8000065a:	0039849b          	addiw	s1,s3,3
    8000065e:	bf19                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000660:	f8843783          	ld	a5,-120(s0)
    80000664:	00878713          	addi	a4,a5,8
    80000668:	f8e43423          	sd	a4,-120(s0)
    8000066c:	4605                	li	a2,1
    8000066e:	45a9                	li	a1,10
    80000670:	6388                	ld	a0,0(a5)
    80000672:	df7ff0ef          	jal	80000468 <printint>
      i += 2;
    80000676:	0039849b          	addiw	s1,s3,3
    8000067a:	bded                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint32), 10, 0);
    8000067c:	f8843783          	ld	a5,-120(s0)
    80000680:	00878713          	addi	a4,a5,8
    80000684:	f8e43423          	sd	a4,-120(s0)
    80000688:	4601                	li	a2,0
    8000068a:	45a9                	li	a1,10
    8000068c:	0007e503          	lwu	a0,0(a5)
    80000690:	dd9ff0ef          	jal	80000468 <printint>
    80000694:	b5c5                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    80000696:	f8843783          	ld	a5,-120(s0)
    8000069a:	00878713          	addi	a4,a5,8
    8000069e:	f8e43423          	sd	a4,-120(s0)
    800006a2:	4601                	li	a2,0
    800006a4:	45a9                	li	a1,10
    800006a6:	6388                	ld	a0,0(a5)
    800006a8:	dc1ff0ef          	jal	80000468 <printint>
      i += 1;
    800006ac:	0029849b          	addiw	s1,s3,2
    800006b0:	b5d1                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006b2:	f8843783          	ld	a5,-120(s0)
    800006b6:	00878713          	addi	a4,a5,8
    800006ba:	f8e43423          	sd	a4,-120(s0)
    800006be:	4601                	li	a2,0
    800006c0:	45a9                	li	a1,10
    800006c2:	6388                	ld	a0,0(a5)
    800006c4:	da5ff0ef          	jal	80000468 <printint>
      i += 2;
    800006c8:	0039849b          	addiw	s1,s3,3
    800006cc:	b565                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint32), 16, 0);
    800006ce:	f8843783          	ld	a5,-120(s0)
    800006d2:	00878713          	addi	a4,a5,8
    800006d6:	f8e43423          	sd	a4,-120(s0)
    800006da:	4601                	li	a2,0
    800006dc:	45c1                	li	a1,16
    800006de:	0007e503          	lwu	a0,0(a5)
    800006e2:	d87ff0ef          	jal	80000468 <printint>
    800006e6:	b579                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 16, 0);
    800006e8:	f8843783          	ld	a5,-120(s0)
    800006ec:	00878713          	addi	a4,a5,8
    800006f0:	f8e43423          	sd	a4,-120(s0)
    800006f4:	4601                	li	a2,0
    800006f6:	45c1                	li	a1,16
    800006f8:	6388                	ld	a0,0(a5)
    800006fa:	d6fff0ef          	jal	80000468 <printint>
      i += 1;
    800006fe:	0029849b          	addiw	s1,s3,2
    80000702:	bd8d                	j	80000574 <printf+0x7a>
    80000704:	fc5e                	sd	s7,56(sp)
      printptr(va_arg(ap, uint64));
    80000706:	f8843783          	ld	a5,-120(s0)
    8000070a:	00878713          	addi	a4,a5,8
    8000070e:	f8e43423          	sd	a4,-120(s0)
    80000712:	0007b983          	ld	s3,0(a5)
  consputc('0');
    80000716:	03000513          	li	a0,48
    8000071a:	b5fff0ef          	jal	80000278 <consputc>
  consputc('x');
    8000071e:	07800513          	li	a0,120
    80000722:	b57ff0ef          	jal	80000278 <consputc>
    80000726:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000728:	00007b97          	auipc	s7,0x7
    8000072c:	008b8b93          	addi	s7,s7,8 # 80007730 <digits>
    80000730:	03c9d793          	srli	a5,s3,0x3c
    80000734:	97de                	add	a5,a5,s7
    80000736:	0007c503          	lbu	a0,0(a5)
    8000073a:	b3fff0ef          	jal	80000278 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000073e:	0992                	slli	s3,s3,0x4
    80000740:	397d                	addiw	s2,s2,-1
    80000742:	fe0917e3          	bnez	s2,80000730 <printf+0x236>
    80000746:	7be2                	ld	s7,56(sp)
    80000748:	b535                	j	80000574 <printf+0x7a>
      consputc(va_arg(ap, uint));
    8000074a:	f8843783          	ld	a5,-120(s0)
    8000074e:	00878713          	addi	a4,a5,8
    80000752:	f8e43423          	sd	a4,-120(s0)
    80000756:	4388                	lw	a0,0(a5)
    80000758:	b21ff0ef          	jal	80000278 <consputc>
    8000075c:	bd21                	j	80000574 <printf+0x7a>
      if((s = va_arg(ap, char*)) == 0)
    8000075e:	f8843783          	ld	a5,-120(s0)
    80000762:	00878713          	addi	a4,a5,8
    80000766:	f8e43423          	sd	a4,-120(s0)
    8000076a:	0007b903          	ld	s2,0(a5)
    8000076e:	00090d63          	beqz	s2,80000788 <printf+0x28e>
      for(; *s; s++)
    80000772:	00094503          	lbu	a0,0(s2)
    80000776:	de050fe3          	beqz	a0,80000574 <printf+0x7a>
        consputc(*s);
    8000077a:	affff0ef          	jal	80000278 <consputc>
      for(; *s; s++)
    8000077e:	0905                	addi	s2,s2,1
    80000780:	00094503          	lbu	a0,0(s2)
    80000784:	f97d                	bnez	a0,8000077a <printf+0x280>
    80000786:	b3fd                	j	80000574 <printf+0x7a>
        s = "(null)";
    80000788:	00007917          	auipc	s2,0x7
    8000078c:	88090913          	addi	s2,s2,-1920 # 80007008 <etext+0x8>
      for(; *s; s++)
    80000790:	02800513          	li	a0,40
    80000794:	b7dd                	j	8000077a <printf+0x280>
    80000796:	74a6                	ld	s1,104(sp)
    80000798:	7906                	ld	s2,96(sp)
    8000079a:	69e6                	ld	s3,88(sp)
    8000079c:	6aa6                	ld	s5,72(sp)
    8000079e:	6b06                	ld	s6,64(sp)
    800007a0:	7c42                	ld	s8,48(sp)
    800007a2:	7ca2                	ld	s9,40(sp)
    800007a4:	7d02                	ld	s10,32(sp)
    800007a6:	6de2                	ld	s11,24(sp)
    800007a8:	a811                	j	800007bc <printf+0x2c2>
    800007aa:	74a6                	ld	s1,104(sp)
    800007ac:	7906                	ld	s2,96(sp)
    800007ae:	69e6                	ld	s3,88(sp)
    800007b0:	6aa6                	ld	s5,72(sp)
    800007b2:	6b06                	ld	s6,64(sp)
    800007b4:	7c42                	ld	s8,48(sp)
    800007b6:	7ca2                	ld	s9,40(sp)
    800007b8:	7d02                	ld	s10,32(sp)
    800007ba:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    800007bc:	0000a797          	auipc	a5,0xa
    800007c0:	ab87a783          	lw	a5,-1352(a5) # 8000a274 <panicking>
    800007c4:	c799                	beqz	a5,800007d2 <printf+0x2d8>
    release(&pr.lock);

  return 0;
}
    800007c6:	4501                	li	a0,0
    800007c8:	70e6                	ld	ra,120(sp)
    800007ca:	7446                	ld	s0,112(sp)
    800007cc:	6a46                	ld	s4,80(sp)
    800007ce:	6129                	addi	sp,sp,192
    800007d0:	8082                	ret
    release(&pr.lock);
    800007d2:	00012517          	auipc	a0,0x12
    800007d6:	b7650513          	addi	a0,a0,-1162 # 80012348 <pr>
    800007da:	48c000ef          	jal	80000c66 <release>
  return 0;
    800007de:	b7e5                	j	800007c6 <printf+0x2cc>

00000000800007e0 <panic>:

void
panic(char *s)
{
    800007e0:	1101                	addi	sp,sp,-32
    800007e2:	ec06                	sd	ra,24(sp)
    800007e4:	e822                	sd	s0,16(sp)
    800007e6:	e426                	sd	s1,8(sp)
    800007e8:	e04a                	sd	s2,0(sp)
    800007ea:	1000                	addi	s0,sp,32
    800007ec:	84aa                	mv	s1,a0
  panicking = 1;
    800007ee:	4905                	li	s2,1
    800007f0:	0000a797          	auipc	a5,0xa
    800007f4:	a927a223          	sw	s2,-1404(a5) # 8000a274 <panicking>
  printf("panic: ");
    800007f8:	00007517          	auipc	a0,0x7
    800007fc:	82050513          	addi	a0,a0,-2016 # 80007018 <etext+0x18>
    80000800:	cfbff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000804:	85a6                	mv	a1,s1
    80000806:	00007517          	auipc	a0,0x7
    8000080a:	81a50513          	addi	a0,a0,-2022 # 80007020 <etext+0x20>
    8000080e:	cedff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000812:	0000a797          	auipc	a5,0xa
    80000816:	a527af23          	sw	s2,-1442(a5) # 8000a270 <panicked>
  for(;;)
    8000081a:	a001                	j	8000081a <panic+0x3a>

000000008000081c <printfinit>:
    ;
}

void
printfinit(void)
{
    8000081c:	1141                	addi	sp,sp,-16
    8000081e:	e406                	sd	ra,8(sp)
    80000820:	e022                	sd	s0,0(sp)
    80000822:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000824:	00007597          	auipc	a1,0x7
    80000828:	80458593          	addi	a1,a1,-2044 # 80007028 <etext+0x28>
    8000082c:	00012517          	auipc	a0,0x12
    80000830:	b1c50513          	addi	a0,a0,-1252 # 80012348 <pr>
    80000834:	31a000ef          	jal	80000b4e <initlock>
}
    80000838:	60a2                	ld	ra,8(sp)
    8000083a:	6402                	ld	s0,0(sp)
    8000083c:	0141                	addi	sp,sp,16
    8000083e:	8082                	ret

0000000080000840 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000840:	1141                	addi	sp,sp,-16
    80000842:	e406                	sd	ra,8(sp)
    80000844:	e022                	sd	s0,0(sp)
    80000846:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000848:	100007b7          	lui	a5,0x10000
    8000084c:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000850:	10000737          	lui	a4,0x10000
    80000854:	f8000693          	li	a3,-128
    80000858:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000085c:	468d                	li	a3,3
    8000085e:	10000637          	lui	a2,0x10000
    80000862:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000866:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000086a:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000086e:	10000737          	lui	a4,0x10000
    80000872:	461d                	li	a2,7
    80000874:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000878:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    8000087c:	00006597          	auipc	a1,0x6
    80000880:	7b458593          	addi	a1,a1,1972 # 80007030 <etext+0x30>
    80000884:	00012517          	auipc	a0,0x12
    80000888:	adc50513          	addi	a0,a0,-1316 # 80012360 <tx_lock>
    8000088c:	2c2000ef          	jal	80000b4e <initlock>
}
    80000890:	60a2                	ld	ra,8(sp)
    80000892:	6402                	ld	s0,0(sp)
    80000894:	0141                	addi	sp,sp,16
    80000896:	8082                	ret

0000000080000898 <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    80000898:	715d                	addi	sp,sp,-80
    8000089a:	e486                	sd	ra,72(sp)
    8000089c:	e0a2                	sd	s0,64(sp)
    8000089e:	fc26                	sd	s1,56(sp)
    800008a0:	ec56                	sd	s5,24(sp)
    800008a2:	0880                	addi	s0,sp,80
    800008a4:	8aaa                	mv	s5,a0
    800008a6:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008a8:	00012517          	auipc	a0,0x12
    800008ac:	ab850513          	addi	a0,a0,-1352 # 80012360 <tx_lock>
    800008b0:	31e000ef          	jal	80000bce <acquire>

  int i = 0;
  while(i < n){ 
    800008b4:	06905063          	blez	s1,80000914 <uartwrite+0x7c>
    800008b8:	f84a                	sd	s2,48(sp)
    800008ba:	f44e                	sd	s3,40(sp)
    800008bc:	f052                	sd	s4,32(sp)
    800008be:	e85a                	sd	s6,16(sp)
    800008c0:	e45e                	sd	s7,8(sp)
    800008c2:	8a56                	mv	s4,s5
    800008c4:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    800008c6:	0000a497          	auipc	s1,0xa
    800008ca:	9b648493          	addi	s1,s1,-1610 # 8000a27c <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    800008ce:	00012997          	auipc	s3,0x12
    800008d2:	a9298993          	addi	s3,s3,-1390 # 80012360 <tx_lock>
    800008d6:	0000a917          	auipc	s2,0xa
    800008da:	9a290913          	addi	s2,s2,-1630 # 8000a278 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    800008de:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    800008e2:	4b05                	li	s6,1
    800008e4:	a005                	j	80000904 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    800008e6:	85ce                	mv	a1,s3
    800008e8:	854a                	mv	a0,s2
    800008ea:	600010ef          	jal	80001eea <sleep>
    while(tx_busy != 0){
    800008ee:	409c                	lw	a5,0(s1)
    800008f0:	fbfd                	bnez	a5,800008e6 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    800008f2:	000a4783          	lbu	a5,0(s4)
    800008f6:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    800008fa:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    800008fe:	0a05                	addi	s4,s4,1
    80000900:	015a0563          	beq	s4,s5,8000090a <uartwrite+0x72>
    while(tx_busy != 0){
    80000904:	409c                	lw	a5,0(s1)
    80000906:	f3e5                	bnez	a5,800008e6 <uartwrite+0x4e>
    80000908:	b7ed                	j	800008f2 <uartwrite+0x5a>
    8000090a:	7942                	ld	s2,48(sp)
    8000090c:	79a2                	ld	s3,40(sp)
    8000090e:	7a02                	ld	s4,32(sp)
    80000910:	6b42                	ld	s6,16(sp)
    80000912:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000914:	00012517          	auipc	a0,0x12
    80000918:	a4c50513          	addi	a0,a0,-1460 # 80012360 <tx_lock>
    8000091c:	34a000ef          	jal	80000c66 <release>
}
    80000920:	60a6                	ld	ra,72(sp)
    80000922:	6406                	ld	s0,64(sp)
    80000924:	74e2                	ld	s1,56(sp)
    80000926:	6ae2                	ld	s5,24(sp)
    80000928:	6161                	addi	sp,sp,80
    8000092a:	8082                	ret

000000008000092c <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000092c:	1101                	addi	sp,sp,-32
    8000092e:	ec06                	sd	ra,24(sp)
    80000930:	e822                	sd	s0,16(sp)
    80000932:	e426                	sd	s1,8(sp)
    80000934:	1000                	addi	s0,sp,32
    80000936:	84aa                	mv	s1,a0
  if(panicking == 0)
    80000938:	0000a797          	auipc	a5,0xa
    8000093c:	93c7a783          	lw	a5,-1732(a5) # 8000a274 <panicking>
    80000940:	cf95                	beqz	a5,8000097c <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000942:	0000a797          	auipc	a5,0xa
    80000946:	92e7a783          	lw	a5,-1746(a5) # 8000a270 <panicked>
    8000094a:	ef85                	bnez	a5,80000982 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000094c:	10000737          	lui	a4,0x10000
    80000950:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000952:	00074783          	lbu	a5,0(a4)
    80000956:	0207f793          	andi	a5,a5,32
    8000095a:	dfe5                	beqz	a5,80000952 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000095c:	0ff4f513          	zext.b	a0,s1
    80000960:	100007b7          	lui	a5,0x10000
    80000964:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    80000968:	0000a797          	auipc	a5,0xa
    8000096c:	90c7a783          	lw	a5,-1780(a5) # 8000a274 <panicking>
    80000970:	cb91                	beqz	a5,80000984 <uartputc_sync+0x58>
    pop_off();
}
    80000972:	60e2                	ld	ra,24(sp)
    80000974:	6442                	ld	s0,16(sp)
    80000976:	64a2                	ld	s1,8(sp)
    80000978:	6105                	addi	sp,sp,32
    8000097a:	8082                	ret
    push_off();
    8000097c:	212000ef          	jal	80000b8e <push_off>
    80000980:	b7c9                	j	80000942 <uartputc_sync+0x16>
    for(;;)
    80000982:	a001                	j	80000982 <uartputc_sync+0x56>
    pop_off();
    80000984:	28e000ef          	jal	80000c12 <pop_off>
}
    80000988:	b7ed                	j	80000972 <uartputc_sync+0x46>

000000008000098a <uartgetc>:

// try to read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    8000098a:	1141                	addi	sp,sp,-16
    8000098c:	e422                	sd	s0,8(sp)
    8000098e:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    80000990:	100007b7          	lui	a5,0x10000
    80000994:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    80000996:	0007c783          	lbu	a5,0(a5)
    8000099a:	8b85                	andi	a5,a5,1
    8000099c:	cb81                	beqz	a5,800009ac <uartgetc+0x22>
    // input data is ready.
    return ReadReg(RHR);
    8000099e:	100007b7          	lui	a5,0x10000
    800009a2:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009a6:	6422                	ld	s0,8(sp)
    800009a8:	0141                	addi	sp,sp,16
    800009aa:	8082                	ret
    return -1;
    800009ac:	557d                	li	a0,-1
    800009ae:	bfe5                	j	800009a6 <uartgetc+0x1c>

00000000800009b0 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009b0:	1101                	addi	sp,sp,-32
    800009b2:	ec06                	sd	ra,24(sp)
    800009b4:	e822                	sd	s0,16(sp)
    800009b6:	e426                	sd	s1,8(sp)
    800009b8:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009ba:	100007b7          	lui	a5,0x10000
    800009be:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    800009c0:	0007c783          	lbu	a5,0(a5)

  acquire(&tx_lock);
    800009c4:	00012517          	auipc	a0,0x12
    800009c8:	99c50513          	addi	a0,a0,-1636 # 80012360 <tx_lock>
    800009cc:	202000ef          	jal	80000bce <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    800009d0:	100007b7          	lui	a5,0x10000
    800009d4:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009d6:	0007c783          	lbu	a5,0(a5)
    800009da:	0207f793          	andi	a5,a5,32
    800009de:	eb89                	bnez	a5,800009f0 <uartintr+0x40>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    800009e0:	00012517          	auipc	a0,0x12
    800009e4:	98050513          	addi	a0,a0,-1664 # 80012360 <tx_lock>
    800009e8:	27e000ef          	jal	80000c66 <release>

  // read and process incoming characters, if any.
  while(1){
    int c = uartgetc();
    if(c == -1)
    800009ec:	54fd                	li	s1,-1
    800009ee:	a831                	j	80000a0a <uartintr+0x5a>
    tx_busy = 0;
    800009f0:	0000a797          	auipc	a5,0xa
    800009f4:	8807a623          	sw	zero,-1908(a5) # 8000a27c <tx_busy>
    wakeup(&tx_chan);
    800009f8:	0000a517          	auipc	a0,0xa
    800009fc:	88050513          	addi	a0,a0,-1920 # 8000a278 <tx_chan>
    80000a00:	536010ef          	jal	80001f36 <wakeup>
    80000a04:	bff1                	j	800009e0 <uartintr+0x30>
      break;
    consoleintr(c);
    80000a06:	8a5ff0ef          	jal	800002aa <consoleintr>
    int c = uartgetc();
    80000a0a:	f81ff0ef          	jal	8000098a <uartgetc>
    if(c == -1)
    80000a0e:	fe951ce3          	bne	a0,s1,80000a06 <uartintr+0x56>
  }
}
    80000a12:	60e2                	ld	ra,24(sp)
    80000a14:	6442                	ld	s0,16(sp)
    80000a16:	64a2                	ld	s1,8(sp)
    80000a18:	6105                	addi	sp,sp,32
    80000a1a:	8082                	ret

0000000080000a1c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a1c:	1101                	addi	sp,sp,-32
    80000a1e:	ec06                	sd	ra,24(sp)
    80000a20:	e822                	sd	s0,16(sp)
    80000a22:	e426                	sd	s1,8(sp)
    80000a24:	e04a                	sd	s2,0(sp)
    80000a26:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a28:	03451793          	slli	a5,a0,0x34
    80000a2c:	e7a9                	bnez	a5,80000a76 <kfree+0x5a>
    80000a2e:	84aa                	mv	s1,a0
    80000a30:	00023797          	auipc	a5,0x23
    80000a34:	f7878793          	addi	a5,a5,-136 # 800239a8 <end>
    80000a38:	02f56f63          	bltu	a0,a5,80000a76 <kfree+0x5a>
    80000a3c:	47c5                	li	a5,17
    80000a3e:	07ee                	slli	a5,a5,0x1b
    80000a40:	02f57b63          	bgeu	a0,a5,80000a76 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a44:	6605                	lui	a2,0x1
    80000a46:	4585                	li	a1,1
    80000a48:	25a000ef          	jal	80000ca2 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a4c:	00012917          	auipc	s2,0x12
    80000a50:	92c90913          	addi	s2,s2,-1748 # 80012378 <kmem>
    80000a54:	854a                	mv	a0,s2
    80000a56:	178000ef          	jal	80000bce <acquire>
  r->next = kmem.freelist;
    80000a5a:	01893783          	ld	a5,24(s2)
    80000a5e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a60:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a64:	854a                	mv	a0,s2
    80000a66:	200000ef          	jal	80000c66 <release>
}
    80000a6a:	60e2                	ld	ra,24(sp)
    80000a6c:	6442                	ld	s0,16(sp)
    80000a6e:	64a2                	ld	s1,8(sp)
    80000a70:	6902                	ld	s2,0(sp)
    80000a72:	6105                	addi	sp,sp,32
    80000a74:	8082                	ret
    panic("kfree");
    80000a76:	00006517          	auipc	a0,0x6
    80000a7a:	5c250513          	addi	a0,a0,1474 # 80007038 <etext+0x38>
    80000a7e:	d63ff0ef          	jal	800007e0 <panic>

0000000080000a82 <freerange>:
{
    80000a82:	7179                	addi	sp,sp,-48
    80000a84:	f406                	sd	ra,40(sp)
    80000a86:	f022                	sd	s0,32(sp)
    80000a88:	ec26                	sd	s1,24(sp)
    80000a8a:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000a8c:	6785                	lui	a5,0x1
    80000a8e:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a92:	00e504b3          	add	s1,a0,a4
    80000a96:	777d                	lui	a4,0xfffff
    80000a98:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a9a:	94be                	add	s1,s1,a5
    80000a9c:	0295e263          	bltu	a1,s1,80000ac0 <freerange+0x3e>
    80000aa0:	e84a                	sd	s2,16(sp)
    80000aa2:	e44e                	sd	s3,8(sp)
    80000aa4:	e052                	sd	s4,0(sp)
    80000aa6:	892e                	mv	s2,a1
    kfree(p);
    80000aa8:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000aaa:	6985                	lui	s3,0x1
    kfree(p);
    80000aac:	01448533          	add	a0,s1,s4
    80000ab0:	f6dff0ef          	jal	80000a1c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ab4:	94ce                	add	s1,s1,s3
    80000ab6:	fe997be3          	bgeu	s2,s1,80000aac <freerange+0x2a>
    80000aba:	6942                	ld	s2,16(sp)
    80000abc:	69a2                	ld	s3,8(sp)
    80000abe:	6a02                	ld	s4,0(sp)
}
    80000ac0:	70a2                	ld	ra,40(sp)
    80000ac2:	7402                	ld	s0,32(sp)
    80000ac4:	64e2                	ld	s1,24(sp)
    80000ac6:	6145                	addi	sp,sp,48
    80000ac8:	8082                	ret

0000000080000aca <kinit>:
{
    80000aca:	1141                	addi	sp,sp,-16
    80000acc:	e406                	sd	ra,8(sp)
    80000ace:	e022                	sd	s0,0(sp)
    80000ad0:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ad2:	00006597          	auipc	a1,0x6
    80000ad6:	56e58593          	addi	a1,a1,1390 # 80007040 <etext+0x40>
    80000ada:	00012517          	auipc	a0,0x12
    80000ade:	89e50513          	addi	a0,a0,-1890 # 80012378 <kmem>
    80000ae2:	06c000ef          	jal	80000b4e <initlock>
  freerange(end, (void*)PHYSTOP);
    80000ae6:	45c5                	li	a1,17
    80000ae8:	05ee                	slli	a1,a1,0x1b
    80000aea:	00023517          	auipc	a0,0x23
    80000aee:	ebe50513          	addi	a0,a0,-322 # 800239a8 <end>
    80000af2:	f91ff0ef          	jal	80000a82 <freerange>
}
    80000af6:	60a2                	ld	ra,8(sp)
    80000af8:	6402                	ld	s0,0(sp)
    80000afa:	0141                	addi	sp,sp,16
    80000afc:	8082                	ret

0000000080000afe <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000afe:	1101                	addi	sp,sp,-32
    80000b00:	ec06                	sd	ra,24(sp)
    80000b02:	e822                	sd	s0,16(sp)
    80000b04:	e426                	sd	s1,8(sp)
    80000b06:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b08:	00012497          	auipc	s1,0x12
    80000b0c:	87048493          	addi	s1,s1,-1936 # 80012378 <kmem>
    80000b10:	8526                	mv	a0,s1
    80000b12:	0bc000ef          	jal	80000bce <acquire>
  r = kmem.freelist;
    80000b16:	6c84                	ld	s1,24(s1)
  if(r)
    80000b18:	c485                	beqz	s1,80000b40 <kalloc+0x42>
    kmem.freelist = r->next;
    80000b1a:	609c                	ld	a5,0(s1)
    80000b1c:	00012517          	auipc	a0,0x12
    80000b20:	85c50513          	addi	a0,a0,-1956 # 80012378 <kmem>
    80000b24:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b26:	140000ef          	jal	80000c66 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b2a:	6605                	lui	a2,0x1
    80000b2c:	4595                	li	a1,5
    80000b2e:	8526                	mv	a0,s1
    80000b30:	172000ef          	jal	80000ca2 <memset>
  return (void*)r;
}
    80000b34:	8526                	mv	a0,s1
    80000b36:	60e2                	ld	ra,24(sp)
    80000b38:	6442                	ld	s0,16(sp)
    80000b3a:	64a2                	ld	s1,8(sp)
    80000b3c:	6105                	addi	sp,sp,32
    80000b3e:	8082                	ret
  release(&kmem.lock);
    80000b40:	00012517          	auipc	a0,0x12
    80000b44:	83850513          	addi	a0,a0,-1992 # 80012378 <kmem>
    80000b48:	11e000ef          	jal	80000c66 <release>
  if(r)
    80000b4c:	b7e5                	j	80000b34 <kalloc+0x36>

0000000080000b4e <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b4e:	1141                	addi	sp,sp,-16
    80000b50:	e422                	sd	s0,8(sp)
    80000b52:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b54:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b56:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b5a:	00053823          	sd	zero,16(a0)
}
    80000b5e:	6422                	ld	s0,8(sp)
    80000b60:	0141                	addi	sp,sp,16
    80000b62:	8082                	ret

0000000080000b64 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b64:	411c                	lw	a5,0(a0)
    80000b66:	e399                	bnez	a5,80000b6c <holding+0x8>
    80000b68:	4501                	li	a0,0
  return r;
}
    80000b6a:	8082                	ret
{
    80000b6c:	1101                	addi	sp,sp,-32
    80000b6e:	ec06                	sd	ra,24(sp)
    80000b70:	e822                	sd	s0,16(sp)
    80000b72:	e426                	sd	s1,8(sp)
    80000b74:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b76:	6904                	ld	s1,16(a0)
    80000b78:	53b000ef          	jal	800018b2 <mycpu>
    80000b7c:	40a48533          	sub	a0,s1,a0
    80000b80:	00153513          	seqz	a0,a0
}
    80000b84:	60e2                	ld	ra,24(sp)
    80000b86:	6442                	ld	s0,16(sp)
    80000b88:	64a2                	ld	s1,8(sp)
    80000b8a:	6105                	addi	sp,sp,32
    80000b8c:	8082                	ret

0000000080000b8e <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b8e:	1101                	addi	sp,sp,-32
    80000b90:	ec06                	sd	ra,24(sp)
    80000b92:	e822                	sd	s0,16(sp)
    80000b94:	e426                	sd	s1,8(sp)
    80000b96:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000b98:	100024f3          	csrr	s1,sstatus
    80000b9c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000ba0:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000ba2:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000ba6:	50d000ef          	jal	800018b2 <mycpu>
    80000baa:	5d3c                	lw	a5,120(a0)
    80000bac:	cb99                	beqz	a5,80000bc2 <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bae:	505000ef          	jal	800018b2 <mycpu>
    80000bb2:	5d3c                	lw	a5,120(a0)
    80000bb4:	2785                	addiw	a5,a5,1
    80000bb6:	dd3c                	sw	a5,120(a0)
}
    80000bb8:	60e2                	ld	ra,24(sp)
    80000bba:	6442                	ld	s0,16(sp)
    80000bbc:	64a2                	ld	s1,8(sp)
    80000bbe:	6105                	addi	sp,sp,32
    80000bc0:	8082                	ret
    mycpu()->intena = old;
    80000bc2:	4f1000ef          	jal	800018b2 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000bc6:	8085                	srli	s1,s1,0x1
    80000bc8:	8885                	andi	s1,s1,1
    80000bca:	dd64                	sw	s1,124(a0)
    80000bcc:	b7cd                	j	80000bae <push_off+0x20>

0000000080000bce <acquire>:
{
    80000bce:	1101                	addi	sp,sp,-32
    80000bd0:	ec06                	sd	ra,24(sp)
    80000bd2:	e822                	sd	s0,16(sp)
    80000bd4:	e426                	sd	s1,8(sp)
    80000bd6:	1000                	addi	s0,sp,32
    80000bd8:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000bda:	fb5ff0ef          	jal	80000b8e <push_off>
  if(holding(lk))
    80000bde:	8526                	mv	a0,s1
    80000be0:	f85ff0ef          	jal	80000b64 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000be4:	4705                	li	a4,1
  if(holding(lk))
    80000be6:	e105                	bnez	a0,80000c06 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000be8:	87ba                	mv	a5,a4
    80000bea:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000bee:	2781                	sext.w	a5,a5
    80000bf0:	ffe5                	bnez	a5,80000be8 <acquire+0x1a>
  __sync_synchronize();
    80000bf2:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000bf6:	4bd000ef          	jal	800018b2 <mycpu>
    80000bfa:	e888                	sd	a0,16(s1)
}
    80000bfc:	60e2                	ld	ra,24(sp)
    80000bfe:	6442                	ld	s0,16(sp)
    80000c00:	64a2                	ld	s1,8(sp)
    80000c02:	6105                	addi	sp,sp,32
    80000c04:	8082                	ret
    panic("acquire");
    80000c06:	00006517          	auipc	a0,0x6
    80000c0a:	44250513          	addi	a0,a0,1090 # 80007048 <etext+0x48>
    80000c0e:	bd3ff0ef          	jal	800007e0 <panic>

0000000080000c12 <pop_off>:

void
pop_off(void)
{
    80000c12:	1141                	addi	sp,sp,-16
    80000c14:	e406                	sd	ra,8(sp)
    80000c16:	e022                	sd	s0,0(sp)
    80000c18:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c1a:	499000ef          	jal	800018b2 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c1e:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c22:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c24:	e78d                	bnez	a5,80000c4e <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c26:	5d3c                	lw	a5,120(a0)
    80000c28:	02f05963          	blez	a5,80000c5a <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80000c2c:	37fd                	addiw	a5,a5,-1
    80000c2e:	0007871b          	sext.w	a4,a5
    80000c32:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c34:	eb09                	bnez	a4,80000c46 <pop_off+0x34>
    80000c36:	5d7c                	lw	a5,124(a0)
    80000c38:	c799                	beqz	a5,80000c46 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c3a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c3e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c42:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c46:	60a2                	ld	ra,8(sp)
    80000c48:	6402                	ld	s0,0(sp)
    80000c4a:	0141                	addi	sp,sp,16
    80000c4c:	8082                	ret
    panic("pop_off - interruptible");
    80000c4e:	00006517          	auipc	a0,0x6
    80000c52:	40250513          	addi	a0,a0,1026 # 80007050 <etext+0x50>
    80000c56:	b8bff0ef          	jal	800007e0 <panic>
    panic("pop_off");
    80000c5a:	00006517          	auipc	a0,0x6
    80000c5e:	40e50513          	addi	a0,a0,1038 # 80007068 <etext+0x68>
    80000c62:	b7fff0ef          	jal	800007e0 <panic>

0000000080000c66 <release>:
{
    80000c66:	1101                	addi	sp,sp,-32
    80000c68:	ec06                	sd	ra,24(sp)
    80000c6a:	e822                	sd	s0,16(sp)
    80000c6c:	e426                	sd	s1,8(sp)
    80000c6e:	1000                	addi	s0,sp,32
    80000c70:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000c72:	ef3ff0ef          	jal	80000b64 <holding>
    80000c76:	c105                	beqz	a0,80000c96 <release+0x30>
  lk->cpu = 0;
    80000c78:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000c7c:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000c80:	0310000f          	fence	rw,w
    80000c84:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000c88:	f8bff0ef          	jal	80000c12 <pop_off>
}
    80000c8c:	60e2                	ld	ra,24(sp)
    80000c8e:	6442                	ld	s0,16(sp)
    80000c90:	64a2                	ld	s1,8(sp)
    80000c92:	6105                	addi	sp,sp,32
    80000c94:	8082                	ret
    panic("release");
    80000c96:	00006517          	auipc	a0,0x6
    80000c9a:	3da50513          	addi	a0,a0,986 # 80007070 <etext+0x70>
    80000c9e:	b43ff0ef          	jal	800007e0 <panic>

0000000080000ca2 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000ca2:	1141                	addi	sp,sp,-16
    80000ca4:	e422                	sd	s0,8(sp)
    80000ca6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000ca8:	ca19                	beqz	a2,80000cbe <memset+0x1c>
    80000caa:	87aa                	mv	a5,a0
    80000cac:	1602                	slli	a2,a2,0x20
    80000cae:	9201                	srli	a2,a2,0x20
    80000cb0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cb4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000cb8:	0785                	addi	a5,a5,1
    80000cba:	fee79de3          	bne	a5,a4,80000cb4 <memset+0x12>
  }
  return dst;
}
    80000cbe:	6422                	ld	s0,8(sp)
    80000cc0:	0141                	addi	sp,sp,16
    80000cc2:	8082                	ret

0000000080000cc4 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cc4:	1141                	addi	sp,sp,-16
    80000cc6:	e422                	sd	s0,8(sp)
    80000cc8:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000cca:	ca05                	beqz	a2,80000cfa <memcmp+0x36>
    80000ccc:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000cd0:	1682                	slli	a3,a3,0x20
    80000cd2:	9281                	srli	a3,a3,0x20
    80000cd4:	0685                	addi	a3,a3,1
    80000cd6:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000cd8:	00054783          	lbu	a5,0(a0)
    80000cdc:	0005c703          	lbu	a4,0(a1)
    80000ce0:	00e79863          	bne	a5,a4,80000cf0 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000ce4:	0505                	addi	a0,a0,1
    80000ce6:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000ce8:	fed518e3          	bne	a0,a3,80000cd8 <memcmp+0x14>
  }

  return 0;
    80000cec:	4501                	li	a0,0
    80000cee:	a019                	j	80000cf4 <memcmp+0x30>
      return *s1 - *s2;
    80000cf0:	40e7853b          	subw	a0,a5,a4
}
    80000cf4:	6422                	ld	s0,8(sp)
    80000cf6:	0141                	addi	sp,sp,16
    80000cf8:	8082                	ret
  return 0;
    80000cfa:	4501                	li	a0,0
    80000cfc:	bfe5                	j	80000cf4 <memcmp+0x30>

0000000080000cfe <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000cfe:	1141                	addi	sp,sp,-16
    80000d00:	e422                	sd	s0,8(sp)
    80000d02:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d04:	c205                	beqz	a2,80000d24 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d06:	02a5e263          	bltu	a1,a0,80000d2a <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d0a:	1602                	slli	a2,a2,0x20
    80000d0c:	9201                	srli	a2,a2,0x20
    80000d0e:	00c587b3          	add	a5,a1,a2
{
    80000d12:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d14:	0585                	addi	a1,a1,1
    80000d16:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffdb659>
    80000d18:	fff5c683          	lbu	a3,-1(a1)
    80000d1c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d20:	feb79ae3          	bne	a5,a1,80000d14 <memmove+0x16>

  return dst;
}
    80000d24:	6422                	ld	s0,8(sp)
    80000d26:	0141                	addi	sp,sp,16
    80000d28:	8082                	ret
  if(s < d && s + n > d){
    80000d2a:	02061693          	slli	a3,a2,0x20
    80000d2e:	9281                	srli	a3,a3,0x20
    80000d30:	00d58733          	add	a4,a1,a3
    80000d34:	fce57be3          	bgeu	a0,a4,80000d0a <memmove+0xc>
    d += n;
    80000d38:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d3a:	fff6079b          	addiw	a5,a2,-1
    80000d3e:	1782                	slli	a5,a5,0x20
    80000d40:	9381                	srli	a5,a5,0x20
    80000d42:	fff7c793          	not	a5,a5
    80000d46:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d48:	177d                	addi	a4,a4,-1
    80000d4a:	16fd                	addi	a3,a3,-1
    80000d4c:	00074603          	lbu	a2,0(a4)
    80000d50:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000d54:	fef71ae3          	bne	a4,a5,80000d48 <memmove+0x4a>
    80000d58:	b7f1                	j	80000d24 <memmove+0x26>

0000000080000d5a <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000d5a:	1141                	addi	sp,sp,-16
    80000d5c:	e406                	sd	ra,8(sp)
    80000d5e:	e022                	sd	s0,0(sp)
    80000d60:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d62:	f9dff0ef          	jal	80000cfe <memmove>
}
    80000d66:	60a2                	ld	ra,8(sp)
    80000d68:	6402                	ld	s0,0(sp)
    80000d6a:	0141                	addi	sp,sp,16
    80000d6c:	8082                	ret

0000000080000d6e <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d6e:	1141                	addi	sp,sp,-16
    80000d70:	e422                	sd	s0,8(sp)
    80000d72:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000d74:	ce11                	beqz	a2,80000d90 <strncmp+0x22>
    80000d76:	00054783          	lbu	a5,0(a0)
    80000d7a:	cf89                	beqz	a5,80000d94 <strncmp+0x26>
    80000d7c:	0005c703          	lbu	a4,0(a1)
    80000d80:	00f71a63          	bne	a4,a5,80000d94 <strncmp+0x26>
    n--, p++, q++;
    80000d84:	367d                	addiw	a2,a2,-1
    80000d86:	0505                	addi	a0,a0,1
    80000d88:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000d8a:	f675                	bnez	a2,80000d76 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000d8c:	4501                	li	a0,0
    80000d8e:	a801                	j	80000d9e <strncmp+0x30>
    80000d90:	4501                	li	a0,0
    80000d92:	a031                	j	80000d9e <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000d94:	00054503          	lbu	a0,0(a0)
    80000d98:	0005c783          	lbu	a5,0(a1)
    80000d9c:	9d1d                	subw	a0,a0,a5
}
    80000d9e:	6422                	ld	s0,8(sp)
    80000da0:	0141                	addi	sp,sp,16
    80000da2:	8082                	ret

0000000080000da4 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000da4:	1141                	addi	sp,sp,-16
    80000da6:	e422                	sd	s0,8(sp)
    80000da8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000daa:	87aa                	mv	a5,a0
    80000dac:	86b2                	mv	a3,a2
    80000dae:	367d                	addiw	a2,a2,-1
    80000db0:	02d05563          	blez	a3,80000dda <strncpy+0x36>
    80000db4:	0785                	addi	a5,a5,1
    80000db6:	0005c703          	lbu	a4,0(a1)
    80000dba:	fee78fa3          	sb	a4,-1(a5)
    80000dbe:	0585                	addi	a1,a1,1
    80000dc0:	f775                	bnez	a4,80000dac <strncpy+0x8>
    ;
  while(n-- > 0)
    80000dc2:	873e                	mv	a4,a5
    80000dc4:	9fb5                	addw	a5,a5,a3
    80000dc6:	37fd                	addiw	a5,a5,-1
    80000dc8:	00c05963          	blez	a2,80000dda <strncpy+0x36>
    *s++ = 0;
    80000dcc:	0705                	addi	a4,a4,1
    80000dce:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000dd2:	40e786bb          	subw	a3,a5,a4
    80000dd6:	fed04be3          	bgtz	a3,80000dcc <strncpy+0x28>
  return os;
}
    80000dda:	6422                	ld	s0,8(sp)
    80000ddc:	0141                	addi	sp,sp,16
    80000dde:	8082                	ret

0000000080000de0 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000de0:	1141                	addi	sp,sp,-16
    80000de2:	e422                	sd	s0,8(sp)
    80000de4:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000de6:	02c05363          	blez	a2,80000e0c <safestrcpy+0x2c>
    80000dea:	fff6069b          	addiw	a3,a2,-1
    80000dee:	1682                	slli	a3,a3,0x20
    80000df0:	9281                	srli	a3,a3,0x20
    80000df2:	96ae                	add	a3,a3,a1
    80000df4:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000df6:	00d58963          	beq	a1,a3,80000e08 <safestrcpy+0x28>
    80000dfa:	0585                	addi	a1,a1,1
    80000dfc:	0785                	addi	a5,a5,1
    80000dfe:	fff5c703          	lbu	a4,-1(a1)
    80000e02:	fee78fa3          	sb	a4,-1(a5)
    80000e06:	fb65                	bnez	a4,80000df6 <safestrcpy+0x16>
    ;
  *s = 0;
    80000e08:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e0c:	6422                	ld	s0,8(sp)
    80000e0e:	0141                	addi	sp,sp,16
    80000e10:	8082                	ret

0000000080000e12 <strlen>:

int
strlen(const char *s)
{
    80000e12:	1141                	addi	sp,sp,-16
    80000e14:	e422                	sd	s0,8(sp)
    80000e16:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e18:	00054783          	lbu	a5,0(a0)
    80000e1c:	cf91                	beqz	a5,80000e38 <strlen+0x26>
    80000e1e:	0505                	addi	a0,a0,1
    80000e20:	87aa                	mv	a5,a0
    80000e22:	86be                	mv	a3,a5
    80000e24:	0785                	addi	a5,a5,1
    80000e26:	fff7c703          	lbu	a4,-1(a5)
    80000e2a:	ff65                	bnez	a4,80000e22 <strlen+0x10>
    80000e2c:	40a6853b          	subw	a0,a3,a0
    80000e30:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000e32:	6422                	ld	s0,8(sp)
    80000e34:	0141                	addi	sp,sp,16
    80000e36:	8082                	ret
  for(n = 0; s[n]; n++)
    80000e38:	4501                	li	a0,0
    80000e3a:	bfe5                	j	80000e32 <strlen+0x20>

0000000080000e3c <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e3c:	1141                	addi	sp,sp,-16
    80000e3e:	e406                	sd	ra,8(sp)
    80000e40:	e022                	sd	s0,0(sp)
    80000e42:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000e44:	25f000ef          	jal	800018a2 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000e48:	00009717          	auipc	a4,0x9
    80000e4c:	43870713          	addi	a4,a4,1080 # 8000a280 <started>
  if(cpuid() == 0){
    80000e50:	c51d                	beqz	a0,80000e7e <main+0x42>
    while(started == 0)
    80000e52:	431c                	lw	a5,0(a4)
    80000e54:	2781                	sext.w	a5,a5
    80000e56:	dff5                	beqz	a5,80000e52 <main+0x16>
      ;
    __sync_synchronize();
    80000e58:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000e5c:	247000ef          	jal	800018a2 <cpuid>
    80000e60:	85aa                	mv	a1,a0
    80000e62:	00006517          	auipc	a0,0x6
    80000e66:	23650513          	addi	a0,a0,566 # 80007098 <etext+0x98>
    80000e6a:	e90ff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    80000e6e:	080000ef          	jal	80000eee <kvminithart>
    trapinithart();   // install kernel trap vector
    80000e72:	62a010ef          	jal	8000249c <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000e76:	732040ef          	jal	800055a8 <plicinithart>
  }

  scheduler();        
    80000e7a:	6d5000ef          	jal	80001d4e <scheduler>
    consoleinit();
    80000e7e:	da6ff0ef          	jal	80000424 <consoleinit>
    printfinit();
    80000e82:	99bff0ef          	jal	8000081c <printfinit>
    printf("\n");
    80000e86:	00006517          	auipc	a0,0x6
    80000e8a:	1f250513          	addi	a0,a0,498 # 80007078 <etext+0x78>
    80000e8e:	e6cff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    80000e92:	00006517          	auipc	a0,0x6
    80000e96:	1ee50513          	addi	a0,a0,494 # 80007080 <etext+0x80>
    80000e9a:	e60ff0ef          	jal	800004fa <printf>
    printf("\n");
    80000e9e:	00006517          	auipc	a0,0x6
    80000ea2:	1da50513          	addi	a0,a0,474 # 80007078 <etext+0x78>
    80000ea6:	e54ff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    80000eaa:	c21ff0ef          	jal	80000aca <kinit>
    kvminit();       // create kernel page table
    80000eae:	2ca000ef          	jal	80001178 <kvminit>
    kvminithart();   // turn on paging
    80000eb2:	03c000ef          	jal	80000eee <kvminithart>
    procinit();      // process table
    80000eb6:	137000ef          	jal	800017ec <procinit>
    trapinit();      // trap vectors
    80000eba:	5be010ef          	jal	80002478 <trapinit>
    trapinithart();  // install kernel trap vector
    80000ebe:	5de010ef          	jal	8000249c <trapinithart>
    plicinit();      // set up interrupt controller
    80000ec2:	6cc040ef          	jal	8000558e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000ec6:	6e2040ef          	jal	800055a8 <plicinithart>
    binit();         // buffer cache
    80000eca:	5a9010ef          	jal	80002c72 <binit>
    iinit();         // inode table
    80000ece:	32e020ef          	jal	800031fc <iinit>
    fileinit();      // file table
    80000ed2:	220030ef          	jal	800040f2 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000ed6:	7c2040ef          	jal	80005698 <virtio_disk_init>
    userinit();      // first user process
    80000eda:	4c9000ef          	jal	80001ba2 <userinit>
    __sync_synchronize();
    80000ede:	0330000f          	fence	rw,rw
    started = 1;
    80000ee2:	4785                	li	a5,1
    80000ee4:	00009717          	auipc	a4,0x9
    80000ee8:	38f72e23          	sw	a5,924(a4) # 8000a280 <started>
    80000eec:	b779                	j	80000e7a <main+0x3e>

0000000080000eee <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000eee:	1141                	addi	sp,sp,-16
    80000ef0:	e422                	sd	s0,8(sp)
    80000ef2:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000ef4:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000ef8:	00009797          	auipc	a5,0x9
    80000efc:	3907b783          	ld	a5,912(a5) # 8000a288 <kernel_pagetable>
    80000f00:	83b1                	srli	a5,a5,0xc
    80000f02:	577d                	li	a4,-1
    80000f04:	177e                	slli	a4,a4,0x3f
    80000f06:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f08:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f0c:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f10:	6422                	ld	s0,8(sp)
    80000f12:	0141                	addi	sp,sp,16
    80000f14:	8082                	ret

0000000080000f16 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f16:	7139                	addi	sp,sp,-64
    80000f18:	fc06                	sd	ra,56(sp)
    80000f1a:	f822                	sd	s0,48(sp)
    80000f1c:	f426                	sd	s1,40(sp)
    80000f1e:	f04a                	sd	s2,32(sp)
    80000f20:	ec4e                	sd	s3,24(sp)
    80000f22:	e852                	sd	s4,16(sp)
    80000f24:	e456                	sd	s5,8(sp)
    80000f26:	e05a                	sd	s6,0(sp)
    80000f28:	0080                	addi	s0,sp,64
    80000f2a:	84aa                	mv	s1,a0
    80000f2c:	89ae                	mv	s3,a1
    80000f2e:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000f30:	57fd                	li	a5,-1
    80000f32:	83e9                	srli	a5,a5,0x1a
    80000f34:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000f36:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000f38:	02b7fc63          	bgeu	a5,a1,80000f70 <walk+0x5a>
    panic("walk");
    80000f3c:	00006517          	auipc	a0,0x6
    80000f40:	17450513          	addi	a0,a0,372 # 800070b0 <etext+0xb0>
    80000f44:	89dff0ef          	jal	800007e0 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000f48:	060a8263          	beqz	s5,80000fac <walk+0x96>
    80000f4c:	bb3ff0ef          	jal	80000afe <kalloc>
    80000f50:	84aa                	mv	s1,a0
    80000f52:	c139                	beqz	a0,80000f98 <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f54:	6605                	lui	a2,0x1
    80000f56:	4581                	li	a1,0
    80000f58:	d4bff0ef          	jal	80000ca2 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f5c:	00c4d793          	srli	a5,s1,0xc
    80000f60:	07aa                	slli	a5,a5,0xa
    80000f62:	0017e793          	ori	a5,a5,1
    80000f66:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80000f6a:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffdb64f>
    80000f6c:	036a0063          	beq	s4,s6,80000f8c <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f70:	0149d933          	srl	s2,s3,s4
    80000f74:	1ff97913          	andi	s2,s2,511
    80000f78:	090e                	slli	s2,s2,0x3
    80000f7a:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000f7c:	00093483          	ld	s1,0(s2)
    80000f80:	0014f793          	andi	a5,s1,1
    80000f84:	d3f1                	beqz	a5,80000f48 <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f86:	80a9                	srli	s1,s1,0xa
    80000f88:	04b2                	slli	s1,s1,0xc
    80000f8a:	b7c5                	j	80000f6a <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000f8c:	00c9d513          	srli	a0,s3,0xc
    80000f90:	1ff57513          	andi	a0,a0,511
    80000f94:	050e                	slli	a0,a0,0x3
    80000f96:	9526                	add	a0,a0,s1
}
    80000f98:	70e2                	ld	ra,56(sp)
    80000f9a:	7442                	ld	s0,48(sp)
    80000f9c:	74a2                	ld	s1,40(sp)
    80000f9e:	7902                	ld	s2,32(sp)
    80000fa0:	69e2                	ld	s3,24(sp)
    80000fa2:	6a42                	ld	s4,16(sp)
    80000fa4:	6aa2                	ld	s5,8(sp)
    80000fa6:	6b02                	ld	s6,0(sp)
    80000fa8:	6121                	addi	sp,sp,64
    80000faa:	8082                	ret
        return 0;
    80000fac:	4501                	li	a0,0
    80000fae:	b7ed                	j	80000f98 <walk+0x82>

0000000080000fb0 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80000fb0:	57fd                	li	a5,-1
    80000fb2:	83e9                	srli	a5,a5,0x1a
    80000fb4:	00b7f463          	bgeu	a5,a1,80000fbc <walkaddr+0xc>
    return 0;
    80000fb8:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000fba:	8082                	ret
{
    80000fbc:	1141                	addi	sp,sp,-16
    80000fbe:	e406                	sd	ra,8(sp)
    80000fc0:	e022                	sd	s0,0(sp)
    80000fc2:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000fc4:	4601                	li	a2,0
    80000fc6:	f51ff0ef          	jal	80000f16 <walk>
  if(pte == 0)
    80000fca:	c105                	beqz	a0,80000fea <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    80000fcc:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80000fce:	0117f693          	andi	a3,a5,17
    80000fd2:	4745                	li	a4,17
    return 0;
    80000fd4:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000fd6:	00e68663          	beq	a3,a4,80000fe2 <walkaddr+0x32>
}
    80000fda:	60a2                	ld	ra,8(sp)
    80000fdc:	6402                	ld	s0,0(sp)
    80000fde:	0141                	addi	sp,sp,16
    80000fe0:	8082                	ret
  pa = PTE2PA(*pte);
    80000fe2:	83a9                	srli	a5,a5,0xa
    80000fe4:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000fe8:	bfcd                	j	80000fda <walkaddr+0x2a>
    return 0;
    80000fea:	4501                	li	a0,0
    80000fec:	b7fd                	j	80000fda <walkaddr+0x2a>

0000000080000fee <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000fee:	715d                	addi	sp,sp,-80
    80000ff0:	e486                	sd	ra,72(sp)
    80000ff2:	e0a2                	sd	s0,64(sp)
    80000ff4:	fc26                	sd	s1,56(sp)
    80000ff6:	f84a                	sd	s2,48(sp)
    80000ff8:	f44e                	sd	s3,40(sp)
    80000ffa:	f052                	sd	s4,32(sp)
    80000ffc:	ec56                	sd	s5,24(sp)
    80000ffe:	e85a                	sd	s6,16(sp)
    80001000:	e45e                	sd	s7,8(sp)
    80001002:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001004:	03459793          	slli	a5,a1,0x34
    80001008:	e7a9                	bnez	a5,80001052 <mappages+0x64>
    8000100a:	8aaa                	mv	s5,a0
    8000100c:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    8000100e:	03461793          	slli	a5,a2,0x34
    80001012:	e7b1                	bnez	a5,8000105e <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    80001014:	ca39                	beqz	a2,8000106a <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001016:	77fd                	lui	a5,0xfffff
    80001018:	963e                	add	a2,a2,a5
    8000101a:	00b609b3          	add	s3,a2,a1
  a = va;
    8000101e:	892e                	mv	s2,a1
    80001020:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80001024:	6b85                	lui	s7,0x1
    80001026:	014904b3          	add	s1,s2,s4
    if((pte = walk(pagetable, a, 1)) == 0)
    8000102a:	4605                	li	a2,1
    8000102c:	85ca                	mv	a1,s2
    8000102e:	8556                	mv	a0,s5
    80001030:	ee7ff0ef          	jal	80000f16 <walk>
    80001034:	c539                	beqz	a0,80001082 <mappages+0x94>
    if(*pte & PTE_V)
    80001036:	611c                	ld	a5,0(a0)
    80001038:	8b85                	andi	a5,a5,1
    8000103a:	ef95                	bnez	a5,80001076 <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000103c:	80b1                	srli	s1,s1,0xc
    8000103e:	04aa                	slli	s1,s1,0xa
    80001040:	0164e4b3          	or	s1,s1,s6
    80001044:	0014e493          	ori	s1,s1,1
    80001048:	e104                	sd	s1,0(a0)
    if(a == last)
    8000104a:	05390863          	beq	s2,s3,8000109a <mappages+0xac>
    a += PGSIZE;
    8000104e:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80001050:	bfd9                	j	80001026 <mappages+0x38>
    panic("mappages: va not aligned");
    80001052:	00006517          	auipc	a0,0x6
    80001056:	06650513          	addi	a0,a0,102 # 800070b8 <etext+0xb8>
    8000105a:	f86ff0ef          	jal	800007e0 <panic>
    panic("mappages: size not aligned");
    8000105e:	00006517          	auipc	a0,0x6
    80001062:	07a50513          	addi	a0,a0,122 # 800070d8 <etext+0xd8>
    80001066:	f7aff0ef          	jal	800007e0 <panic>
    panic("mappages: size");
    8000106a:	00006517          	auipc	a0,0x6
    8000106e:	08e50513          	addi	a0,a0,142 # 800070f8 <etext+0xf8>
    80001072:	f6eff0ef          	jal	800007e0 <panic>
      panic("mappages: remap");
    80001076:	00006517          	auipc	a0,0x6
    8000107a:	09250513          	addi	a0,a0,146 # 80007108 <etext+0x108>
    8000107e:	f62ff0ef          	jal	800007e0 <panic>
      return -1;
    80001082:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001084:	60a6                	ld	ra,72(sp)
    80001086:	6406                	ld	s0,64(sp)
    80001088:	74e2                	ld	s1,56(sp)
    8000108a:	7942                	ld	s2,48(sp)
    8000108c:	79a2                	ld	s3,40(sp)
    8000108e:	7a02                	ld	s4,32(sp)
    80001090:	6ae2                	ld	s5,24(sp)
    80001092:	6b42                	ld	s6,16(sp)
    80001094:	6ba2                	ld	s7,8(sp)
    80001096:	6161                	addi	sp,sp,80
    80001098:	8082                	ret
  return 0;
    8000109a:	4501                	li	a0,0
    8000109c:	b7e5                	j	80001084 <mappages+0x96>

000000008000109e <kvmmap>:
{
    8000109e:	1141                	addi	sp,sp,-16
    800010a0:	e406                	sd	ra,8(sp)
    800010a2:	e022                	sd	s0,0(sp)
    800010a4:	0800                	addi	s0,sp,16
    800010a6:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    800010a8:	86b2                	mv	a3,a2
    800010aa:	863e                	mv	a2,a5
    800010ac:	f43ff0ef          	jal	80000fee <mappages>
    800010b0:	e509                	bnez	a0,800010ba <kvmmap+0x1c>
}
    800010b2:	60a2                	ld	ra,8(sp)
    800010b4:	6402                	ld	s0,0(sp)
    800010b6:	0141                	addi	sp,sp,16
    800010b8:	8082                	ret
    panic("kvmmap");
    800010ba:	00006517          	auipc	a0,0x6
    800010be:	05e50513          	addi	a0,a0,94 # 80007118 <etext+0x118>
    800010c2:	f1eff0ef          	jal	800007e0 <panic>

00000000800010c6 <kvmmake>:
{
    800010c6:	1101                	addi	sp,sp,-32
    800010c8:	ec06                	sd	ra,24(sp)
    800010ca:	e822                	sd	s0,16(sp)
    800010cc:	e426                	sd	s1,8(sp)
    800010ce:	e04a                	sd	s2,0(sp)
    800010d0:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800010d2:	a2dff0ef          	jal	80000afe <kalloc>
    800010d6:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800010d8:	6605                	lui	a2,0x1
    800010da:	4581                	li	a1,0
    800010dc:	bc7ff0ef          	jal	80000ca2 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800010e0:	4719                	li	a4,6
    800010e2:	6685                	lui	a3,0x1
    800010e4:	10000637          	lui	a2,0x10000
    800010e8:	100005b7          	lui	a1,0x10000
    800010ec:	8526                	mv	a0,s1
    800010ee:	fb1ff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800010f2:	4719                	li	a4,6
    800010f4:	6685                	lui	a3,0x1
    800010f6:	10001637          	lui	a2,0x10001
    800010fa:	100015b7          	lui	a1,0x10001
    800010fe:	8526                	mv	a0,s1
    80001100:	f9fff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001104:	4719                	li	a4,6
    80001106:	040006b7          	lui	a3,0x4000
    8000110a:	0c000637          	lui	a2,0xc000
    8000110e:	0c0005b7          	lui	a1,0xc000
    80001112:	8526                	mv	a0,s1
    80001114:	f8bff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001118:	00006917          	auipc	s2,0x6
    8000111c:	ee890913          	addi	s2,s2,-280 # 80007000 <etext>
    80001120:	4729                	li	a4,10
    80001122:	80006697          	auipc	a3,0x80006
    80001126:	ede68693          	addi	a3,a3,-290 # 7000 <_entry-0x7fff9000>
    8000112a:	4605                	li	a2,1
    8000112c:	067e                	slli	a2,a2,0x1f
    8000112e:	85b2                	mv	a1,a2
    80001130:	8526                	mv	a0,s1
    80001132:	f6dff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80001136:	46c5                	li	a3,17
    80001138:	06ee                	slli	a3,a3,0x1b
    8000113a:	4719                	li	a4,6
    8000113c:	412686b3          	sub	a3,a3,s2
    80001140:	864a                	mv	a2,s2
    80001142:	85ca                	mv	a1,s2
    80001144:	8526                	mv	a0,s1
    80001146:	f59ff0ef          	jal	8000109e <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    8000114a:	4729                	li	a4,10
    8000114c:	6685                	lui	a3,0x1
    8000114e:	00005617          	auipc	a2,0x5
    80001152:	eb260613          	addi	a2,a2,-334 # 80006000 <_trampoline>
    80001156:	040005b7          	lui	a1,0x4000
    8000115a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000115c:	05b2                	slli	a1,a1,0xc
    8000115e:	8526                	mv	a0,s1
    80001160:	f3fff0ef          	jal	8000109e <kvmmap>
  proc_mapstacks(kpgtbl);
    80001164:	8526                	mv	a0,s1
    80001166:	5ee000ef          	jal	80001754 <proc_mapstacks>
}
    8000116a:	8526                	mv	a0,s1
    8000116c:	60e2                	ld	ra,24(sp)
    8000116e:	6442                	ld	s0,16(sp)
    80001170:	64a2                	ld	s1,8(sp)
    80001172:	6902                	ld	s2,0(sp)
    80001174:	6105                	addi	sp,sp,32
    80001176:	8082                	ret

0000000080001178 <kvminit>:
{
    80001178:	1141                	addi	sp,sp,-16
    8000117a:	e406                	sd	ra,8(sp)
    8000117c:	e022                	sd	s0,0(sp)
    8000117e:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001180:	f47ff0ef          	jal	800010c6 <kvmmake>
    80001184:	00009797          	auipc	a5,0x9
    80001188:	10a7b223          	sd	a0,260(a5) # 8000a288 <kernel_pagetable>
}
    8000118c:	60a2                	ld	ra,8(sp)
    8000118e:	6402                	ld	s0,0(sp)
    80001190:	0141                	addi	sp,sp,16
    80001192:	8082                	ret

0000000080001194 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001194:	1101                	addi	sp,sp,-32
    80001196:	ec06                	sd	ra,24(sp)
    80001198:	e822                	sd	s0,16(sp)
    8000119a:	e426                	sd	s1,8(sp)
    8000119c:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    8000119e:	961ff0ef          	jal	80000afe <kalloc>
    800011a2:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800011a4:	c509                	beqz	a0,800011ae <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800011a6:	6605                	lui	a2,0x1
    800011a8:	4581                	li	a1,0
    800011aa:	af9ff0ef          	jal	80000ca2 <memset>
  return pagetable;
}
    800011ae:	8526                	mv	a0,s1
    800011b0:	60e2                	ld	ra,24(sp)
    800011b2:	6442                	ld	s0,16(sp)
    800011b4:	64a2                	ld	s1,8(sp)
    800011b6:	6105                	addi	sp,sp,32
    800011b8:	8082                	ret

00000000800011ba <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011ba:	7139                	addi	sp,sp,-64
    800011bc:	fc06                	sd	ra,56(sp)
    800011be:	f822                	sd	s0,48(sp)
    800011c0:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800011c2:	03459793          	slli	a5,a1,0x34
    800011c6:	e38d                	bnez	a5,800011e8 <uvmunmap+0x2e>
    800011c8:	f04a                	sd	s2,32(sp)
    800011ca:	ec4e                	sd	s3,24(sp)
    800011cc:	e852                	sd	s4,16(sp)
    800011ce:	e456                	sd	s5,8(sp)
    800011d0:	e05a                	sd	s6,0(sp)
    800011d2:	8a2a                	mv	s4,a0
    800011d4:	892e                	mv	s2,a1
    800011d6:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800011d8:	0632                	slli	a2,a2,0xc
    800011da:	00b609b3          	add	s3,a2,a1
    800011de:	6b05                	lui	s6,0x1
    800011e0:	0535f963          	bgeu	a1,s3,80001232 <uvmunmap+0x78>
    800011e4:	f426                	sd	s1,40(sp)
    800011e6:	a015                	j	8000120a <uvmunmap+0x50>
    800011e8:	f426                	sd	s1,40(sp)
    800011ea:	f04a                	sd	s2,32(sp)
    800011ec:	ec4e                	sd	s3,24(sp)
    800011ee:	e852                	sd	s4,16(sp)
    800011f0:	e456                	sd	s5,8(sp)
    800011f2:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    800011f4:	00006517          	auipc	a0,0x6
    800011f8:	f2c50513          	addi	a0,a0,-212 # 80007120 <etext+0x120>
    800011fc:	de4ff0ef          	jal	800007e0 <panic>
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80001200:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001204:	995a                	add	s2,s2,s6
    80001206:	03397563          	bgeu	s2,s3,80001230 <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000120a:	4601                	li	a2,0
    8000120c:	85ca                	mv	a1,s2
    8000120e:	8552                	mv	a0,s4
    80001210:	d07ff0ef          	jal	80000f16 <walk>
    80001214:	84aa                	mv	s1,a0
    80001216:	d57d                	beqz	a0,80001204 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    80001218:	611c                	ld	a5,0(a0)
    8000121a:	0017f713          	andi	a4,a5,1
    8000121e:	d37d                	beqz	a4,80001204 <uvmunmap+0x4a>
    if(do_free){
    80001220:	fe0a80e3          	beqz	s5,80001200 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001224:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    80001226:	00c79513          	slli	a0,a5,0xc
    8000122a:	ff2ff0ef          	jal	80000a1c <kfree>
    8000122e:	bfc9                	j	80001200 <uvmunmap+0x46>
    80001230:	74a2                	ld	s1,40(sp)
    80001232:	7902                	ld	s2,32(sp)
    80001234:	69e2                	ld	s3,24(sp)
    80001236:	6a42                	ld	s4,16(sp)
    80001238:	6aa2                	ld	s5,8(sp)
    8000123a:	6b02                	ld	s6,0(sp)
  }
}
    8000123c:	70e2                	ld	ra,56(sp)
    8000123e:	7442                	ld	s0,48(sp)
    80001240:	6121                	addi	sp,sp,64
    80001242:	8082                	ret

0000000080001244 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80001244:	1101                	addi	sp,sp,-32
    80001246:	ec06                	sd	ra,24(sp)
    80001248:	e822                	sd	s0,16(sp)
    8000124a:	e426                	sd	s1,8(sp)
    8000124c:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    8000124e:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    80001250:	00b67d63          	bgeu	a2,a1,8000126a <uvmdealloc+0x26>
    80001254:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001256:	6785                	lui	a5,0x1
    80001258:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000125a:	00f60733          	add	a4,a2,a5
    8000125e:	76fd                	lui	a3,0xfffff
    80001260:	8f75                	and	a4,a4,a3
    80001262:	97ae                	add	a5,a5,a1
    80001264:	8ff5                	and	a5,a5,a3
    80001266:	00f76863          	bltu	a4,a5,80001276 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    8000126a:	8526                	mv	a0,s1
    8000126c:	60e2                	ld	ra,24(sp)
    8000126e:	6442                	ld	s0,16(sp)
    80001270:	64a2                	ld	s1,8(sp)
    80001272:	6105                	addi	sp,sp,32
    80001274:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001276:	8f99                	sub	a5,a5,a4
    80001278:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    8000127a:	4685                	li	a3,1
    8000127c:	0007861b          	sext.w	a2,a5
    80001280:	85ba                	mv	a1,a4
    80001282:	f39ff0ef          	jal	800011ba <uvmunmap>
    80001286:	b7d5                	j	8000126a <uvmdealloc+0x26>

0000000080001288 <uvmalloc>:
  if(newsz < oldsz)
    80001288:	08b66f63          	bltu	a2,a1,80001326 <uvmalloc+0x9e>
{
    8000128c:	7139                	addi	sp,sp,-64
    8000128e:	fc06                	sd	ra,56(sp)
    80001290:	f822                	sd	s0,48(sp)
    80001292:	ec4e                	sd	s3,24(sp)
    80001294:	e852                	sd	s4,16(sp)
    80001296:	e456                	sd	s5,8(sp)
    80001298:	0080                	addi	s0,sp,64
    8000129a:	8aaa                	mv	s5,a0
    8000129c:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    8000129e:	6785                	lui	a5,0x1
    800012a0:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012a2:	95be                	add	a1,a1,a5
    800012a4:	77fd                	lui	a5,0xfffff
    800012a6:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    800012aa:	08c9f063          	bgeu	s3,a2,8000132a <uvmalloc+0xa2>
    800012ae:	f426                	sd	s1,40(sp)
    800012b0:	f04a                	sd	s2,32(sp)
    800012b2:	e05a                	sd	s6,0(sp)
    800012b4:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800012b6:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800012ba:	845ff0ef          	jal	80000afe <kalloc>
    800012be:	84aa                	mv	s1,a0
    if(mem == 0){
    800012c0:	c515                	beqz	a0,800012ec <uvmalloc+0x64>
    memset(mem, 0, PGSIZE);
    800012c2:	6605                	lui	a2,0x1
    800012c4:	4581                	li	a1,0
    800012c6:	9ddff0ef          	jal	80000ca2 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800012ca:	875a                	mv	a4,s6
    800012cc:	86a6                	mv	a3,s1
    800012ce:	6605                	lui	a2,0x1
    800012d0:	85ca                	mv	a1,s2
    800012d2:	8556                	mv	a0,s5
    800012d4:	d1bff0ef          	jal	80000fee <mappages>
    800012d8:	e915                	bnez	a0,8000130c <uvmalloc+0x84>
  for(a = oldsz; a < newsz; a += PGSIZE){
    800012da:	6785                	lui	a5,0x1
    800012dc:	993e                	add	s2,s2,a5
    800012de:	fd496ee3          	bltu	s2,s4,800012ba <uvmalloc+0x32>
  return newsz;
    800012e2:	8552                	mv	a0,s4
    800012e4:	74a2                	ld	s1,40(sp)
    800012e6:	7902                	ld	s2,32(sp)
    800012e8:	6b02                	ld	s6,0(sp)
    800012ea:	a811                	j	800012fe <uvmalloc+0x76>
      uvmdealloc(pagetable, a, oldsz);
    800012ec:	864e                	mv	a2,s3
    800012ee:	85ca                	mv	a1,s2
    800012f0:	8556                	mv	a0,s5
    800012f2:	f53ff0ef          	jal	80001244 <uvmdealloc>
      return 0;
    800012f6:	4501                	li	a0,0
    800012f8:	74a2                	ld	s1,40(sp)
    800012fa:	7902                	ld	s2,32(sp)
    800012fc:	6b02                	ld	s6,0(sp)
}
    800012fe:	70e2                	ld	ra,56(sp)
    80001300:	7442                	ld	s0,48(sp)
    80001302:	69e2                	ld	s3,24(sp)
    80001304:	6a42                	ld	s4,16(sp)
    80001306:	6aa2                	ld	s5,8(sp)
    80001308:	6121                	addi	sp,sp,64
    8000130a:	8082                	ret
      kfree(mem);
    8000130c:	8526                	mv	a0,s1
    8000130e:	f0eff0ef          	jal	80000a1c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001312:	864e                	mv	a2,s3
    80001314:	85ca                	mv	a1,s2
    80001316:	8556                	mv	a0,s5
    80001318:	f2dff0ef          	jal	80001244 <uvmdealloc>
      return 0;
    8000131c:	4501                	li	a0,0
    8000131e:	74a2                	ld	s1,40(sp)
    80001320:	7902                	ld	s2,32(sp)
    80001322:	6b02                	ld	s6,0(sp)
    80001324:	bfe9                	j	800012fe <uvmalloc+0x76>
    return oldsz;
    80001326:	852e                	mv	a0,a1
}
    80001328:	8082                	ret
  return newsz;
    8000132a:	8532                	mv	a0,a2
    8000132c:	bfc9                	j	800012fe <uvmalloc+0x76>

000000008000132e <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000132e:	7179                	addi	sp,sp,-48
    80001330:	f406                	sd	ra,40(sp)
    80001332:	f022                	sd	s0,32(sp)
    80001334:	ec26                	sd	s1,24(sp)
    80001336:	e84a                	sd	s2,16(sp)
    80001338:	e44e                	sd	s3,8(sp)
    8000133a:	e052                	sd	s4,0(sp)
    8000133c:	1800                	addi	s0,sp,48
    8000133e:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    80001340:	84aa                	mv	s1,a0
    80001342:	6905                	lui	s2,0x1
    80001344:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001346:	4985                	li	s3,1
    80001348:	a819                	j	8000135e <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    8000134a:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    8000134c:	00c79513          	slli	a0,a5,0xc
    80001350:	fdfff0ef          	jal	8000132e <freewalk>
      pagetable[i] = 0;
    80001354:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    80001358:	04a1                	addi	s1,s1,8
    8000135a:	01248f63          	beq	s1,s2,80001378 <freewalk+0x4a>
    pte_t pte = pagetable[i];
    8000135e:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001360:	00f7f713          	andi	a4,a5,15
    80001364:	ff3703e3          	beq	a4,s3,8000134a <freewalk+0x1c>
    } else if(pte & PTE_V){
    80001368:	8b85                	andi	a5,a5,1
    8000136a:	d7fd                	beqz	a5,80001358 <freewalk+0x2a>
      panic("freewalk: leaf");
    8000136c:	00006517          	auipc	a0,0x6
    80001370:	dcc50513          	addi	a0,a0,-564 # 80007138 <etext+0x138>
    80001374:	c6cff0ef          	jal	800007e0 <panic>
    }
  }
  kfree((void*)pagetable);
    80001378:	8552                	mv	a0,s4
    8000137a:	ea2ff0ef          	jal	80000a1c <kfree>
}
    8000137e:	70a2                	ld	ra,40(sp)
    80001380:	7402                	ld	s0,32(sp)
    80001382:	64e2                	ld	s1,24(sp)
    80001384:	6942                	ld	s2,16(sp)
    80001386:	69a2                	ld	s3,8(sp)
    80001388:	6a02                	ld	s4,0(sp)
    8000138a:	6145                	addi	sp,sp,48
    8000138c:	8082                	ret

000000008000138e <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    8000138e:	1101                	addi	sp,sp,-32
    80001390:	ec06                	sd	ra,24(sp)
    80001392:	e822                	sd	s0,16(sp)
    80001394:	e426                	sd	s1,8(sp)
    80001396:	1000                	addi	s0,sp,32
    80001398:	84aa                	mv	s1,a0
  if(sz > 0)
    8000139a:	e989                	bnez	a1,800013ac <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    8000139c:	8526                	mv	a0,s1
    8000139e:	f91ff0ef          	jal	8000132e <freewalk>
}
    800013a2:	60e2                	ld	ra,24(sp)
    800013a4:	6442                	ld	s0,16(sp)
    800013a6:	64a2                	ld	s1,8(sp)
    800013a8:	6105                	addi	sp,sp,32
    800013aa:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800013ac:	6785                	lui	a5,0x1
    800013ae:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013b0:	95be                	add	a1,a1,a5
    800013b2:	4685                	li	a3,1
    800013b4:	00c5d613          	srli	a2,a1,0xc
    800013b8:	4581                	li	a1,0
    800013ba:	e01ff0ef          	jal	800011ba <uvmunmap>
    800013be:	bff9                	j	8000139c <uvmfree+0xe>

00000000800013c0 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    800013c0:	ce49                	beqz	a2,8000145a <uvmcopy+0x9a>
{
    800013c2:	715d                	addi	sp,sp,-80
    800013c4:	e486                	sd	ra,72(sp)
    800013c6:	e0a2                	sd	s0,64(sp)
    800013c8:	fc26                	sd	s1,56(sp)
    800013ca:	f84a                	sd	s2,48(sp)
    800013cc:	f44e                	sd	s3,40(sp)
    800013ce:	f052                	sd	s4,32(sp)
    800013d0:	ec56                	sd	s5,24(sp)
    800013d2:	e85a                	sd	s6,16(sp)
    800013d4:	e45e                	sd	s7,8(sp)
    800013d6:	0880                	addi	s0,sp,80
    800013d8:	8aaa                	mv	s5,a0
    800013da:	8b2e                	mv	s6,a1
    800013dc:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    800013de:	4481                	li	s1,0
    800013e0:	a029                	j	800013ea <uvmcopy+0x2a>
    800013e2:	6785                	lui	a5,0x1
    800013e4:	94be                	add	s1,s1,a5
    800013e6:	0544fe63          	bgeu	s1,s4,80001442 <uvmcopy+0x82>
    if((pte = walk(old, i, 0)) == 0)
    800013ea:	4601                	li	a2,0
    800013ec:	85a6                	mv	a1,s1
    800013ee:	8556                	mv	a0,s5
    800013f0:	b27ff0ef          	jal	80000f16 <walk>
    800013f4:	d57d                	beqz	a0,800013e2 <uvmcopy+0x22>
      continue;   // page table entry hasn't been allocated
    if((*pte & PTE_V) == 0)
    800013f6:	6118                	ld	a4,0(a0)
    800013f8:	00177793          	andi	a5,a4,1
    800013fc:	d3fd                	beqz	a5,800013e2 <uvmcopy+0x22>
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    800013fe:	00a75593          	srli	a1,a4,0xa
    80001402:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80001406:	3ff77913          	andi	s2,a4,1023
    if((mem = kalloc()) == 0)
    8000140a:	ef4ff0ef          	jal	80000afe <kalloc>
    8000140e:	89aa                	mv	s3,a0
    80001410:	c105                	beqz	a0,80001430 <uvmcopy+0x70>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80001412:	6605                	lui	a2,0x1
    80001414:	85de                	mv	a1,s7
    80001416:	8e9ff0ef          	jal	80000cfe <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    8000141a:	874a                	mv	a4,s2
    8000141c:	86ce                	mv	a3,s3
    8000141e:	6605                	lui	a2,0x1
    80001420:	85a6                	mv	a1,s1
    80001422:	855a                	mv	a0,s6
    80001424:	bcbff0ef          	jal	80000fee <mappages>
    80001428:	dd4d                	beqz	a0,800013e2 <uvmcopy+0x22>
      kfree(mem);
    8000142a:	854e                	mv	a0,s3
    8000142c:	df0ff0ef          	jal	80000a1c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001430:	4685                	li	a3,1
    80001432:	00c4d613          	srli	a2,s1,0xc
    80001436:	4581                	li	a1,0
    80001438:	855a                	mv	a0,s6
    8000143a:	d81ff0ef          	jal	800011ba <uvmunmap>
  return -1;
    8000143e:	557d                	li	a0,-1
    80001440:	a011                	j	80001444 <uvmcopy+0x84>
  return 0;
    80001442:	4501                	li	a0,0
}
    80001444:	60a6                	ld	ra,72(sp)
    80001446:	6406                	ld	s0,64(sp)
    80001448:	74e2                	ld	s1,56(sp)
    8000144a:	7942                	ld	s2,48(sp)
    8000144c:	79a2                	ld	s3,40(sp)
    8000144e:	7a02                	ld	s4,32(sp)
    80001450:	6ae2                	ld	s5,24(sp)
    80001452:	6b42                	ld	s6,16(sp)
    80001454:	6ba2                	ld	s7,8(sp)
    80001456:	6161                	addi	sp,sp,80
    80001458:	8082                	ret
  return 0;
    8000145a:	4501                	li	a0,0
}
    8000145c:	8082                	ret

000000008000145e <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    8000145e:	1141                	addi	sp,sp,-16
    80001460:	e406                	sd	ra,8(sp)
    80001462:	e022                	sd	s0,0(sp)
    80001464:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80001466:	4601                	li	a2,0
    80001468:	aafff0ef          	jal	80000f16 <walk>
  if(pte == 0)
    8000146c:	c901                	beqz	a0,8000147c <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    8000146e:	611c                	ld	a5,0(a0)
    80001470:	9bbd                	andi	a5,a5,-17
    80001472:	e11c                	sd	a5,0(a0)
}
    80001474:	60a2                	ld	ra,8(sp)
    80001476:	6402                	ld	s0,0(sp)
    80001478:	0141                	addi	sp,sp,16
    8000147a:	8082                	ret
    panic("uvmclear");
    8000147c:	00006517          	auipc	a0,0x6
    80001480:	ccc50513          	addi	a0,a0,-820 # 80007148 <etext+0x148>
    80001484:	b5cff0ef          	jal	800007e0 <panic>

0000000080001488 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80001488:	c6dd                	beqz	a3,80001536 <copyinstr+0xae>
{
    8000148a:	715d                	addi	sp,sp,-80
    8000148c:	e486                	sd	ra,72(sp)
    8000148e:	e0a2                	sd	s0,64(sp)
    80001490:	fc26                	sd	s1,56(sp)
    80001492:	f84a                	sd	s2,48(sp)
    80001494:	f44e                	sd	s3,40(sp)
    80001496:	f052                	sd	s4,32(sp)
    80001498:	ec56                	sd	s5,24(sp)
    8000149a:	e85a                	sd	s6,16(sp)
    8000149c:	e45e                	sd	s7,8(sp)
    8000149e:	0880                	addi	s0,sp,80
    800014a0:	8a2a                	mv	s4,a0
    800014a2:	8b2e                	mv	s6,a1
    800014a4:	8bb2                	mv	s7,a2
    800014a6:	8936                	mv	s2,a3
    va0 = PGROUNDDOWN(srcva);
    800014a8:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    800014aa:	6985                	lui	s3,0x1
    800014ac:	a825                	j	800014e4 <copyinstr+0x5c>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    800014ae:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    800014b2:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    800014b4:	37fd                	addiw	a5,a5,-1
    800014b6:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800014ba:	60a6                	ld	ra,72(sp)
    800014bc:	6406                	ld	s0,64(sp)
    800014be:	74e2                	ld	s1,56(sp)
    800014c0:	7942                	ld	s2,48(sp)
    800014c2:	79a2                	ld	s3,40(sp)
    800014c4:	7a02                	ld	s4,32(sp)
    800014c6:	6ae2                	ld	s5,24(sp)
    800014c8:	6b42                	ld	s6,16(sp)
    800014ca:	6ba2                	ld	s7,8(sp)
    800014cc:	6161                	addi	sp,sp,80
    800014ce:	8082                	ret
    800014d0:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    800014d4:	9742                	add	a4,a4,a6
      --max;
    800014d6:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    800014da:	01348bb3          	add	s7,s1,s3
  while(got_null == 0 && max > 0){
    800014de:	04e58463          	beq	a1,a4,80001526 <copyinstr+0x9e>
{
    800014e2:	8b3e                	mv	s6,a5
    va0 = PGROUNDDOWN(srcva);
    800014e4:	015bf4b3          	and	s1,s7,s5
    pa0 = walkaddr(pagetable, va0);
    800014e8:	85a6                	mv	a1,s1
    800014ea:	8552                	mv	a0,s4
    800014ec:	ac5ff0ef          	jal	80000fb0 <walkaddr>
    if(pa0 == 0)
    800014f0:	cd0d                	beqz	a0,8000152a <copyinstr+0xa2>
    n = PGSIZE - (srcva - va0);
    800014f2:	417486b3          	sub	a3,s1,s7
    800014f6:	96ce                	add	a3,a3,s3
    if(n > max)
    800014f8:	00d97363          	bgeu	s2,a3,800014fe <copyinstr+0x76>
    800014fc:	86ca                	mv	a3,s2
    char *p = (char *) (pa0 + (srcva - va0));
    800014fe:	955e                	add	a0,a0,s7
    80001500:	8d05                	sub	a0,a0,s1
    while(n > 0){
    80001502:	c695                	beqz	a3,8000152e <copyinstr+0xa6>
    80001504:	87da                	mv	a5,s6
    80001506:	885a                	mv	a6,s6
      if(*p == '\0'){
    80001508:	41650633          	sub	a2,a0,s6
    while(n > 0){
    8000150c:	96da                	add	a3,a3,s6
    8000150e:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001510:	00f60733          	add	a4,a2,a5
    80001514:	00074703          	lbu	a4,0(a4)
    80001518:	db59                	beqz	a4,800014ae <copyinstr+0x26>
        *dst = *p;
    8000151a:	00e78023          	sb	a4,0(a5)
      dst++;
    8000151e:	0785                	addi	a5,a5,1
    while(n > 0){
    80001520:	fed797e3          	bne	a5,a3,8000150e <copyinstr+0x86>
    80001524:	b775                	j	800014d0 <copyinstr+0x48>
    80001526:	4781                	li	a5,0
    80001528:	b771                	j	800014b4 <copyinstr+0x2c>
      return -1;
    8000152a:	557d                	li	a0,-1
    8000152c:	b779                	j	800014ba <copyinstr+0x32>
    srcva = va0 + PGSIZE;
    8000152e:	6b85                	lui	s7,0x1
    80001530:	9ba6                	add	s7,s7,s1
    80001532:	87da                	mv	a5,s6
    80001534:	b77d                	j	800014e2 <copyinstr+0x5a>
  int got_null = 0;
    80001536:	4781                	li	a5,0
  if(got_null){
    80001538:	37fd                	addiw	a5,a5,-1
    8000153a:	0007851b          	sext.w	a0,a5
}
    8000153e:	8082                	ret

0000000080001540 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    80001540:	1141                	addi	sp,sp,-16
    80001542:	e406                	sd	ra,8(sp)
    80001544:	e022                	sd	s0,0(sp)
    80001546:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    80001548:	4601                	li	a2,0
    8000154a:	9cdff0ef          	jal	80000f16 <walk>
  if (pte == 0) {
    8000154e:	c519                	beqz	a0,8000155c <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V){
    80001550:	6108                	ld	a0,0(a0)
    80001552:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001554:	60a2                	ld	ra,8(sp)
    80001556:	6402                	ld	s0,0(sp)
    80001558:	0141                	addi	sp,sp,16
    8000155a:	8082                	ret
    return 0;
    8000155c:	4501                	li	a0,0
    8000155e:	bfdd                	j	80001554 <ismapped+0x14>

0000000080001560 <vmfault>:
{
    80001560:	7179                	addi	sp,sp,-48
    80001562:	f406                	sd	ra,40(sp)
    80001564:	f022                	sd	s0,32(sp)
    80001566:	ec26                	sd	s1,24(sp)
    80001568:	e44e                	sd	s3,8(sp)
    8000156a:	1800                	addi	s0,sp,48
    8000156c:	89aa                	mv	s3,a0
    8000156e:	84ae                	mv	s1,a1
  struct proc *p = myproc();
    80001570:	35e000ef          	jal	800018ce <myproc>
  if (va >= p->sz)
    80001574:	653c                	ld	a5,72(a0)
    80001576:	00f4ea63          	bltu	s1,a5,8000158a <vmfault+0x2a>
    return 0;
    8000157a:	4981                	li	s3,0
}
    8000157c:	854e                	mv	a0,s3
    8000157e:	70a2                	ld	ra,40(sp)
    80001580:	7402                	ld	s0,32(sp)
    80001582:	64e2                	ld	s1,24(sp)
    80001584:	69a2                	ld	s3,8(sp)
    80001586:	6145                	addi	sp,sp,48
    80001588:	8082                	ret
    8000158a:	e84a                	sd	s2,16(sp)
    8000158c:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    8000158e:	77fd                	lui	a5,0xfffff
    80001590:	8cfd                	and	s1,s1,a5
  if(ismapped(pagetable, va)) {
    80001592:	85a6                	mv	a1,s1
    80001594:	854e                	mv	a0,s3
    80001596:	fabff0ef          	jal	80001540 <ismapped>
    return 0;
    8000159a:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    8000159c:	c119                	beqz	a0,800015a2 <vmfault+0x42>
    8000159e:	6942                	ld	s2,16(sp)
    800015a0:	bff1                	j	8000157c <vmfault+0x1c>
    800015a2:	e052                	sd	s4,0(sp)
  mem = (uint64) kalloc();
    800015a4:	d5aff0ef          	jal	80000afe <kalloc>
    800015a8:	8a2a                	mv	s4,a0
  if(mem == 0)
    800015aa:	c90d                	beqz	a0,800015dc <vmfault+0x7c>
  mem = (uint64) kalloc();
    800015ac:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    800015ae:	6605                	lui	a2,0x1
    800015b0:	4581                	li	a1,0
    800015b2:	ef0ff0ef          	jal	80000ca2 <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    800015b6:	4759                	li	a4,22
    800015b8:	86d2                	mv	a3,s4
    800015ba:	6605                	lui	a2,0x1
    800015bc:	85a6                	mv	a1,s1
    800015be:	05093503          	ld	a0,80(s2)
    800015c2:	a2dff0ef          	jal	80000fee <mappages>
    800015c6:	e501                	bnez	a0,800015ce <vmfault+0x6e>
    800015c8:	6942                	ld	s2,16(sp)
    800015ca:	6a02                	ld	s4,0(sp)
    800015cc:	bf45                	j	8000157c <vmfault+0x1c>
    kfree((void *)mem);
    800015ce:	8552                	mv	a0,s4
    800015d0:	c4cff0ef          	jal	80000a1c <kfree>
    return 0;
    800015d4:	4981                	li	s3,0
    800015d6:	6942                	ld	s2,16(sp)
    800015d8:	6a02                	ld	s4,0(sp)
    800015da:	b74d                	j	8000157c <vmfault+0x1c>
    800015dc:	6942                	ld	s2,16(sp)
    800015de:	6a02                	ld	s4,0(sp)
    800015e0:	bf71                	j	8000157c <vmfault+0x1c>

00000000800015e2 <copyout>:
  while(len > 0){
    800015e2:	c2cd                	beqz	a3,80001684 <copyout+0xa2>
{
    800015e4:	711d                	addi	sp,sp,-96
    800015e6:	ec86                	sd	ra,88(sp)
    800015e8:	e8a2                	sd	s0,80(sp)
    800015ea:	e4a6                	sd	s1,72(sp)
    800015ec:	f852                	sd	s4,48(sp)
    800015ee:	f05a                	sd	s6,32(sp)
    800015f0:	ec5e                	sd	s7,24(sp)
    800015f2:	e862                	sd	s8,16(sp)
    800015f4:	1080                	addi	s0,sp,96
    800015f6:	8c2a                	mv	s8,a0
    800015f8:	8b2e                	mv	s6,a1
    800015fa:	8bb2                	mv	s7,a2
    800015fc:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    800015fe:	74fd                	lui	s1,0xfffff
    80001600:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    80001602:	57fd                	li	a5,-1
    80001604:	83e9                	srli	a5,a5,0x1a
    80001606:	0897e163          	bltu	a5,s1,80001688 <copyout+0xa6>
    8000160a:	e0ca                	sd	s2,64(sp)
    8000160c:	fc4e                	sd	s3,56(sp)
    8000160e:	f456                	sd	s5,40(sp)
    80001610:	e466                	sd	s9,8(sp)
    80001612:	e06a                	sd	s10,0(sp)
    80001614:	6d05                	lui	s10,0x1
    80001616:	8cbe                	mv	s9,a5
    80001618:	a015                	j	8000163c <copyout+0x5a>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    8000161a:	409b0533          	sub	a0,s6,s1
    8000161e:	0009861b          	sext.w	a2,s3
    80001622:	85de                	mv	a1,s7
    80001624:	954a                	add	a0,a0,s2
    80001626:	ed8ff0ef          	jal	80000cfe <memmove>
    len -= n;
    8000162a:	413a0a33          	sub	s4,s4,s3
    src += n;
    8000162e:	9bce                	add	s7,s7,s3
  while(len > 0){
    80001630:	040a0363          	beqz	s4,80001676 <copyout+0x94>
    if(va0 >= MAXVA)
    80001634:	055cec63          	bltu	s9,s5,8000168c <copyout+0xaa>
    80001638:	84d6                	mv	s1,s5
    8000163a:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    8000163c:	85a6                	mv	a1,s1
    8000163e:	8562                	mv	a0,s8
    80001640:	971ff0ef          	jal	80000fb0 <walkaddr>
    80001644:	892a                	mv	s2,a0
    if(pa0 == 0) {
    80001646:	e901                	bnez	a0,80001656 <copyout+0x74>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001648:	4601                	li	a2,0
    8000164a:	85a6                	mv	a1,s1
    8000164c:	8562                	mv	a0,s8
    8000164e:	f13ff0ef          	jal	80001560 <vmfault>
    80001652:	892a                	mv	s2,a0
    80001654:	c139                	beqz	a0,8000169a <copyout+0xb8>
    pte = walk(pagetable, va0, 0);
    80001656:	4601                	li	a2,0
    80001658:	85a6                	mv	a1,s1
    8000165a:	8562                	mv	a0,s8
    8000165c:	8bbff0ef          	jal	80000f16 <walk>
    if((*pte & PTE_W) == 0)
    80001660:	611c                	ld	a5,0(a0)
    80001662:	8b91                	andi	a5,a5,4
    80001664:	c3b1                	beqz	a5,800016a8 <copyout+0xc6>
    n = PGSIZE - (dstva - va0);
    80001666:	01a48ab3          	add	s5,s1,s10
    8000166a:	416a89b3          	sub	s3,s5,s6
    if(n > len)
    8000166e:	fb3a76e3          	bgeu	s4,s3,8000161a <copyout+0x38>
    80001672:	89d2                	mv	s3,s4
    80001674:	b75d                	j	8000161a <copyout+0x38>
  return 0;
    80001676:	4501                	li	a0,0
    80001678:	6906                	ld	s2,64(sp)
    8000167a:	79e2                	ld	s3,56(sp)
    8000167c:	7aa2                	ld	s5,40(sp)
    8000167e:	6ca2                	ld	s9,8(sp)
    80001680:	6d02                	ld	s10,0(sp)
    80001682:	a80d                	j	800016b4 <copyout+0xd2>
    80001684:	4501                	li	a0,0
}
    80001686:	8082                	ret
      return -1;
    80001688:	557d                	li	a0,-1
    8000168a:	a02d                	j	800016b4 <copyout+0xd2>
    8000168c:	557d                	li	a0,-1
    8000168e:	6906                	ld	s2,64(sp)
    80001690:	79e2                	ld	s3,56(sp)
    80001692:	7aa2                	ld	s5,40(sp)
    80001694:	6ca2                	ld	s9,8(sp)
    80001696:	6d02                	ld	s10,0(sp)
    80001698:	a831                	j	800016b4 <copyout+0xd2>
        return -1;
    8000169a:	557d                	li	a0,-1
    8000169c:	6906                	ld	s2,64(sp)
    8000169e:	79e2                	ld	s3,56(sp)
    800016a0:	7aa2                	ld	s5,40(sp)
    800016a2:	6ca2                	ld	s9,8(sp)
    800016a4:	6d02                	ld	s10,0(sp)
    800016a6:	a039                	j	800016b4 <copyout+0xd2>
      return -1;
    800016a8:	557d                	li	a0,-1
    800016aa:	6906                	ld	s2,64(sp)
    800016ac:	79e2                	ld	s3,56(sp)
    800016ae:	7aa2                	ld	s5,40(sp)
    800016b0:	6ca2                	ld	s9,8(sp)
    800016b2:	6d02                	ld	s10,0(sp)
}
    800016b4:	60e6                	ld	ra,88(sp)
    800016b6:	6446                	ld	s0,80(sp)
    800016b8:	64a6                	ld	s1,72(sp)
    800016ba:	7a42                	ld	s4,48(sp)
    800016bc:	7b02                	ld	s6,32(sp)
    800016be:	6be2                	ld	s7,24(sp)
    800016c0:	6c42                	ld	s8,16(sp)
    800016c2:	6125                	addi	sp,sp,96
    800016c4:	8082                	ret

00000000800016c6 <copyin>:
  while(len > 0){
    800016c6:	c6c9                	beqz	a3,80001750 <copyin+0x8a>
{
    800016c8:	715d                	addi	sp,sp,-80
    800016ca:	e486                	sd	ra,72(sp)
    800016cc:	e0a2                	sd	s0,64(sp)
    800016ce:	fc26                	sd	s1,56(sp)
    800016d0:	f84a                	sd	s2,48(sp)
    800016d2:	f44e                	sd	s3,40(sp)
    800016d4:	f052                	sd	s4,32(sp)
    800016d6:	ec56                	sd	s5,24(sp)
    800016d8:	e85a                	sd	s6,16(sp)
    800016da:	e45e                	sd	s7,8(sp)
    800016dc:	e062                	sd	s8,0(sp)
    800016de:	0880                	addi	s0,sp,80
    800016e0:	8baa                	mv	s7,a0
    800016e2:	8aae                	mv	s5,a1
    800016e4:	8932                	mv	s2,a2
    800016e6:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    800016e8:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800016ea:	6b05                	lui	s6,0x1
    800016ec:	a035                	j	80001718 <copyin+0x52>
    800016ee:	412984b3          	sub	s1,s3,s2
    800016f2:	94da                	add	s1,s1,s6
    if(n > len)
    800016f4:	009a7363          	bgeu	s4,s1,800016fa <copyin+0x34>
    800016f8:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800016fa:	413905b3          	sub	a1,s2,s3
    800016fe:	0004861b          	sext.w	a2,s1
    80001702:	95aa                	add	a1,a1,a0
    80001704:	8556                	mv	a0,s5
    80001706:	df8ff0ef          	jal	80000cfe <memmove>
    len -= n;
    8000170a:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000170e:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    80001710:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001714:	020a0163          	beqz	s4,80001736 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    80001718:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    8000171c:	85ce                	mv	a1,s3
    8000171e:	855e                	mv	a0,s7
    80001720:	891ff0ef          	jal	80000fb0 <walkaddr>
    if(pa0 == 0) {
    80001724:	f569                	bnez	a0,800016ee <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001726:	4601                	li	a2,0
    80001728:	85ce                	mv	a1,s3
    8000172a:	855e                	mv	a0,s7
    8000172c:	e35ff0ef          	jal	80001560 <vmfault>
    80001730:	fd5d                	bnez	a0,800016ee <copyin+0x28>
        return -1;
    80001732:	557d                	li	a0,-1
    80001734:	a011                	j	80001738 <copyin+0x72>
  return 0;
    80001736:	4501                	li	a0,0
}
    80001738:	60a6                	ld	ra,72(sp)
    8000173a:	6406                	ld	s0,64(sp)
    8000173c:	74e2                	ld	s1,56(sp)
    8000173e:	7942                	ld	s2,48(sp)
    80001740:	79a2                	ld	s3,40(sp)
    80001742:	7a02                	ld	s4,32(sp)
    80001744:	6ae2                	ld	s5,24(sp)
    80001746:	6b42                	ld	s6,16(sp)
    80001748:	6ba2                	ld	s7,8(sp)
    8000174a:	6c02                	ld	s8,0(sp)
    8000174c:	6161                	addi	sp,sp,80
    8000174e:	8082                	ret
  return 0;
    80001750:	4501                	li	a0,0
}
    80001752:	8082                	ret

0000000080001754 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001754:	7139                	addi	sp,sp,-64
    80001756:	fc06                	sd	ra,56(sp)
    80001758:	f822                	sd	s0,48(sp)
    8000175a:	f426                	sd	s1,40(sp)
    8000175c:	f04a                	sd	s2,32(sp)
    8000175e:	ec4e                	sd	s3,24(sp)
    80001760:	e852                	sd	s4,16(sp)
    80001762:	e456                	sd	s5,8(sp)
    80001764:	e05a                	sd	s6,0(sp)
    80001766:	0080                	addi	s0,sp,64
    80001768:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    8000176a:	00011497          	auipc	s1,0x11
    8000176e:	05e48493          	addi	s1,s1,94 # 800127c8 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80001772:	8b26                	mv	s6,s1
    80001774:	00a36937          	lui	s2,0xa36
    80001778:	77d90913          	addi	s2,s2,1917 # a3677d <_entry-0x7f5c9883>
    8000177c:	0932                	slli	s2,s2,0xc
    8000177e:	46d90913          	addi	s2,s2,1133
    80001782:	0936                	slli	s2,s2,0xd
    80001784:	df590913          	addi	s2,s2,-523
    80001788:	093a                	slli	s2,s2,0xe
    8000178a:	6cf90913          	addi	s2,s2,1743
    8000178e:	040009b7          	lui	s3,0x4000
    80001792:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001794:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001796:	00017a97          	auipc	s5,0x17
    8000179a:	e32a8a93          	addi	s5,s5,-462 # 800185c8 <tickslock>
    char *pa = kalloc();
    8000179e:	b60ff0ef          	jal	80000afe <kalloc>
    800017a2:	862a                	mv	a2,a0
    if(pa == 0)
    800017a4:	cd15                	beqz	a0,800017e0 <proc_mapstacks+0x8c>
    uint64 va = KSTACK((int) (p - proc));
    800017a6:	416485b3          	sub	a1,s1,s6
    800017aa:	858d                	srai	a1,a1,0x3
    800017ac:	032585b3          	mul	a1,a1,s2
    800017b0:	2585                	addiw	a1,a1,1
    800017b2:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017b6:	4719                	li	a4,6
    800017b8:	6685                	lui	a3,0x1
    800017ba:	40b985b3          	sub	a1,s3,a1
    800017be:	8552                	mv	a0,s4
    800017c0:	8dfff0ef          	jal	8000109e <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    800017c4:	17848493          	addi	s1,s1,376
    800017c8:	fd549be3          	bne	s1,s5,8000179e <proc_mapstacks+0x4a>
  }
}
    800017cc:	70e2                	ld	ra,56(sp)
    800017ce:	7442                	ld	s0,48(sp)
    800017d0:	74a2                	ld	s1,40(sp)
    800017d2:	7902                	ld	s2,32(sp)
    800017d4:	69e2                	ld	s3,24(sp)
    800017d6:	6a42                	ld	s4,16(sp)
    800017d8:	6aa2                	ld	s5,8(sp)
    800017da:	6b02                	ld	s6,0(sp)
    800017dc:	6121                	addi	sp,sp,64
    800017de:	8082                	ret
      panic("kalloc");
    800017e0:	00006517          	auipc	a0,0x6
    800017e4:	97850513          	addi	a0,a0,-1672 # 80007158 <etext+0x158>
    800017e8:	ff9fe0ef          	jal	800007e0 <panic>

00000000800017ec <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800017ec:	7139                	addi	sp,sp,-64
    800017ee:	fc06                	sd	ra,56(sp)
    800017f0:	f822                	sd	s0,48(sp)
    800017f2:	f426                	sd	s1,40(sp)
    800017f4:	f04a                	sd	s2,32(sp)
    800017f6:	ec4e                	sd	s3,24(sp)
    800017f8:	e852                	sd	s4,16(sp)
    800017fa:	e456                	sd	s5,8(sp)
    800017fc:	e05a                	sd	s6,0(sp)
    800017fe:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001800:	00006597          	auipc	a1,0x6
    80001804:	96058593          	addi	a1,a1,-1696 # 80007160 <etext+0x160>
    80001808:	00011517          	auipc	a0,0x11
    8000180c:	b9050513          	addi	a0,a0,-1136 # 80012398 <pid_lock>
    80001810:	b3eff0ef          	jal	80000b4e <initlock>
  initlock(&wait_lock, "wait_lock");
    80001814:	00006597          	auipc	a1,0x6
    80001818:	95458593          	addi	a1,a1,-1708 # 80007168 <etext+0x168>
    8000181c:	00011517          	auipc	a0,0x11
    80001820:	b9450513          	addi	a0,a0,-1132 # 800123b0 <wait_lock>
    80001824:	b2aff0ef          	jal	80000b4e <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001828:	00011497          	auipc	s1,0x11
    8000182c:	fa048493          	addi	s1,s1,-96 # 800127c8 <proc>
      initlock(&p->lock, "proc");
    80001830:	00006b17          	auipc	s6,0x6
    80001834:	948b0b13          	addi	s6,s6,-1720 # 80007178 <etext+0x178>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001838:	8aa6                	mv	s5,s1
    8000183a:	00a36937          	lui	s2,0xa36
    8000183e:	77d90913          	addi	s2,s2,1917 # a3677d <_entry-0x7f5c9883>
    80001842:	0932                	slli	s2,s2,0xc
    80001844:	46d90913          	addi	s2,s2,1133
    80001848:	0936                	slli	s2,s2,0xd
    8000184a:	df590913          	addi	s2,s2,-523
    8000184e:	093a                	slli	s2,s2,0xe
    80001850:	6cf90913          	addi	s2,s2,1743
    80001854:	040009b7          	lui	s3,0x4000
    80001858:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000185a:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    8000185c:	00017a17          	auipc	s4,0x17
    80001860:	d6ca0a13          	addi	s4,s4,-660 # 800185c8 <tickslock>
      initlock(&p->lock, "proc");
    80001864:	85da                	mv	a1,s6
    80001866:	8526                	mv	a0,s1
    80001868:	ae6ff0ef          	jal	80000b4e <initlock>
      p->state = UNUSED;
    8000186c:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001870:	415487b3          	sub	a5,s1,s5
    80001874:	878d                	srai	a5,a5,0x3
    80001876:	032787b3          	mul	a5,a5,s2
    8000187a:	2785                	addiw	a5,a5,1 # fffffffffffff001 <end+0xffffffff7ffdb659>
    8000187c:	00d7979b          	slliw	a5,a5,0xd
    80001880:	40f987b3          	sub	a5,s3,a5
    80001884:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001886:	17848493          	addi	s1,s1,376
    8000188a:	fd449de3          	bne	s1,s4,80001864 <procinit+0x78>
  }
}
    8000188e:	70e2                	ld	ra,56(sp)
    80001890:	7442                	ld	s0,48(sp)
    80001892:	74a2                	ld	s1,40(sp)
    80001894:	7902                	ld	s2,32(sp)
    80001896:	69e2                	ld	s3,24(sp)
    80001898:	6a42                	ld	s4,16(sp)
    8000189a:	6aa2                	ld	s5,8(sp)
    8000189c:	6b02                	ld	s6,0(sp)
    8000189e:	6121                	addi	sp,sp,64
    800018a0:	8082                	ret

00000000800018a2 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018a2:	1141                	addi	sp,sp,-16
    800018a4:	e422                	sd	s0,8(sp)
    800018a6:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800018a8:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018aa:	2501                	sext.w	a0,a0
    800018ac:	6422                	ld	s0,8(sp)
    800018ae:	0141                	addi	sp,sp,16
    800018b0:	8082                	ret

00000000800018b2 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    800018b2:	1141                	addi	sp,sp,-16
    800018b4:	e422                	sd	s0,8(sp)
    800018b6:	0800                	addi	s0,sp,16
    800018b8:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800018ba:	2781                	sext.w	a5,a5
    800018bc:	079e                	slli	a5,a5,0x7
  return c;
}
    800018be:	00011517          	auipc	a0,0x11
    800018c2:	b0a50513          	addi	a0,a0,-1270 # 800123c8 <cpus>
    800018c6:	953e                	add	a0,a0,a5
    800018c8:	6422                	ld	s0,8(sp)
    800018ca:	0141                	addi	sp,sp,16
    800018cc:	8082                	ret

00000000800018ce <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    800018ce:	1101                	addi	sp,sp,-32
    800018d0:	ec06                	sd	ra,24(sp)
    800018d2:	e822                	sd	s0,16(sp)
    800018d4:	e426                	sd	s1,8(sp)
    800018d6:	1000                	addi	s0,sp,32
  push_off();
    800018d8:	ab6ff0ef          	jal	80000b8e <push_off>
    800018dc:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800018de:	2781                	sext.w	a5,a5
    800018e0:	079e                	slli	a5,a5,0x7
    800018e2:	00011717          	auipc	a4,0x11
    800018e6:	ab670713          	addi	a4,a4,-1354 # 80012398 <pid_lock>
    800018ea:	97ba                	add	a5,a5,a4
    800018ec:	7b84                	ld	s1,48(a5)
  pop_off();
    800018ee:	b24ff0ef          	jal	80000c12 <pop_off>
  return p;
}
    800018f2:	8526                	mv	a0,s1
    800018f4:	60e2                	ld	ra,24(sp)
    800018f6:	6442                	ld	s0,16(sp)
    800018f8:	64a2                	ld	s1,8(sp)
    800018fa:	6105                	addi	sp,sp,32
    800018fc:	8082                	ret

00000000800018fe <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    800018fe:	7179                	addi	sp,sp,-48
    80001900:	f406                	sd	ra,40(sp)
    80001902:	f022                	sd	s0,32(sp)
    80001904:	ec26                	sd	s1,24(sp)
    80001906:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001908:	fc7ff0ef          	jal	800018ce <myproc>
    8000190c:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    8000190e:	b58ff0ef          	jal	80000c66 <release>

  if (first) {
    80001912:	00009797          	auipc	a5,0x9
    80001916:	92e7a783          	lw	a5,-1746(a5) # 8000a240 <first.1>
    8000191a:	cf8d                	beqz	a5,80001954 <forkret+0x56>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    8000191c:	4505                	li	a0,1
    8000191e:	59b010ef          	jal	800036b8 <fsinit>

    first = 0;
    80001922:	00009797          	auipc	a5,0x9
    80001926:	9007af23          	sw	zero,-1762(a5) # 8000a240 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    8000192a:	0330000f          	fence	rw,rw

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    8000192e:	00006517          	auipc	a0,0x6
    80001932:	85250513          	addi	a0,a0,-1966 # 80007180 <etext+0x180>
    80001936:	fca43823          	sd	a0,-48(s0)
    8000193a:	fc043c23          	sd	zero,-40(s0)
    8000193e:	fd040593          	addi	a1,s0,-48
    80001942:	681020ef          	jal	800047c2 <kexec>
    80001946:	6cbc                	ld	a5,88(s1)
    80001948:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    8000194a:	6cbc                	ld	a5,88(s1)
    8000194c:	7bb8                	ld	a4,112(a5)
    8000194e:	57fd                	li	a5,-1
    80001950:	02f70d63          	beq	a4,a5,8000198a <forkret+0x8c>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001954:	361000ef          	jal	800024b4 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001958:	68a8                	ld	a0,80(s1)
    8000195a:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    8000195c:	04000737          	lui	a4,0x4000
    80001960:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001962:	0732                	slli	a4,a4,0xc
    80001964:	00004797          	auipc	a5,0x4
    80001968:	73878793          	addi	a5,a5,1848 # 8000609c <userret>
    8000196c:	00004697          	auipc	a3,0x4
    80001970:	69468693          	addi	a3,a3,1684 # 80006000 <_trampoline>
    80001974:	8f95                	sub	a5,a5,a3
    80001976:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001978:	577d                	li	a4,-1
    8000197a:	177e                	slli	a4,a4,0x3f
    8000197c:	8d59                	or	a0,a0,a4
    8000197e:	9782                	jalr	a5
}
    80001980:	70a2                	ld	ra,40(sp)
    80001982:	7402                	ld	s0,32(sp)
    80001984:	64e2                	ld	s1,24(sp)
    80001986:	6145                	addi	sp,sp,48
    80001988:	8082                	ret
      panic("exec");
    8000198a:	00005517          	auipc	a0,0x5
    8000198e:	7fe50513          	addi	a0,a0,2046 # 80007188 <etext+0x188>
    80001992:	e4ffe0ef          	jal	800007e0 <panic>

0000000080001996 <allocpid>:
{
    80001996:	1101                	addi	sp,sp,-32
    80001998:	ec06                	sd	ra,24(sp)
    8000199a:	e822                	sd	s0,16(sp)
    8000199c:	e426                	sd	s1,8(sp)
    8000199e:	e04a                	sd	s2,0(sp)
    800019a0:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    800019a2:	00011917          	auipc	s2,0x11
    800019a6:	9f690913          	addi	s2,s2,-1546 # 80012398 <pid_lock>
    800019aa:	854a                	mv	a0,s2
    800019ac:	a22ff0ef          	jal	80000bce <acquire>
  pid = nextpid;
    800019b0:	00009797          	auipc	a5,0x9
    800019b4:	89478793          	addi	a5,a5,-1900 # 8000a244 <nextpid>
    800019b8:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019ba:	0014871b          	addiw	a4,s1,1
    800019be:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019c0:	854a                	mv	a0,s2
    800019c2:	aa4ff0ef          	jal	80000c66 <release>
}
    800019c6:	8526                	mv	a0,s1
    800019c8:	60e2                	ld	ra,24(sp)
    800019ca:	6442                	ld	s0,16(sp)
    800019cc:	64a2                	ld	s1,8(sp)
    800019ce:	6902                	ld	s2,0(sp)
    800019d0:	6105                	addi	sp,sp,32
    800019d2:	8082                	ret

00000000800019d4 <proc_pagetable>:
{
    800019d4:	1101                	addi	sp,sp,-32
    800019d6:	ec06                	sd	ra,24(sp)
    800019d8:	e822                	sd	s0,16(sp)
    800019da:	e426                	sd	s1,8(sp)
    800019dc:	e04a                	sd	s2,0(sp)
    800019de:	1000                	addi	s0,sp,32
    800019e0:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019e2:	fb2ff0ef          	jal	80001194 <uvmcreate>
    800019e6:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800019e8:	cd05                	beqz	a0,80001a20 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    800019ea:	4729                	li	a4,10
    800019ec:	00004697          	auipc	a3,0x4
    800019f0:	61468693          	addi	a3,a3,1556 # 80006000 <_trampoline>
    800019f4:	6605                	lui	a2,0x1
    800019f6:	040005b7          	lui	a1,0x4000
    800019fa:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019fc:	05b2                	slli	a1,a1,0xc
    800019fe:	df0ff0ef          	jal	80000fee <mappages>
    80001a02:	02054663          	bltz	a0,80001a2e <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a06:	4719                	li	a4,6
    80001a08:	05893683          	ld	a3,88(s2)
    80001a0c:	6605                	lui	a2,0x1
    80001a0e:	020005b7          	lui	a1,0x2000
    80001a12:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a14:	05b6                	slli	a1,a1,0xd
    80001a16:	8526                	mv	a0,s1
    80001a18:	dd6ff0ef          	jal	80000fee <mappages>
    80001a1c:	00054f63          	bltz	a0,80001a3a <proc_pagetable+0x66>
}
    80001a20:	8526                	mv	a0,s1
    80001a22:	60e2                	ld	ra,24(sp)
    80001a24:	6442                	ld	s0,16(sp)
    80001a26:	64a2                	ld	s1,8(sp)
    80001a28:	6902                	ld	s2,0(sp)
    80001a2a:	6105                	addi	sp,sp,32
    80001a2c:	8082                	ret
    uvmfree(pagetable, 0);
    80001a2e:	4581                	li	a1,0
    80001a30:	8526                	mv	a0,s1
    80001a32:	95dff0ef          	jal	8000138e <uvmfree>
    return 0;
    80001a36:	4481                	li	s1,0
    80001a38:	b7e5                	j	80001a20 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a3a:	4681                	li	a3,0
    80001a3c:	4605                	li	a2,1
    80001a3e:	040005b7          	lui	a1,0x4000
    80001a42:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a44:	05b2                	slli	a1,a1,0xc
    80001a46:	8526                	mv	a0,s1
    80001a48:	f72ff0ef          	jal	800011ba <uvmunmap>
    uvmfree(pagetable, 0);
    80001a4c:	4581                	li	a1,0
    80001a4e:	8526                	mv	a0,s1
    80001a50:	93fff0ef          	jal	8000138e <uvmfree>
    return 0;
    80001a54:	4481                	li	s1,0
    80001a56:	b7e9                	j	80001a20 <proc_pagetable+0x4c>

0000000080001a58 <proc_freepagetable>:
{
    80001a58:	1101                	addi	sp,sp,-32
    80001a5a:	ec06                	sd	ra,24(sp)
    80001a5c:	e822                	sd	s0,16(sp)
    80001a5e:	e426                	sd	s1,8(sp)
    80001a60:	e04a                	sd	s2,0(sp)
    80001a62:	1000                	addi	s0,sp,32
    80001a64:	84aa                	mv	s1,a0
    80001a66:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a68:	4681                	li	a3,0
    80001a6a:	4605                	li	a2,1
    80001a6c:	040005b7          	lui	a1,0x4000
    80001a70:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a72:	05b2                	slli	a1,a1,0xc
    80001a74:	f46ff0ef          	jal	800011ba <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a78:	4681                	li	a3,0
    80001a7a:	4605                	li	a2,1
    80001a7c:	020005b7          	lui	a1,0x2000
    80001a80:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a82:	05b6                	slli	a1,a1,0xd
    80001a84:	8526                	mv	a0,s1
    80001a86:	f34ff0ef          	jal	800011ba <uvmunmap>
  uvmfree(pagetable, sz);
    80001a8a:	85ca                	mv	a1,s2
    80001a8c:	8526                	mv	a0,s1
    80001a8e:	901ff0ef          	jal	8000138e <uvmfree>
}
    80001a92:	60e2                	ld	ra,24(sp)
    80001a94:	6442                	ld	s0,16(sp)
    80001a96:	64a2                	ld	s1,8(sp)
    80001a98:	6902                	ld	s2,0(sp)
    80001a9a:	6105                	addi	sp,sp,32
    80001a9c:	8082                	ret

0000000080001a9e <freeproc>:
{
    80001a9e:	1101                	addi	sp,sp,-32
    80001aa0:	ec06                	sd	ra,24(sp)
    80001aa2:	e822                	sd	s0,16(sp)
    80001aa4:	e426                	sd	s1,8(sp)
    80001aa6:	1000                	addi	s0,sp,32
    80001aa8:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001aaa:	6d28                	ld	a0,88(a0)
    80001aac:	c119                	beqz	a0,80001ab2 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001aae:	f6ffe0ef          	jal	80000a1c <kfree>
  p->trapframe = 0;
    80001ab2:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001ab6:	68a8                	ld	a0,80(s1)
    80001ab8:	c501                	beqz	a0,80001ac0 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001aba:	64ac                	ld	a1,72(s1)
    80001abc:	f9dff0ef          	jal	80001a58 <proc_freepagetable>
  p->pagetable = 0;
    80001ac0:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001ac4:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001ac8:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001acc:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001ad0:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001ad4:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001ad8:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001adc:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001ae0:	0004ac23          	sw	zero,24(s1)
}
    80001ae4:	60e2                	ld	ra,24(sp)
    80001ae6:	6442                	ld	s0,16(sp)
    80001ae8:	64a2                	ld	s1,8(sp)
    80001aea:	6105                	addi	sp,sp,32
    80001aec:	8082                	ret

0000000080001aee <allocproc>:
{
    80001aee:	1101                	addi	sp,sp,-32
    80001af0:	ec06                	sd	ra,24(sp)
    80001af2:	e822                	sd	s0,16(sp)
    80001af4:	e426                	sd	s1,8(sp)
    80001af6:	e04a                	sd	s2,0(sp)
    80001af8:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001afa:	00011497          	auipc	s1,0x11
    80001afe:	cce48493          	addi	s1,s1,-818 # 800127c8 <proc>
    80001b02:	00017917          	auipc	s2,0x17
    80001b06:	ac690913          	addi	s2,s2,-1338 # 800185c8 <tickslock>
    acquire(&p->lock);
    80001b0a:	8526                	mv	a0,s1
    80001b0c:	8c2ff0ef          	jal	80000bce <acquire>
    if(p->state == UNUSED) {
    80001b10:	4c9c                	lw	a5,24(s1)
    80001b12:	cb91                	beqz	a5,80001b26 <allocproc+0x38>
      release(&p->lock);
    80001b14:	8526                	mv	a0,s1
    80001b16:	950ff0ef          	jal	80000c66 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b1a:	17848493          	addi	s1,s1,376
    80001b1e:	ff2496e3          	bne	s1,s2,80001b0a <allocproc+0x1c>
  return 0;
    80001b22:	4481                	li	s1,0
    80001b24:	a881                	j	80001b74 <allocproc+0x86>
  p->pid = allocpid();
    80001b26:	e71ff0ef          	jal	80001996 <allocpid>
    80001b2a:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b2c:	4785                	li	a5,1
    80001b2e:	cc9c                	sw	a5,24(s1)
  p->priority = 10;    // Default priority
    80001b30:	47a9                	li	a5,10
    80001b32:	16f4a623          	sw	a5,364(s1)
  p->age = 0;
    80001b36:	1604a823          	sw	zero,368(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001b3a:	fc5fe0ef          	jal	80000afe <kalloc>
    80001b3e:	892a                	mv	s2,a0
    80001b40:	eca8                	sd	a0,88(s1)
    80001b42:	c121                	beqz	a0,80001b82 <allocproc+0x94>
  p->pagetable = proc_pagetable(p);
    80001b44:	8526                	mv	a0,s1
    80001b46:	e8fff0ef          	jal	800019d4 <proc_pagetable>
    80001b4a:	892a                	mv	s2,a0
    80001b4c:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001b4e:	c131                	beqz	a0,80001b92 <allocproc+0xa4>
  memset(&p->context, 0, sizeof(p->context));
    80001b50:	07000613          	li	a2,112
    80001b54:	4581                	li	a1,0
    80001b56:	06048513          	addi	a0,s1,96
    80001b5a:	948ff0ef          	jal	80000ca2 <memset>
  p->context.ra = (uint64)forkret;
    80001b5e:	00000797          	auipc	a5,0x0
    80001b62:	da078793          	addi	a5,a5,-608 # 800018fe <forkret>
    80001b66:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b68:	60bc                	ld	a5,64(s1)
    80001b6a:	6705                	lui	a4,0x1
    80001b6c:	97ba                	add	a5,a5,a4
    80001b6e:	f4bc                	sd	a5,104(s1)
  p->ticks_used = 0; // NEW
    80001b70:	1604a423          	sw	zero,360(s1)
}
    80001b74:	8526                	mv	a0,s1
    80001b76:	60e2                	ld	ra,24(sp)
    80001b78:	6442                	ld	s0,16(sp)
    80001b7a:	64a2                	ld	s1,8(sp)
    80001b7c:	6902                	ld	s2,0(sp)
    80001b7e:	6105                	addi	sp,sp,32
    80001b80:	8082                	ret
    freeproc(p);
    80001b82:	8526                	mv	a0,s1
    80001b84:	f1bff0ef          	jal	80001a9e <freeproc>
    release(&p->lock);
    80001b88:	8526                	mv	a0,s1
    80001b8a:	8dcff0ef          	jal	80000c66 <release>
    return 0;
    80001b8e:	84ca                	mv	s1,s2
    80001b90:	b7d5                	j	80001b74 <allocproc+0x86>
    freeproc(p);
    80001b92:	8526                	mv	a0,s1
    80001b94:	f0bff0ef          	jal	80001a9e <freeproc>
    release(&p->lock);
    80001b98:	8526                	mv	a0,s1
    80001b9a:	8ccff0ef          	jal	80000c66 <release>
    return 0;
    80001b9e:	84ca                	mv	s1,s2
    80001ba0:	bfd1                	j	80001b74 <allocproc+0x86>

0000000080001ba2 <userinit>:
{
    80001ba2:	1101                	addi	sp,sp,-32
    80001ba4:	ec06                	sd	ra,24(sp)
    80001ba6:	e822                	sd	s0,16(sp)
    80001ba8:	e426                	sd	s1,8(sp)
    80001baa:	1000                	addi	s0,sp,32
  p = allocproc();
    80001bac:	f43ff0ef          	jal	80001aee <allocproc>
    80001bb0:	84aa                	mv	s1,a0
  initproc = p;
    80001bb2:	00008797          	auipc	a5,0x8
    80001bb6:	6ca7bf23          	sd	a0,1758(a5) # 8000a290 <initproc>
  p->cwd = namei("/");
    80001bba:	00005517          	auipc	a0,0x5
    80001bbe:	5d650513          	addi	a0,a0,1494 # 80007190 <etext+0x190>
    80001bc2:	018020ef          	jal	80003bda <namei>
    80001bc6:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001bca:	478d                	li	a5,3
    80001bcc:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bce:	8526                	mv	a0,s1
    80001bd0:	896ff0ef          	jal	80000c66 <release>
}
    80001bd4:	60e2                	ld	ra,24(sp)
    80001bd6:	6442                	ld	s0,16(sp)
    80001bd8:	64a2                	ld	s1,8(sp)
    80001bda:	6105                	addi	sp,sp,32
    80001bdc:	8082                	ret

0000000080001bde <growproc>:
{
    80001bde:	1101                	addi	sp,sp,-32
    80001be0:	ec06                	sd	ra,24(sp)
    80001be2:	e822                	sd	s0,16(sp)
    80001be4:	e426                	sd	s1,8(sp)
    80001be6:	e04a                	sd	s2,0(sp)
    80001be8:	1000                	addi	s0,sp,32
    80001bea:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001bec:	ce3ff0ef          	jal	800018ce <myproc>
    80001bf0:	892a                	mv	s2,a0
  sz = p->sz;
    80001bf2:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001bf4:	02905963          	blez	s1,80001c26 <growproc+0x48>
    if(sz + n > TRAPFRAME) {
    80001bf8:	00b48633          	add	a2,s1,a1
    80001bfc:	020007b7          	lui	a5,0x2000
    80001c00:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001c02:	07b6                	slli	a5,a5,0xd
    80001c04:	02c7ea63          	bltu	a5,a2,80001c38 <growproc+0x5a>
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c08:	4691                	li	a3,4
    80001c0a:	6928                	ld	a0,80(a0)
    80001c0c:	e7cff0ef          	jal	80001288 <uvmalloc>
    80001c10:	85aa                	mv	a1,a0
    80001c12:	c50d                	beqz	a0,80001c3c <growproc+0x5e>
  p->sz = sz;
    80001c14:	04b93423          	sd	a1,72(s2)
  return 0;
    80001c18:	4501                	li	a0,0
}
    80001c1a:	60e2                	ld	ra,24(sp)
    80001c1c:	6442                	ld	s0,16(sp)
    80001c1e:	64a2                	ld	s1,8(sp)
    80001c20:	6902                	ld	s2,0(sp)
    80001c22:	6105                	addi	sp,sp,32
    80001c24:	8082                	ret
  } else if(n < 0){
    80001c26:	fe04d7e3          	bgez	s1,80001c14 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c2a:	00b48633          	add	a2,s1,a1
    80001c2e:	6928                	ld	a0,80(a0)
    80001c30:	e14ff0ef          	jal	80001244 <uvmdealloc>
    80001c34:	85aa                	mv	a1,a0
    80001c36:	bff9                	j	80001c14 <growproc+0x36>
      return -1;
    80001c38:	557d                	li	a0,-1
    80001c3a:	b7c5                	j	80001c1a <growproc+0x3c>
      return -1;
    80001c3c:	557d                	li	a0,-1
    80001c3e:	bff1                	j	80001c1a <growproc+0x3c>

0000000080001c40 <kfork>:
{
    80001c40:	7139                	addi	sp,sp,-64
    80001c42:	fc06                	sd	ra,56(sp)
    80001c44:	f822                	sd	s0,48(sp)
    80001c46:	f04a                	sd	s2,32(sp)
    80001c48:	e456                	sd	s5,8(sp)
    80001c4a:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c4c:	c83ff0ef          	jal	800018ce <myproc>
    80001c50:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c52:	e9dff0ef          	jal	80001aee <allocproc>
    80001c56:	0e050a63          	beqz	a0,80001d4a <kfork+0x10a>
    80001c5a:	e852                	sd	s4,16(sp)
    80001c5c:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001c5e:	048ab603          	ld	a2,72(s5)
    80001c62:	692c                	ld	a1,80(a0)
    80001c64:	050ab503          	ld	a0,80(s5)
    80001c68:	f58ff0ef          	jal	800013c0 <uvmcopy>
    80001c6c:	04054a63          	bltz	a0,80001cc0 <kfork+0x80>
    80001c70:	f426                	sd	s1,40(sp)
    80001c72:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c74:	048ab783          	ld	a5,72(s5)
    80001c78:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c7c:	058ab683          	ld	a3,88(s5)
    80001c80:	87b6                	mv	a5,a3
    80001c82:	058a3703          	ld	a4,88(s4)
    80001c86:	12068693          	addi	a3,a3,288
    80001c8a:	0007b803          	ld	a6,0(a5)
    80001c8e:	6788                	ld	a0,8(a5)
    80001c90:	6b8c                	ld	a1,16(a5)
    80001c92:	6f90                	ld	a2,24(a5)
    80001c94:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001c98:	e708                	sd	a0,8(a4)
    80001c9a:	eb0c                	sd	a1,16(a4)
    80001c9c:	ef10                	sd	a2,24(a4)
    80001c9e:	02078793          	addi	a5,a5,32
    80001ca2:	02070713          	addi	a4,a4,32
    80001ca6:	fed792e3          	bne	a5,a3,80001c8a <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001caa:	058a3783          	ld	a5,88(s4)
    80001cae:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001cb2:	0d0a8493          	addi	s1,s5,208
    80001cb6:	0d0a0913          	addi	s2,s4,208
    80001cba:	150a8993          	addi	s3,s5,336
    80001cbe:	a831                	j	80001cda <kfork+0x9a>
    freeproc(np);
    80001cc0:	8552                	mv	a0,s4
    80001cc2:	dddff0ef          	jal	80001a9e <freeproc>
    release(&np->lock);
    80001cc6:	8552                	mv	a0,s4
    80001cc8:	f9ffe0ef          	jal	80000c66 <release>
    return -1;
    80001ccc:	597d                	li	s2,-1
    80001cce:	6a42                	ld	s4,16(sp)
    80001cd0:	a0b5                	j	80001d3c <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001cd2:	04a1                	addi	s1,s1,8
    80001cd4:	0921                	addi	s2,s2,8
    80001cd6:	01348963          	beq	s1,s3,80001ce8 <kfork+0xa8>
    if(p->ofile[i])
    80001cda:	6088                	ld	a0,0(s1)
    80001cdc:	d97d                	beqz	a0,80001cd2 <kfork+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001cde:	496020ef          	jal	80004174 <filedup>
    80001ce2:	00a93023          	sd	a0,0(s2)
    80001ce6:	b7f5                	j	80001cd2 <kfork+0x92>
  np->cwd = idup(p->cwd);
    80001ce8:	150ab503          	ld	a0,336(s5)
    80001cec:	6a2010ef          	jal	8000338e <idup>
    80001cf0:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cf4:	4641                	li	a2,16
    80001cf6:	158a8593          	addi	a1,s5,344
    80001cfa:	158a0513          	addi	a0,s4,344
    80001cfe:	8e2ff0ef          	jal	80000de0 <safestrcpy>
  pid = np->pid;
    80001d02:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001d06:	8552                	mv	a0,s4
    80001d08:	f5ffe0ef          	jal	80000c66 <release>
  acquire(&wait_lock);
    80001d0c:	00010497          	auipc	s1,0x10
    80001d10:	6a448493          	addi	s1,s1,1700 # 800123b0 <wait_lock>
    80001d14:	8526                	mv	a0,s1
    80001d16:	eb9fe0ef          	jal	80000bce <acquire>
  np->parent = p;
    80001d1a:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d1e:	8526                	mv	a0,s1
    80001d20:	f47fe0ef          	jal	80000c66 <release>
  acquire(&np->lock);
    80001d24:	8552                	mv	a0,s4
    80001d26:	ea9fe0ef          	jal	80000bce <acquire>
  np->state = RUNNABLE;
    80001d2a:	478d                	li	a5,3
    80001d2c:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d30:	8552                	mv	a0,s4
    80001d32:	f35fe0ef          	jal	80000c66 <release>
  return pid;
    80001d36:	74a2                	ld	s1,40(sp)
    80001d38:	69e2                	ld	s3,24(sp)
    80001d3a:	6a42                	ld	s4,16(sp)
}
    80001d3c:	854a                	mv	a0,s2
    80001d3e:	70e2                	ld	ra,56(sp)
    80001d40:	7442                	ld	s0,48(sp)
    80001d42:	7902                	ld	s2,32(sp)
    80001d44:	6aa2                	ld	s5,8(sp)
    80001d46:	6121                	addi	sp,sp,64
    80001d48:	8082                	ret
    return -1;
    80001d4a:	597d                	li	s2,-1
    80001d4c:	bfc5                	j	80001d3c <kfork+0xfc>

0000000080001d4e <scheduler>:
{
    80001d4e:	715d                	addi	sp,sp,-80
    80001d50:	e486                	sd	ra,72(sp)
    80001d52:	e0a2                	sd	s0,64(sp)
    80001d54:	fc26                	sd	s1,56(sp)
    80001d56:	f84a                	sd	s2,48(sp)
    80001d58:	f44e                	sd	s3,40(sp)
    80001d5a:	f052                	sd	s4,32(sp)
    80001d5c:	ec56                	sd	s5,24(sp)
    80001d5e:	e85a                	sd	s6,16(sp)
    80001d60:	e45e                	sd	s7,8(sp)
    80001d62:	e062                	sd	s8,0(sp)
    80001d64:	0880                	addi	s0,sp,80
    80001d66:	8792                	mv	a5,tp
  int id = r_tp();
    80001d68:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d6a:	00779b13          	slli	s6,a5,0x7
    80001d6e:	00010717          	auipc	a4,0x10
    80001d72:	62a70713          	addi	a4,a4,1578 # 80012398 <pid_lock>
    80001d76:	975a                	add	a4,a4,s6
    80001d78:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d7c:	00010717          	auipc	a4,0x10
    80001d80:	65470713          	addi	a4,a4,1620 # 800123d0 <cpus+0x8>
    80001d84:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001d86:	4c11                	li	s8,4
        c->proc = p;
    80001d88:	079e                	slli	a5,a5,0x7
    80001d8a:	00010a17          	auipc	s4,0x10
    80001d8e:	60ea0a13          	addi	s4,s4,1550 # 80012398 <pid_lock>
    80001d92:	9a3e                	add	s4,s4,a5
        found = 1;
    80001d94:	4b85                	li	s7,1
    for(p = proc; p < &proc[NPROC]; p++) {
    80001d96:	00017997          	auipc	s3,0x17
    80001d9a:	83298993          	addi	s3,s3,-1998 # 800185c8 <tickslock>
    80001d9e:	a089                	j	80001de0 <scheduler+0x92>
      release(&p->lock);
    80001da0:	8526                	mv	a0,s1
    80001da2:	ec5fe0ef          	jal	80000c66 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001da6:	17848493          	addi	s1,s1,376
    80001daa:	03348763          	beq	s1,s3,80001dd8 <scheduler+0x8a>
      acquire(&p->lock);
    80001dae:	8526                	mv	a0,s1
    80001db0:	e1ffe0ef          	jal	80000bce <acquire>
      if(p->state == RUNNABLE) {
    80001db4:	4c9c                	lw	a5,24(s1)
    80001db6:	ff2795e3          	bne	a5,s2,80001da0 <scheduler+0x52>
        p->state = RUNNING;
    80001dba:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001dbe:	029a3823          	sd	s1,48(s4)
        p->ticks_used = 0;    // ADD THIS LINE ONLY
    80001dc2:	1604a423          	sw	zero,360(s1)
        swtch(&c->context, &p->context);
    80001dc6:	06048593          	addi	a1,s1,96
    80001dca:	855a                	mv	a0,s6
    80001dcc:	642000ef          	jal	8000240e <swtch>
        c->proc = 0;
    80001dd0:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001dd4:	8ade                	mv	s5,s7
    80001dd6:	b7e9                	j	80001da0 <scheduler+0x52>
    if(found == 0) {
    80001dd8:	000a9463          	bnez	s5,80001de0 <scheduler+0x92>
      asm volatile("wfi");
    80001ddc:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001de0:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001de4:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001de8:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001dec:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001df0:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001df2:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001df6:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001df8:	00011497          	auipc	s1,0x11
    80001dfc:	9d048493          	addi	s1,s1,-1584 # 800127c8 <proc>
      if(p->state == RUNNABLE) {
    80001e00:	490d                	li	s2,3
    80001e02:	b775                	j	80001dae <scheduler+0x60>

0000000080001e04 <sched>:
{
    80001e04:	7179                	addi	sp,sp,-48
    80001e06:	f406                	sd	ra,40(sp)
    80001e08:	f022                	sd	s0,32(sp)
    80001e0a:	ec26                	sd	s1,24(sp)
    80001e0c:	e84a                	sd	s2,16(sp)
    80001e0e:	e44e                	sd	s3,8(sp)
    80001e10:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e12:	abdff0ef          	jal	800018ce <myproc>
    80001e16:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001e18:	d4dfe0ef          	jal	80000b64 <holding>
    80001e1c:	c92d                	beqz	a0,80001e8e <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e1e:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001e20:	2781                	sext.w	a5,a5
    80001e22:	079e                	slli	a5,a5,0x7
    80001e24:	00010717          	auipc	a4,0x10
    80001e28:	57470713          	addi	a4,a4,1396 # 80012398 <pid_lock>
    80001e2c:	97ba                	add	a5,a5,a4
    80001e2e:	0a87a703          	lw	a4,168(a5)
    80001e32:	4785                	li	a5,1
    80001e34:	06f71363          	bne	a4,a5,80001e9a <sched+0x96>
  if(p->state == RUNNING)
    80001e38:	4c98                	lw	a4,24(s1)
    80001e3a:	4791                	li	a5,4
    80001e3c:	06f70563          	beq	a4,a5,80001ea6 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e40:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e44:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001e46:	e7b5                	bnez	a5,80001eb2 <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e48:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e4a:	00010917          	auipc	s2,0x10
    80001e4e:	54e90913          	addi	s2,s2,1358 # 80012398 <pid_lock>
    80001e52:	2781                	sext.w	a5,a5
    80001e54:	079e                	slli	a5,a5,0x7
    80001e56:	97ca                	add	a5,a5,s2
    80001e58:	0ac7a983          	lw	s3,172(a5)
    80001e5c:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e5e:	2781                	sext.w	a5,a5
    80001e60:	079e                	slli	a5,a5,0x7
    80001e62:	00010597          	auipc	a1,0x10
    80001e66:	56e58593          	addi	a1,a1,1390 # 800123d0 <cpus+0x8>
    80001e6a:	95be                	add	a1,a1,a5
    80001e6c:	06048513          	addi	a0,s1,96
    80001e70:	59e000ef          	jal	8000240e <swtch>
    80001e74:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e76:	2781                	sext.w	a5,a5
    80001e78:	079e                	slli	a5,a5,0x7
    80001e7a:	993e                	add	s2,s2,a5
    80001e7c:	0b392623          	sw	s3,172(s2)
}
    80001e80:	70a2                	ld	ra,40(sp)
    80001e82:	7402                	ld	s0,32(sp)
    80001e84:	64e2                	ld	s1,24(sp)
    80001e86:	6942                	ld	s2,16(sp)
    80001e88:	69a2                	ld	s3,8(sp)
    80001e8a:	6145                	addi	sp,sp,48
    80001e8c:	8082                	ret
    panic("sched p->lock");
    80001e8e:	00005517          	auipc	a0,0x5
    80001e92:	30a50513          	addi	a0,a0,778 # 80007198 <etext+0x198>
    80001e96:	94bfe0ef          	jal	800007e0 <panic>
    panic("sched locks");
    80001e9a:	00005517          	auipc	a0,0x5
    80001e9e:	30e50513          	addi	a0,a0,782 # 800071a8 <etext+0x1a8>
    80001ea2:	93ffe0ef          	jal	800007e0 <panic>
    panic("sched RUNNING");
    80001ea6:	00005517          	auipc	a0,0x5
    80001eaa:	31250513          	addi	a0,a0,786 # 800071b8 <etext+0x1b8>
    80001eae:	933fe0ef          	jal	800007e0 <panic>
    panic("sched interruptible");
    80001eb2:	00005517          	auipc	a0,0x5
    80001eb6:	31650513          	addi	a0,a0,790 # 800071c8 <etext+0x1c8>
    80001eba:	927fe0ef          	jal	800007e0 <panic>

0000000080001ebe <yield>:
{
    80001ebe:	1101                	addi	sp,sp,-32
    80001ec0:	ec06                	sd	ra,24(sp)
    80001ec2:	e822                	sd	s0,16(sp)
    80001ec4:	e426                	sd	s1,8(sp)
    80001ec6:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001ec8:	a07ff0ef          	jal	800018ce <myproc>
    80001ecc:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ece:	d01fe0ef          	jal	80000bce <acquire>
  p->state = RUNNABLE;
    80001ed2:	478d                	li	a5,3
    80001ed4:	cc9c                	sw	a5,24(s1)
  sched();
    80001ed6:	f2fff0ef          	jal	80001e04 <sched>
  release(&p->lock);
    80001eda:	8526                	mv	a0,s1
    80001edc:	d8bfe0ef          	jal	80000c66 <release>
}
    80001ee0:	60e2                	ld	ra,24(sp)
    80001ee2:	6442                	ld	s0,16(sp)
    80001ee4:	64a2                	ld	s1,8(sp)
    80001ee6:	6105                	addi	sp,sp,32
    80001ee8:	8082                	ret

0000000080001eea <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001eea:	7179                	addi	sp,sp,-48
    80001eec:	f406                	sd	ra,40(sp)
    80001eee:	f022                	sd	s0,32(sp)
    80001ef0:	ec26                	sd	s1,24(sp)
    80001ef2:	e84a                	sd	s2,16(sp)
    80001ef4:	e44e                	sd	s3,8(sp)
    80001ef6:	1800                	addi	s0,sp,48
    80001ef8:	89aa                	mv	s3,a0
    80001efa:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001efc:	9d3ff0ef          	jal	800018ce <myproc>
    80001f00:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001f02:	ccdfe0ef          	jal	80000bce <acquire>
  release(lk);
    80001f06:	854a                	mv	a0,s2
    80001f08:	d5ffe0ef          	jal	80000c66 <release>

  // Go to sleep.
  p->chan = chan;
    80001f0c:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001f10:	4789                	li	a5,2
    80001f12:	cc9c                	sw	a5,24(s1)

  sched();
    80001f14:	ef1ff0ef          	jal	80001e04 <sched>

  // Tidy up.
  p->chan = 0;
    80001f18:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001f1c:	8526                	mv	a0,s1
    80001f1e:	d49fe0ef          	jal	80000c66 <release>
  acquire(lk);
    80001f22:	854a                	mv	a0,s2
    80001f24:	cabfe0ef          	jal	80000bce <acquire>
}
    80001f28:	70a2                	ld	ra,40(sp)
    80001f2a:	7402                	ld	s0,32(sp)
    80001f2c:	64e2                	ld	s1,24(sp)
    80001f2e:	6942                	ld	s2,16(sp)
    80001f30:	69a2                	ld	s3,8(sp)
    80001f32:	6145                	addi	sp,sp,48
    80001f34:	8082                	ret

0000000080001f36 <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001f36:	7139                	addi	sp,sp,-64
    80001f38:	fc06                	sd	ra,56(sp)
    80001f3a:	f822                	sd	s0,48(sp)
    80001f3c:	f426                	sd	s1,40(sp)
    80001f3e:	f04a                	sd	s2,32(sp)
    80001f40:	ec4e                	sd	s3,24(sp)
    80001f42:	e852                	sd	s4,16(sp)
    80001f44:	e456                	sd	s5,8(sp)
    80001f46:	0080                	addi	s0,sp,64
    80001f48:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001f4a:	00011497          	auipc	s1,0x11
    80001f4e:	87e48493          	addi	s1,s1,-1922 # 800127c8 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001f52:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001f54:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f56:	00016917          	auipc	s2,0x16
    80001f5a:	67290913          	addi	s2,s2,1650 # 800185c8 <tickslock>
    80001f5e:	a801                	j	80001f6e <wakeup+0x38>
      }
      release(&p->lock);
    80001f60:	8526                	mv	a0,s1
    80001f62:	d05fe0ef          	jal	80000c66 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f66:	17848493          	addi	s1,s1,376
    80001f6a:	03248263          	beq	s1,s2,80001f8e <wakeup+0x58>
    if(p != myproc()){
    80001f6e:	961ff0ef          	jal	800018ce <myproc>
    80001f72:	fea48ae3          	beq	s1,a0,80001f66 <wakeup+0x30>
      acquire(&p->lock);
    80001f76:	8526                	mv	a0,s1
    80001f78:	c57fe0ef          	jal	80000bce <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001f7c:	4c9c                	lw	a5,24(s1)
    80001f7e:	ff3791e3          	bne	a5,s3,80001f60 <wakeup+0x2a>
    80001f82:	709c                	ld	a5,32(s1)
    80001f84:	fd479ee3          	bne	a5,s4,80001f60 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001f88:	0154ac23          	sw	s5,24(s1)
    80001f8c:	bfd1                	j	80001f60 <wakeup+0x2a>
    }
  }
}
    80001f8e:	70e2                	ld	ra,56(sp)
    80001f90:	7442                	ld	s0,48(sp)
    80001f92:	74a2                	ld	s1,40(sp)
    80001f94:	7902                	ld	s2,32(sp)
    80001f96:	69e2                	ld	s3,24(sp)
    80001f98:	6a42                	ld	s4,16(sp)
    80001f9a:	6aa2                	ld	s5,8(sp)
    80001f9c:	6121                	addi	sp,sp,64
    80001f9e:	8082                	ret

0000000080001fa0 <reparent>:
{
    80001fa0:	7179                	addi	sp,sp,-48
    80001fa2:	f406                	sd	ra,40(sp)
    80001fa4:	f022                	sd	s0,32(sp)
    80001fa6:	ec26                	sd	s1,24(sp)
    80001fa8:	e84a                	sd	s2,16(sp)
    80001faa:	e44e                	sd	s3,8(sp)
    80001fac:	e052                	sd	s4,0(sp)
    80001fae:	1800                	addi	s0,sp,48
    80001fb0:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001fb2:	00011497          	auipc	s1,0x11
    80001fb6:	81648493          	addi	s1,s1,-2026 # 800127c8 <proc>
      pp->parent = initproc;
    80001fba:	00008a17          	auipc	s4,0x8
    80001fbe:	2d6a0a13          	addi	s4,s4,726 # 8000a290 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001fc2:	00016997          	auipc	s3,0x16
    80001fc6:	60698993          	addi	s3,s3,1542 # 800185c8 <tickslock>
    80001fca:	a029                	j	80001fd4 <reparent+0x34>
    80001fcc:	17848493          	addi	s1,s1,376
    80001fd0:	01348b63          	beq	s1,s3,80001fe6 <reparent+0x46>
    if(pp->parent == p){
    80001fd4:	7c9c                	ld	a5,56(s1)
    80001fd6:	ff279be3          	bne	a5,s2,80001fcc <reparent+0x2c>
      pp->parent = initproc;
    80001fda:	000a3503          	ld	a0,0(s4)
    80001fde:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001fe0:	f57ff0ef          	jal	80001f36 <wakeup>
    80001fe4:	b7e5                	j	80001fcc <reparent+0x2c>
}
    80001fe6:	70a2                	ld	ra,40(sp)
    80001fe8:	7402                	ld	s0,32(sp)
    80001fea:	64e2                	ld	s1,24(sp)
    80001fec:	6942                	ld	s2,16(sp)
    80001fee:	69a2                	ld	s3,8(sp)
    80001ff0:	6a02                	ld	s4,0(sp)
    80001ff2:	6145                	addi	sp,sp,48
    80001ff4:	8082                	ret

0000000080001ff6 <kexit>:
{
    80001ff6:	7179                	addi	sp,sp,-48
    80001ff8:	f406                	sd	ra,40(sp)
    80001ffa:	f022                	sd	s0,32(sp)
    80001ffc:	ec26                	sd	s1,24(sp)
    80001ffe:	e84a                	sd	s2,16(sp)
    80002000:	e44e                	sd	s3,8(sp)
    80002002:	e052                	sd	s4,0(sp)
    80002004:	1800                	addi	s0,sp,48
    80002006:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002008:	8c7ff0ef          	jal	800018ce <myproc>
    8000200c:	89aa                	mv	s3,a0
  if(p == initproc)
    8000200e:	00008797          	auipc	a5,0x8
    80002012:	2827b783          	ld	a5,642(a5) # 8000a290 <initproc>
    80002016:	0d050493          	addi	s1,a0,208
    8000201a:	15050913          	addi	s2,a0,336
    8000201e:	00a79f63          	bne	a5,a0,8000203c <kexit+0x46>
    panic("init exiting");
    80002022:	00005517          	auipc	a0,0x5
    80002026:	1be50513          	addi	a0,a0,446 # 800071e0 <etext+0x1e0>
    8000202a:	fb6fe0ef          	jal	800007e0 <panic>
      fileclose(f);
    8000202e:	18c020ef          	jal	800041ba <fileclose>
      p->ofile[fd] = 0;
    80002032:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    80002036:	04a1                	addi	s1,s1,8
    80002038:	01248563          	beq	s1,s2,80002042 <kexit+0x4c>
    if(p->ofile[fd]){
    8000203c:	6088                	ld	a0,0(s1)
    8000203e:	f965                	bnez	a0,8000202e <kexit+0x38>
    80002040:	bfdd                	j	80002036 <kexit+0x40>
  begin_op();
    80002042:	56d010ef          	jal	80003dae <begin_op>
  iput(p->cwd);
    80002046:	1509b503          	ld	a0,336(s3)
    8000204a:	4fc010ef          	jal	80003546 <iput>
  end_op();
    8000204e:	5cb010ef          	jal	80003e18 <end_op>
  p->cwd = 0;
    80002052:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    80002056:	00010497          	auipc	s1,0x10
    8000205a:	35a48493          	addi	s1,s1,858 # 800123b0 <wait_lock>
    8000205e:	8526                	mv	a0,s1
    80002060:	b6ffe0ef          	jal	80000bce <acquire>
  reparent(p);
    80002064:	854e                	mv	a0,s3
    80002066:	f3bff0ef          	jal	80001fa0 <reparent>
  wakeup(p->parent);
    8000206a:	0389b503          	ld	a0,56(s3)
    8000206e:	ec9ff0ef          	jal	80001f36 <wakeup>
  acquire(&p->lock);
    80002072:	854e                	mv	a0,s3
    80002074:	b5bfe0ef          	jal	80000bce <acquire>
  p->xstate = status;
    80002078:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    8000207c:	4795                	li	a5,5
    8000207e:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002082:	8526                	mv	a0,s1
    80002084:	be3fe0ef          	jal	80000c66 <release>
  sched();
    80002088:	d7dff0ef          	jal	80001e04 <sched>
  panic("zombie exit");
    8000208c:	00005517          	auipc	a0,0x5
    80002090:	16450513          	addi	a0,a0,356 # 800071f0 <etext+0x1f0>
    80002094:	f4cfe0ef          	jal	800007e0 <panic>

0000000080002098 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    80002098:	7179                	addi	sp,sp,-48
    8000209a:	f406                	sd	ra,40(sp)
    8000209c:	f022                	sd	s0,32(sp)
    8000209e:	ec26                	sd	s1,24(sp)
    800020a0:	e84a                	sd	s2,16(sp)
    800020a2:	e44e                	sd	s3,8(sp)
    800020a4:	1800                	addi	s0,sp,48
    800020a6:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800020a8:	00010497          	auipc	s1,0x10
    800020ac:	72048493          	addi	s1,s1,1824 # 800127c8 <proc>
    800020b0:	00016997          	auipc	s3,0x16
    800020b4:	51898993          	addi	s3,s3,1304 # 800185c8 <tickslock>
    acquire(&p->lock);
    800020b8:	8526                	mv	a0,s1
    800020ba:	b15fe0ef          	jal	80000bce <acquire>
    if(p->pid == pid){
    800020be:	589c                	lw	a5,48(s1)
    800020c0:	01278b63          	beq	a5,s2,800020d6 <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800020c4:	8526                	mv	a0,s1
    800020c6:	ba1fe0ef          	jal	80000c66 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800020ca:	17848493          	addi	s1,s1,376
    800020ce:	ff3495e3          	bne	s1,s3,800020b8 <kkill+0x20>
  }
  return -1;
    800020d2:	557d                	li	a0,-1
    800020d4:	a819                	j	800020ea <kkill+0x52>
      p->killed = 1;
    800020d6:	4785                	li	a5,1
    800020d8:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    800020da:	4c98                	lw	a4,24(s1)
    800020dc:	4789                	li	a5,2
    800020de:	00f70d63          	beq	a4,a5,800020f8 <kkill+0x60>
      release(&p->lock);
    800020e2:	8526                	mv	a0,s1
    800020e4:	b83fe0ef          	jal	80000c66 <release>
      return 0;
    800020e8:	4501                	li	a0,0
}
    800020ea:	70a2                	ld	ra,40(sp)
    800020ec:	7402                	ld	s0,32(sp)
    800020ee:	64e2                	ld	s1,24(sp)
    800020f0:	6942                	ld	s2,16(sp)
    800020f2:	69a2                	ld	s3,8(sp)
    800020f4:	6145                	addi	sp,sp,48
    800020f6:	8082                	ret
        p->state = RUNNABLE;
    800020f8:	478d                	li	a5,3
    800020fa:	cc9c                	sw	a5,24(s1)
    800020fc:	b7dd                	j	800020e2 <kkill+0x4a>

00000000800020fe <setkilled>:

void
setkilled(struct proc *p)
{
    800020fe:	1101                	addi	sp,sp,-32
    80002100:	ec06                	sd	ra,24(sp)
    80002102:	e822                	sd	s0,16(sp)
    80002104:	e426                	sd	s1,8(sp)
    80002106:	1000                	addi	s0,sp,32
    80002108:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000210a:	ac5fe0ef          	jal	80000bce <acquire>
  p->killed = 1;
    8000210e:	4785                	li	a5,1
    80002110:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002112:	8526                	mv	a0,s1
    80002114:	b53fe0ef          	jal	80000c66 <release>
}
    80002118:	60e2                	ld	ra,24(sp)
    8000211a:	6442                	ld	s0,16(sp)
    8000211c:	64a2                	ld	s1,8(sp)
    8000211e:	6105                	addi	sp,sp,32
    80002120:	8082                	ret

0000000080002122 <killed>:

int
killed(struct proc *p)
{
    80002122:	1101                	addi	sp,sp,-32
    80002124:	ec06                	sd	ra,24(sp)
    80002126:	e822                	sd	s0,16(sp)
    80002128:	e426                	sd	s1,8(sp)
    8000212a:	e04a                	sd	s2,0(sp)
    8000212c:	1000                	addi	s0,sp,32
    8000212e:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002130:	a9ffe0ef          	jal	80000bce <acquire>
  k = p->killed;
    80002134:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    80002138:	8526                	mv	a0,s1
    8000213a:	b2dfe0ef          	jal	80000c66 <release>
  return k;
}
    8000213e:	854a                	mv	a0,s2
    80002140:	60e2                	ld	ra,24(sp)
    80002142:	6442                	ld	s0,16(sp)
    80002144:	64a2                	ld	s1,8(sp)
    80002146:	6902                	ld	s2,0(sp)
    80002148:	6105                	addi	sp,sp,32
    8000214a:	8082                	ret

000000008000214c <kwait>:
{
    8000214c:	715d                	addi	sp,sp,-80
    8000214e:	e486                	sd	ra,72(sp)
    80002150:	e0a2                	sd	s0,64(sp)
    80002152:	fc26                	sd	s1,56(sp)
    80002154:	f84a                	sd	s2,48(sp)
    80002156:	f44e                	sd	s3,40(sp)
    80002158:	f052                	sd	s4,32(sp)
    8000215a:	ec56                	sd	s5,24(sp)
    8000215c:	e85a                	sd	s6,16(sp)
    8000215e:	e45e                	sd	s7,8(sp)
    80002160:	e062                	sd	s8,0(sp)
    80002162:	0880                	addi	s0,sp,80
    80002164:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    80002166:	f68ff0ef          	jal	800018ce <myproc>
    8000216a:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000216c:	00010517          	auipc	a0,0x10
    80002170:	24450513          	addi	a0,a0,580 # 800123b0 <wait_lock>
    80002174:	a5bfe0ef          	jal	80000bce <acquire>
    havekids = 0;
    80002178:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    8000217a:	4a15                	li	s4,5
        havekids = 1;
    8000217c:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000217e:	00016997          	auipc	s3,0x16
    80002182:	44a98993          	addi	s3,s3,1098 # 800185c8 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002186:	00010c17          	auipc	s8,0x10
    8000218a:	22ac0c13          	addi	s8,s8,554 # 800123b0 <wait_lock>
    8000218e:	a871                	j	8000222a <kwait+0xde>
          pid = pp->pid;
    80002190:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002194:	000b0c63          	beqz	s6,800021ac <kwait+0x60>
    80002198:	4691                	li	a3,4
    8000219a:	02c48613          	addi	a2,s1,44
    8000219e:	85da                	mv	a1,s6
    800021a0:	05093503          	ld	a0,80(s2)
    800021a4:	c3eff0ef          	jal	800015e2 <copyout>
    800021a8:	02054b63          	bltz	a0,800021de <kwait+0x92>
          freeproc(pp);
    800021ac:	8526                	mv	a0,s1
    800021ae:	8f1ff0ef          	jal	80001a9e <freeproc>
          release(&pp->lock);
    800021b2:	8526                	mv	a0,s1
    800021b4:	ab3fe0ef          	jal	80000c66 <release>
          release(&wait_lock);
    800021b8:	00010517          	auipc	a0,0x10
    800021bc:	1f850513          	addi	a0,a0,504 # 800123b0 <wait_lock>
    800021c0:	aa7fe0ef          	jal	80000c66 <release>
}
    800021c4:	854e                	mv	a0,s3
    800021c6:	60a6                	ld	ra,72(sp)
    800021c8:	6406                	ld	s0,64(sp)
    800021ca:	74e2                	ld	s1,56(sp)
    800021cc:	7942                	ld	s2,48(sp)
    800021ce:	79a2                	ld	s3,40(sp)
    800021d0:	7a02                	ld	s4,32(sp)
    800021d2:	6ae2                	ld	s5,24(sp)
    800021d4:	6b42                	ld	s6,16(sp)
    800021d6:	6ba2                	ld	s7,8(sp)
    800021d8:	6c02                	ld	s8,0(sp)
    800021da:	6161                	addi	sp,sp,80
    800021dc:	8082                	ret
            release(&pp->lock);
    800021de:	8526                	mv	a0,s1
    800021e0:	a87fe0ef          	jal	80000c66 <release>
            release(&wait_lock);
    800021e4:	00010517          	auipc	a0,0x10
    800021e8:	1cc50513          	addi	a0,a0,460 # 800123b0 <wait_lock>
    800021ec:	a7bfe0ef          	jal	80000c66 <release>
            return -1;
    800021f0:	59fd                	li	s3,-1
    800021f2:	bfc9                	j	800021c4 <kwait+0x78>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800021f4:	17848493          	addi	s1,s1,376
    800021f8:	03348063          	beq	s1,s3,80002218 <kwait+0xcc>
      if(pp->parent == p){
    800021fc:	7c9c                	ld	a5,56(s1)
    800021fe:	ff279be3          	bne	a5,s2,800021f4 <kwait+0xa8>
        acquire(&pp->lock);
    80002202:	8526                	mv	a0,s1
    80002204:	9cbfe0ef          	jal	80000bce <acquire>
        if(pp->state == ZOMBIE){
    80002208:	4c9c                	lw	a5,24(s1)
    8000220a:	f94783e3          	beq	a5,s4,80002190 <kwait+0x44>
        release(&pp->lock);
    8000220e:	8526                	mv	a0,s1
    80002210:	a57fe0ef          	jal	80000c66 <release>
        havekids = 1;
    80002214:	8756                	mv	a4,s5
    80002216:	bff9                	j	800021f4 <kwait+0xa8>
    if(!havekids || killed(p)){
    80002218:	cf19                	beqz	a4,80002236 <kwait+0xea>
    8000221a:	854a                	mv	a0,s2
    8000221c:	f07ff0ef          	jal	80002122 <killed>
    80002220:	e919                	bnez	a0,80002236 <kwait+0xea>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002222:	85e2                	mv	a1,s8
    80002224:	854a                	mv	a0,s2
    80002226:	cc5ff0ef          	jal	80001eea <sleep>
    havekids = 0;
    8000222a:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000222c:	00010497          	auipc	s1,0x10
    80002230:	59c48493          	addi	s1,s1,1436 # 800127c8 <proc>
    80002234:	b7e1                	j	800021fc <kwait+0xb0>
      release(&wait_lock);
    80002236:	00010517          	auipc	a0,0x10
    8000223a:	17a50513          	addi	a0,a0,378 # 800123b0 <wait_lock>
    8000223e:	a29fe0ef          	jal	80000c66 <release>
      return -1;
    80002242:	59fd                	li	s3,-1
    80002244:	b741                	j	800021c4 <kwait+0x78>

0000000080002246 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002246:	7179                	addi	sp,sp,-48
    80002248:	f406                	sd	ra,40(sp)
    8000224a:	f022                	sd	s0,32(sp)
    8000224c:	ec26                	sd	s1,24(sp)
    8000224e:	e84a                	sd	s2,16(sp)
    80002250:	e44e                	sd	s3,8(sp)
    80002252:	e052                	sd	s4,0(sp)
    80002254:	1800                	addi	s0,sp,48
    80002256:	84aa                	mv	s1,a0
    80002258:	892e                	mv	s2,a1
    8000225a:	89b2                	mv	s3,a2
    8000225c:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000225e:	e70ff0ef          	jal	800018ce <myproc>
  if(user_dst){
    80002262:	cc99                	beqz	s1,80002280 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80002264:	86d2                	mv	a3,s4
    80002266:	864e                	mv	a2,s3
    80002268:	85ca                	mv	a1,s2
    8000226a:	6928                	ld	a0,80(a0)
    8000226c:	b76ff0ef          	jal	800015e2 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002270:	70a2                	ld	ra,40(sp)
    80002272:	7402                	ld	s0,32(sp)
    80002274:	64e2                	ld	s1,24(sp)
    80002276:	6942                	ld	s2,16(sp)
    80002278:	69a2                	ld	s3,8(sp)
    8000227a:	6a02                	ld	s4,0(sp)
    8000227c:	6145                	addi	sp,sp,48
    8000227e:	8082                	ret
    memmove((char *)dst, src, len);
    80002280:	000a061b          	sext.w	a2,s4
    80002284:	85ce                	mv	a1,s3
    80002286:	854a                	mv	a0,s2
    80002288:	a77fe0ef          	jal	80000cfe <memmove>
    return 0;
    8000228c:	8526                	mv	a0,s1
    8000228e:	b7cd                	j	80002270 <either_copyout+0x2a>

0000000080002290 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002290:	7179                	addi	sp,sp,-48
    80002292:	f406                	sd	ra,40(sp)
    80002294:	f022                	sd	s0,32(sp)
    80002296:	ec26                	sd	s1,24(sp)
    80002298:	e84a                	sd	s2,16(sp)
    8000229a:	e44e                	sd	s3,8(sp)
    8000229c:	e052                	sd	s4,0(sp)
    8000229e:	1800                	addi	s0,sp,48
    800022a0:	892a                	mv	s2,a0
    800022a2:	84ae                	mv	s1,a1
    800022a4:	89b2                	mv	s3,a2
    800022a6:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800022a8:	e26ff0ef          	jal	800018ce <myproc>
  if(user_src){
    800022ac:	cc99                	beqz	s1,800022ca <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800022ae:	86d2                	mv	a3,s4
    800022b0:	864e                	mv	a2,s3
    800022b2:	85ca                	mv	a1,s2
    800022b4:	6928                	ld	a0,80(a0)
    800022b6:	c10ff0ef          	jal	800016c6 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800022ba:	70a2                	ld	ra,40(sp)
    800022bc:	7402                	ld	s0,32(sp)
    800022be:	64e2                	ld	s1,24(sp)
    800022c0:	6942                	ld	s2,16(sp)
    800022c2:	69a2                	ld	s3,8(sp)
    800022c4:	6a02                	ld	s4,0(sp)
    800022c6:	6145                	addi	sp,sp,48
    800022c8:	8082                	ret
    memmove(dst, (char*)src, len);
    800022ca:	000a061b          	sext.w	a2,s4
    800022ce:	85ce                	mv	a1,s3
    800022d0:	854a                	mv	a0,s2
    800022d2:	a2dfe0ef          	jal	80000cfe <memmove>
    return 0;
    800022d6:	8526                	mv	a0,s1
    800022d8:	b7cd                	j	800022ba <either_copyin+0x2a>

00000000800022da <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800022da:	715d                	addi	sp,sp,-80
    800022dc:	e486                	sd	ra,72(sp)
    800022de:	e0a2                	sd	s0,64(sp)
    800022e0:	fc26                	sd	s1,56(sp)
    800022e2:	f84a                	sd	s2,48(sp)
    800022e4:	f44e                	sd	s3,40(sp)
    800022e6:	f052                	sd	s4,32(sp)
    800022e8:	ec56                	sd	s5,24(sp)
    800022ea:	e85a                	sd	s6,16(sp)
    800022ec:	e45e                	sd	s7,8(sp)
    800022ee:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800022f0:	00005517          	auipc	a0,0x5
    800022f4:	d8850513          	addi	a0,a0,-632 # 80007078 <etext+0x78>
    800022f8:	a02fe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800022fc:	00010497          	auipc	s1,0x10
    80002300:	62448493          	addi	s1,s1,1572 # 80012920 <proc+0x158>
    80002304:	00016917          	auipc	s2,0x16
    80002308:	41c90913          	addi	s2,s2,1052 # 80018720 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000230c:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    8000230e:	00005997          	auipc	s3,0x5
    80002312:	ef298993          	addi	s3,s3,-270 # 80007200 <etext+0x200>
    printf("%d %s %s", p->pid, state, p->name);
    80002316:	00005a97          	auipc	s5,0x5
    8000231a:	ef2a8a93          	addi	s5,s5,-270 # 80007208 <etext+0x208>
    printf("\n");
    8000231e:	00005a17          	auipc	s4,0x5
    80002322:	d5aa0a13          	addi	s4,s4,-678 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002326:	00005b97          	auipc	s7,0x5
    8000232a:	422b8b93          	addi	s7,s7,1058 # 80007748 <states.0>
    8000232e:	a829                	j	80002348 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80002330:	ed86a583          	lw	a1,-296(a3)
    80002334:	8556                	mv	a0,s5
    80002336:	9c4fe0ef          	jal	800004fa <printf>
    printf("\n");
    8000233a:	8552                	mv	a0,s4
    8000233c:	9befe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002340:	17848493          	addi	s1,s1,376
    80002344:	03248263          	beq	s1,s2,80002368 <procdump+0x8e>
    if(p->state == UNUSED)
    80002348:	86a6                	mv	a3,s1
    8000234a:	ec04a783          	lw	a5,-320(s1)
    8000234e:	dbed                	beqz	a5,80002340 <procdump+0x66>
      state = "???";
    80002350:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002352:	fcfb6fe3          	bltu	s6,a5,80002330 <procdump+0x56>
    80002356:	02079713          	slli	a4,a5,0x20
    8000235a:	01d75793          	srli	a5,a4,0x1d
    8000235e:	97de                	add	a5,a5,s7
    80002360:	6390                	ld	a2,0(a5)
    80002362:	f679                	bnez	a2,80002330 <procdump+0x56>
      state = "???";
    80002364:	864e                	mv	a2,s3
    80002366:	b7e9                	j	80002330 <procdump+0x56>
  }
}
    80002368:	60a6                	ld	ra,72(sp)
    8000236a:	6406                	ld	s0,64(sp)
    8000236c:	74e2                	ld	s1,56(sp)
    8000236e:	7942                	ld	s2,48(sp)
    80002370:	79a2                	ld	s3,40(sp)
    80002372:	7a02                	ld	s4,32(sp)
    80002374:	6ae2                	ld	s5,24(sp)
    80002376:	6b42                	ld	s6,16(sp)
    80002378:	6ba2                	ld	s7,8(sp)
    8000237a:	6161                	addi	sp,sp,80
    8000237c:	8082                	ret

000000008000237e <age_processes>:


// Age processes waiting in queues - increase priority over time
void
age_processes(void)
{
    8000237e:	7139                	addi	sp,sp,-64
    80002380:	fc06                	sd	ra,56(sp)
    80002382:	f822                	sd	s0,48(sp)
    80002384:	f426                	sd	s1,40(sp)
    80002386:	f04a                	sd	s2,32(sp)
    80002388:	ec4e                	sd	s3,24(sp)
    8000238a:	e852                	sd	s4,16(sp)
    8000238c:	e456                	sd	s5,8(sp)
    8000238e:	0080                	addi	s0,sp,64
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80002390:	00010497          	auipc	s1,0x10
    80002394:	43848493          	addi	s1,s1,1080 # 800127c8 <proc>
    acquire(&p->lock);
    if(p->state == RUNNABLE) {
    80002398:	498d                	li	s3,3
      p->age++;
      if(p->age > 50) {       // Every 50 ticks waiting
    8000239a:	03200a13          	li	s4,50
        p->priority++;         // Increase priority
        p->age = 0;
        printf("[AGE] PID %d now priority %d\n", p->pid, p->priority);
    8000239e:	00005a97          	auipc	s5,0x5
    800023a2:	e7aa8a93          	addi	s5,s5,-390 # 80007218 <etext+0x218>
  for(p = proc; p < &proc[NPROC]; p++) {
    800023a6:	00016917          	auipc	s2,0x16
    800023aa:	22290913          	addi	s2,s2,546 # 800185c8 <tickslock>
    800023ae:	a00d                	j	800023d0 <age_processes+0x52>
      p->age++;
    800023b0:	1704a783          	lw	a5,368(s1)
    800023b4:	2785                	addiw	a5,a5,1
    800023b6:	0007871b          	sext.w	a4,a5
    800023ba:	16f4a823          	sw	a5,368(s1)
      if(p->age > 50) {       // Every 50 ticks waiting
    800023be:	02ea4263          	blt	s4,a4,800023e2 <age_processes+0x64>
      }
    } else {
      p->age = 0;              // Reset when not waiting
    }
    release(&p->lock);
    800023c2:	8526                	mv	a0,s1
    800023c4:	8a3fe0ef          	jal	80000c66 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800023c8:	17848493          	addi	s1,s1,376
    800023cc:	03248863          	beq	s1,s2,800023fc <age_processes+0x7e>
    acquire(&p->lock);
    800023d0:	8526                	mv	a0,s1
    800023d2:	ffcfe0ef          	jal	80000bce <acquire>
    if(p->state == RUNNABLE) {
    800023d6:	4c9c                	lw	a5,24(s1)
    800023d8:	fd378ce3          	beq	a5,s3,800023b0 <age_processes+0x32>
      p->age = 0;              // Reset when not waiting
    800023dc:	1604a823          	sw	zero,368(s1)
    800023e0:	b7cd                	j	800023c2 <age_processes+0x44>
        p->priority++;         // Increase priority
    800023e2:	16c4a603          	lw	a2,364(s1)
    800023e6:	2605                	addiw	a2,a2,1 # 1001 <_entry-0x7fffefff>
    800023e8:	16c4a623          	sw	a2,364(s1)
        p->age = 0;
    800023ec:	1604a823          	sw	zero,368(s1)
        printf("[AGE] PID %d now priority %d\n", p->pid, p->priority);
    800023f0:	2601                	sext.w	a2,a2
    800023f2:	588c                	lw	a1,48(s1)
    800023f4:	8556                	mv	a0,s5
    800023f6:	904fe0ef          	jal	800004fa <printf>
    800023fa:	b7e1                	j	800023c2 <age_processes+0x44>
  }
    800023fc:	70e2                	ld	ra,56(sp)
    800023fe:	7442                	ld	s0,48(sp)
    80002400:	74a2                	ld	s1,40(sp)
    80002402:	7902                	ld	s2,32(sp)
    80002404:	69e2                	ld	s3,24(sp)
    80002406:	6a42                	ld	s4,16(sp)
    80002408:	6aa2                	ld	s5,8(sp)
    8000240a:	6121                	addi	sp,sp,64
    8000240c:	8082                	ret

000000008000240e <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    8000240e:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    80002412:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002416:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002418:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    8000241a:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    8000241e:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    80002422:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    80002426:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    8000242a:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    8000242e:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    80002432:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002436:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    8000243a:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    8000243e:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    80002442:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002446:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    8000244a:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    8000244c:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    8000244e:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002452:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002456:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    8000245a:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    8000245e:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    80002462:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002466:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    8000246a:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    8000246e:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    80002472:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002476:	8082                	ret

0000000080002478 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002478:	1141                	addi	sp,sp,-16
    8000247a:	e406                	sd	ra,8(sp)
    8000247c:	e022                	sd	s0,0(sp)
    8000247e:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002480:	00005597          	auipc	a1,0x5
    80002484:	de858593          	addi	a1,a1,-536 # 80007268 <etext+0x268>
    80002488:	00016517          	auipc	a0,0x16
    8000248c:	14050513          	addi	a0,a0,320 # 800185c8 <tickslock>
    80002490:	ebefe0ef          	jal	80000b4e <initlock>
}
    80002494:	60a2                	ld	ra,8(sp)
    80002496:	6402                	ld	s0,0(sp)
    80002498:	0141                	addi	sp,sp,16
    8000249a:	8082                	ret

000000008000249c <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000249c:	1141                	addi	sp,sp,-16
    8000249e:	e422                	sd	s0,8(sp)
    800024a0:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    800024a2:	00003797          	auipc	a5,0x3
    800024a6:	08e78793          	addi	a5,a5,142 # 80005530 <kernelvec>
    800024aa:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800024ae:	6422                	ld	s0,8(sp)
    800024b0:	0141                	addi	sp,sp,16
    800024b2:	8082                	ret

00000000800024b4 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800024b4:	1141                	addi	sp,sp,-16
    800024b6:	e406                	sd	ra,8(sp)
    800024b8:	e022                	sd	s0,0(sp)
    800024ba:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800024bc:	c12ff0ef          	jal	800018ce <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800024c0:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800024c4:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800024c6:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800024ca:	04000737          	lui	a4,0x4000
    800024ce:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800024d0:	0732                	slli	a4,a4,0xc
    800024d2:	00004797          	auipc	a5,0x4
    800024d6:	b2e78793          	addi	a5,a5,-1234 # 80006000 <_trampoline>
    800024da:	00004697          	auipc	a3,0x4
    800024de:	b2668693          	addi	a3,a3,-1242 # 80006000 <_trampoline>
    800024e2:	8f95                	sub	a5,a5,a3
    800024e4:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    800024e6:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800024ea:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800024ec:	18002773          	csrr	a4,satp
    800024f0:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800024f2:	6d38                	ld	a4,88(a0)
    800024f4:	613c                	ld	a5,64(a0)
    800024f6:	6685                	lui	a3,0x1
    800024f8:	97b6                	add	a5,a5,a3
    800024fa:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800024fc:	6d3c                	ld	a5,88(a0)
    800024fe:	00000717          	auipc	a4,0x0
    80002502:	18a70713          	addi	a4,a4,394 # 80002688 <usertrap>
    80002506:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002508:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    8000250a:	8712                	mv	a4,tp
    8000250c:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000250e:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002512:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002516:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000251a:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    8000251e:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002520:	6f9c                	ld	a5,24(a5)
    80002522:	14179073          	csrw	sepc,a5
}
    80002526:	60a2                	ld	ra,8(sp)
    80002528:	6402                	ld	s0,0(sp)
    8000252a:	0141                	addi	sp,sp,16
    8000252c:	8082                	ret

000000008000252e <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    8000252e:	1141                	addi	sp,sp,-16
    80002530:	e406                	sd	ra,8(sp)
    80002532:	e022                	sd	s0,0(sp)
    80002534:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002536:	b98ff0ef          	jal	800018ce <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000253a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000253e:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002540:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002544:	00004697          	auipc	a3,0x4
    80002548:	abc68693          	addi	a3,a3,-1348 # 80006000 <_trampoline>
    8000254c:	00004717          	auipc	a4,0x4
    80002550:	ab470713          	addi	a4,a4,-1356 # 80006000 <_trampoline>
    80002554:	8f15                	sub	a4,a4,a3
    80002556:	040007b7          	lui	a5,0x4000
    8000255a:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    8000255c:	07b2                	slli	a5,a5,0xc
    8000255e:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002560:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002564:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002566:	18002673          	csrr	a2,satp
    8000256a:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000256c:	6d30                	ld	a2,88(a0)
    8000256e:	6138                	ld	a4,64(a0)
    80002570:	6585                	lui	a1,0x1
    80002572:	972e                	add	a4,a4,a1
    80002574:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002576:	6d38                	ld	a4,88(a0)
    80002578:	00000617          	auipc	a2,0x0
    8000257c:	11060613          	addi	a2,a2,272 # 80002688 <usertrap>
    80002580:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002582:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002584:	8612                	mv	a2,tp
    80002586:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002588:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000258c:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002590:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002594:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002598:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000259a:	6f18                	ld	a4,24(a4)
    8000259c:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    800025a0:	6928                	ld	a0,80(a0)
    800025a2:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800025a4:	00004717          	auipc	a4,0x4
    800025a8:	af870713          	addi	a4,a4,-1288 # 8000609c <userret>
    800025ac:	8f15                	sub	a4,a4,a3
    800025ae:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800025b0:	577d                	li	a4,-1
    800025b2:	177e                	slli	a4,a4,0x3f
    800025b4:	8d59                	or	a0,a0,a4
    800025b6:	9782                	jalr	a5
}
    800025b8:	60a2                	ld	ra,8(sp)
    800025ba:	6402                	ld	s0,0(sp)
    800025bc:	0141                	addi	sp,sp,16
    800025be:	8082                	ret

00000000800025c0 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800025c0:	1101                	addi	sp,sp,-32
    800025c2:	ec06                	sd	ra,24(sp)
    800025c4:	e822                	sd	s0,16(sp)
    800025c6:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    800025c8:	adaff0ef          	jal	800018a2 <cpuid>
    800025cc:	cd11                	beqz	a0,800025e8 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    800025ce:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800025d2:	000f4737          	lui	a4,0xf4
    800025d6:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800025da:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800025dc:	14d79073          	csrw	stimecmp,a5
}
    800025e0:	60e2                	ld	ra,24(sp)
    800025e2:	6442                	ld	s0,16(sp)
    800025e4:	6105                	addi	sp,sp,32
    800025e6:	8082                	ret
    800025e8:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    800025ea:	00016497          	auipc	s1,0x16
    800025ee:	fde48493          	addi	s1,s1,-34 # 800185c8 <tickslock>
    800025f2:	8526                	mv	a0,s1
    800025f4:	ddafe0ef          	jal	80000bce <acquire>
    ticks++;
    800025f8:	00008517          	auipc	a0,0x8
    800025fc:	ca050513          	addi	a0,a0,-864 # 8000a298 <ticks>
    80002600:	411c                	lw	a5,0(a0)
    80002602:	2785                	addiw	a5,a5,1
    80002604:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    80002606:	931ff0ef          	jal	80001f36 <wakeup>
    release(&tickslock);
    8000260a:	8526                	mv	a0,s1
    8000260c:	e5afe0ef          	jal	80000c66 <release>
    80002610:	64a2                	ld	s1,8(sp)
    80002612:	bf75                	j	800025ce <clockintr+0xe>

0000000080002614 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002614:	1101                	addi	sp,sp,-32
    80002616:	ec06                	sd	ra,24(sp)
    80002618:	e822                	sd	s0,16(sp)
    8000261a:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000261c:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80002620:	57fd                	li	a5,-1
    80002622:	17fe                	slli	a5,a5,0x3f
    80002624:	07a5                	addi	a5,a5,9
    80002626:	00f70c63          	beq	a4,a5,8000263e <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    8000262a:	57fd                	li	a5,-1
    8000262c:	17fe                	slli	a5,a5,0x3f
    8000262e:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002630:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80002632:	04f70763          	beq	a4,a5,80002680 <devintr+0x6c>
  }
}
    80002636:	60e2                	ld	ra,24(sp)
    80002638:	6442                	ld	s0,16(sp)
    8000263a:	6105                	addi	sp,sp,32
    8000263c:	8082                	ret
    8000263e:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002640:	79d020ef          	jal	800055dc <plic_claim>
    80002644:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002646:	47a9                	li	a5,10
    80002648:	00f50963          	beq	a0,a5,8000265a <devintr+0x46>
    } else if(irq == VIRTIO0_IRQ){
    8000264c:	4785                	li	a5,1
    8000264e:	00f50963          	beq	a0,a5,80002660 <devintr+0x4c>
    return 1;
    80002652:	4505                	li	a0,1
    } else if(irq){
    80002654:	e889                	bnez	s1,80002666 <devintr+0x52>
    80002656:	64a2                	ld	s1,8(sp)
    80002658:	bff9                	j	80002636 <devintr+0x22>
      uartintr();
    8000265a:	b56fe0ef          	jal	800009b0 <uartintr>
    if(irq)
    8000265e:	a819                	j	80002674 <devintr+0x60>
      virtio_disk_intr();
    80002660:	442030ef          	jal	80005aa2 <virtio_disk_intr>
    if(irq)
    80002664:	a801                	j	80002674 <devintr+0x60>
      printf("unexpected interrupt irq=%d\n", irq);
    80002666:	85a6                	mv	a1,s1
    80002668:	00005517          	auipc	a0,0x5
    8000266c:	c0850513          	addi	a0,a0,-1016 # 80007270 <etext+0x270>
    80002670:	e8bfd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    80002674:	8526                	mv	a0,s1
    80002676:	787020ef          	jal	800055fc <plic_complete>
    return 1;
    8000267a:	4505                	li	a0,1
    8000267c:	64a2                	ld	s1,8(sp)
    8000267e:	bf65                	j	80002636 <devintr+0x22>
    clockintr();
    80002680:	f41ff0ef          	jal	800025c0 <clockintr>
    return 2;
    80002684:	4509                	li	a0,2
    80002686:	bf45                	j	80002636 <devintr+0x22>

0000000080002688 <usertrap>:
{
    80002688:	1101                	addi	sp,sp,-32
    8000268a:	ec06                	sd	ra,24(sp)
    8000268c:	e822                	sd	s0,16(sp)
    8000268e:	e426                	sd	s1,8(sp)
    80002690:	e04a                	sd	s2,0(sp)
    80002692:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002694:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80002698:	1007f793          	andi	a5,a5,256
    8000269c:	eba5                	bnez	a5,8000270c <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000269e:	00003797          	auipc	a5,0x3
    800026a2:	e9278793          	addi	a5,a5,-366 # 80005530 <kernelvec>
    800026a6:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800026aa:	a24ff0ef          	jal	800018ce <myproc>
    800026ae:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800026b0:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800026b2:	14102773          	csrr	a4,sepc
    800026b6:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800026b8:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800026bc:	47a1                	li	a5,8
    800026be:	04f70d63          	beq	a4,a5,80002718 <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    800026c2:	f53ff0ef          	jal	80002614 <devintr>
    800026c6:	892a                	mv	s2,a0
    800026c8:	e15d                	bnez	a0,8000276e <usertrap+0xe6>
    800026ca:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    800026ce:	47bd                	li	a5,15
    800026d0:	08f70363          	beq	a4,a5,80002756 <usertrap+0xce>
    800026d4:	14202773          	csrr	a4,scause
    800026d8:	47b5                	li	a5,13
    800026da:	06f70e63          	beq	a4,a5,80002756 <usertrap+0xce>
    800026de:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800026e2:	5890                	lw	a2,48(s1)
    800026e4:	00005517          	auipc	a0,0x5
    800026e8:	bcc50513          	addi	a0,a0,-1076 # 800072b0 <etext+0x2b0>
    800026ec:	e0ffd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800026f0:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800026f4:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800026f8:	00005517          	auipc	a0,0x5
    800026fc:	be850513          	addi	a0,a0,-1048 # 800072e0 <etext+0x2e0>
    80002700:	dfbfd0ef          	jal	800004fa <printf>
    setkilled(p);
    80002704:	8526                	mv	a0,s1
    80002706:	9f9ff0ef          	jal	800020fe <setkilled>
    8000270a:	a035                	j	80002736 <usertrap+0xae>
    panic("usertrap: not from user mode");
    8000270c:	00005517          	auipc	a0,0x5
    80002710:	b8450513          	addi	a0,a0,-1148 # 80007290 <etext+0x290>
    80002714:	8ccfe0ef          	jal	800007e0 <panic>
    if(killed(p))
    80002718:	a0bff0ef          	jal	80002122 <killed>
    8000271c:	e90d                	bnez	a0,8000274e <usertrap+0xc6>
    p->trapframe->epc += 4;
    8000271e:	6cb8                	ld	a4,88(s1)
    80002720:	6f1c                	ld	a5,24(a4)
    80002722:	0791                	addi	a5,a5,4
    80002724:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002726:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000272a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000272e:	10079073          	csrw	sstatus,a5
    syscall();
    80002732:	2a8000ef          	jal	800029da <syscall>
  if(killed(p))
    80002736:	8526                	mv	a0,s1
    80002738:	9ebff0ef          	jal	80002122 <killed>
    8000273c:	ed15                	bnez	a0,80002778 <usertrap+0xf0>
  usertrapret();
    8000273e:	df1ff0ef          	jal	8000252e <usertrapret>
}
    80002742:	60e2                	ld	ra,24(sp)
    80002744:	6442                	ld	s0,16(sp)
    80002746:	64a2                	ld	s1,8(sp)
    80002748:	6902                	ld	s2,0(sp)
    8000274a:	6105                	addi	sp,sp,32
    8000274c:	8082                	ret
      kexit(-1);
    8000274e:	557d                	li	a0,-1
    80002750:	8a7ff0ef          	jal	80001ff6 <kexit>
    80002754:	b7e9                	j	8000271e <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002756:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000275a:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    8000275e:	164d                	addi	a2,a2,-13
    80002760:	00163613          	seqz	a2,a2
    80002764:	68a8                	ld	a0,80(s1)
    80002766:	dfbfe0ef          	jal	80001560 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    8000276a:	f571                	bnez	a0,80002736 <usertrap+0xae>
    8000276c:	bf8d                	j	800026de <usertrap+0x56>
  if(killed(p))
    8000276e:	8526                	mv	a0,s1
    80002770:	9b3ff0ef          	jal	80002122 <killed>
    80002774:	c511                	beqz	a0,80002780 <usertrap+0xf8>
    80002776:	a011                	j	8000277a <usertrap+0xf2>
    80002778:	4901                	li	s2,0
    kexit(-1);
    8000277a:	557d                	li	a0,-1
    8000277c:	87bff0ef          	jal	80001ff6 <kexit>
  if(which_dev == 2){  // 2 means timer interrupt
    80002780:	4789                	li	a5,2
    80002782:	faf91ee3          	bne	s2,a5,8000273e <usertrap+0xb6>
    age_processes(); 
    80002786:	bf9ff0ef          	jal	8000237e <age_processes>
    struct proc *p = myproc();
    8000278a:	944ff0ef          	jal	800018ce <myproc>
    8000278e:	84aa                	mv	s1,a0
    acquire(&p->lock);
    80002790:	c3efe0ef          	jal	80000bce <acquire>
    p->ticks_used++;
    80002794:	1684a783          	lw	a5,360(s1)
    80002798:	2785                	addiw	a5,a5,1
    8000279a:	0007871b          	sext.w	a4,a5
    8000279e:	16f4a423          	sw	a5,360(s1)
	  if(p->ticks_used >= time_quantum) {
    800027a2:	00008797          	auipc	a5,0x8
    800027a6:	aa67a783          	lw	a5,-1370(a5) # 8000a248 <time_quantum>
    800027aa:	00f74863          	blt	a4,a5,800027ba <usertrap+0x132>
	      release(&p->lock);
    800027ae:	8526                	mv	a0,s1
    800027b0:	cb6fe0ef          	jal	80000c66 <release>
	      yield();
    800027b4:	f0aff0ef          	jal	80001ebe <yield>
    800027b8:	b759                	j	8000273e <usertrap+0xb6>
	      release(&p->lock);
    800027ba:	8526                	mv	a0,s1
    800027bc:	caafe0ef          	jal	80000c66 <release>
    800027c0:	bfbd                	j	8000273e <usertrap+0xb6>

00000000800027c2 <kerneltrap>:
{
    800027c2:	7179                	addi	sp,sp,-48
    800027c4:	f406                	sd	ra,40(sp)
    800027c6:	f022                	sd	s0,32(sp)
    800027c8:	ec26                	sd	s1,24(sp)
    800027ca:	e84a                	sd	s2,16(sp)
    800027cc:	e44e                	sd	s3,8(sp)
    800027ce:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800027d0:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800027d4:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    800027d8:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    800027dc:	1004f793          	andi	a5,s1,256
    800027e0:	c795                	beqz	a5,8000280c <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800027e2:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800027e6:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800027e8:	eb85                	bnez	a5,80002818 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    800027ea:	e2bff0ef          	jal	80002614 <devintr>
    800027ee:	c91d                	beqz	a0,80002824 <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0) {  // 2 = timer, and we have a process
    800027f0:	4789                	li	a5,2
    800027f2:	04f50a63          	beq	a0,a5,80002846 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    800027f6:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800027fa:	10049073          	csrw	sstatus,s1
}
    800027fe:	70a2                	ld	ra,40(sp)
    80002800:	7402                	ld	s0,32(sp)
    80002802:	64e2                	ld	s1,24(sp)
    80002804:	6942                	ld	s2,16(sp)
    80002806:	69a2                	ld	s3,8(sp)
    80002808:	6145                	addi	sp,sp,48
    8000280a:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    8000280c:	00005517          	auipc	a0,0x5
    80002810:	afc50513          	addi	a0,a0,-1284 # 80007308 <etext+0x308>
    80002814:	fcdfd0ef          	jal	800007e0 <panic>
    panic("kerneltrap: interrupts enabled");
    80002818:	00005517          	auipc	a0,0x5
    8000281c:	b1850513          	addi	a0,a0,-1256 # 80007330 <etext+0x330>
    80002820:	fc1fd0ef          	jal	800007e0 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002824:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002828:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    8000282c:	85ce                	mv	a1,s3
    8000282e:	00005517          	auipc	a0,0x5
    80002832:	b2250513          	addi	a0,a0,-1246 # 80007350 <etext+0x350>
    80002836:	cc5fd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    8000283a:	00005517          	auipc	a0,0x5
    8000283e:	b3e50513          	addi	a0,a0,-1218 # 80007378 <etext+0x378>
    80002842:	f9ffd0ef          	jal	800007e0 <panic>
  if(which_dev == 2 && myproc() != 0) {  // 2 = timer, and we have a process
    80002846:	888ff0ef          	jal	800018ce <myproc>
    8000284a:	d555                	beqz	a0,800027f6 <kerneltrap+0x34>
    age_processes();  
    8000284c:	b33ff0ef          	jal	8000237e <age_processes>
    struct proc *p = myproc();
    80002850:	87eff0ef          	jal	800018ce <myproc>
    80002854:	89aa                	mv	s3,a0
    acquire(&p->lock);
    80002856:	b78fe0ef          	jal	80000bce <acquire>
    p->ticks_used++;
    8000285a:	1689a783          	lw	a5,360(s3)
    8000285e:	2785                	addiw	a5,a5,1
    80002860:	0007871b          	sext.w	a4,a5
    80002864:	16f9a423          	sw	a5,360(s3)
    if(p->ticks_used >= time_quantum) {
    80002868:	00008797          	auipc	a5,0x8
    8000286c:	9e07a783          	lw	a5,-1568(a5) # 8000a248 <time_quantum>
    80002870:	00f74863          	blt	a4,a5,80002880 <kerneltrap+0xbe>
      release(&p->lock);
    80002874:	854e                	mv	a0,s3
    80002876:	bf0fe0ef          	jal	80000c66 <release>
      yield();
    8000287a:	e44ff0ef          	jal	80001ebe <yield>
    8000287e:	bfa5                	j	800027f6 <kerneltrap+0x34>
      release(&p->lock);
    80002880:	854e                	mv	a0,s3
    80002882:	be4fe0ef          	jal	80000c66 <release>
    80002886:	bf85                	j	800027f6 <kerneltrap+0x34>

0000000080002888 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002888:	1101                	addi	sp,sp,-32
    8000288a:	ec06                	sd	ra,24(sp)
    8000288c:	e822                	sd	s0,16(sp)
    8000288e:	e426                	sd	s1,8(sp)
    80002890:	1000                	addi	s0,sp,32
    80002892:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002894:	83aff0ef          	jal	800018ce <myproc>
  switch (n) {
    80002898:	4795                	li	a5,5
    8000289a:	0497e163          	bltu	a5,s1,800028dc <argraw+0x54>
    8000289e:	048a                	slli	s1,s1,0x2
    800028a0:	00005717          	auipc	a4,0x5
    800028a4:	ed870713          	addi	a4,a4,-296 # 80007778 <states.0+0x30>
    800028a8:	94ba                	add	s1,s1,a4
    800028aa:	409c                	lw	a5,0(s1)
    800028ac:	97ba                	add	a5,a5,a4
    800028ae:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    800028b0:	6d3c                	ld	a5,88(a0)
    800028b2:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    800028b4:	60e2                	ld	ra,24(sp)
    800028b6:	6442                	ld	s0,16(sp)
    800028b8:	64a2                	ld	s1,8(sp)
    800028ba:	6105                	addi	sp,sp,32
    800028bc:	8082                	ret
    return p->trapframe->a1;
    800028be:	6d3c                	ld	a5,88(a0)
    800028c0:	7fa8                	ld	a0,120(a5)
    800028c2:	bfcd                	j	800028b4 <argraw+0x2c>
    return p->trapframe->a2;
    800028c4:	6d3c                	ld	a5,88(a0)
    800028c6:	63c8                	ld	a0,128(a5)
    800028c8:	b7f5                	j	800028b4 <argraw+0x2c>
    return p->trapframe->a3;
    800028ca:	6d3c                	ld	a5,88(a0)
    800028cc:	67c8                	ld	a0,136(a5)
    800028ce:	b7dd                	j	800028b4 <argraw+0x2c>
    return p->trapframe->a4;
    800028d0:	6d3c                	ld	a5,88(a0)
    800028d2:	6bc8                	ld	a0,144(a5)
    800028d4:	b7c5                	j	800028b4 <argraw+0x2c>
    return p->trapframe->a5;
    800028d6:	6d3c                	ld	a5,88(a0)
    800028d8:	6fc8                	ld	a0,152(a5)
    800028da:	bfe9                	j	800028b4 <argraw+0x2c>
  panic("argraw");
    800028dc:	00005517          	auipc	a0,0x5
    800028e0:	aac50513          	addi	a0,a0,-1364 # 80007388 <etext+0x388>
    800028e4:	efdfd0ef          	jal	800007e0 <panic>

00000000800028e8 <fetchaddr>:
{
    800028e8:	1101                	addi	sp,sp,-32
    800028ea:	ec06                	sd	ra,24(sp)
    800028ec:	e822                	sd	s0,16(sp)
    800028ee:	e426                	sd	s1,8(sp)
    800028f0:	e04a                	sd	s2,0(sp)
    800028f2:	1000                	addi	s0,sp,32
    800028f4:	84aa                	mv	s1,a0
    800028f6:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800028f8:	fd7fe0ef          	jal	800018ce <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    800028fc:	653c                	ld	a5,72(a0)
    800028fe:	02f4f663          	bgeu	s1,a5,8000292a <fetchaddr+0x42>
    80002902:	00848713          	addi	a4,s1,8
    80002906:	02e7e463          	bltu	a5,a4,8000292e <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    8000290a:	46a1                	li	a3,8
    8000290c:	8626                	mv	a2,s1
    8000290e:	85ca                	mv	a1,s2
    80002910:	6928                	ld	a0,80(a0)
    80002912:	db5fe0ef          	jal	800016c6 <copyin>
    80002916:	00a03533          	snez	a0,a0
    8000291a:	40a00533          	neg	a0,a0
}
    8000291e:	60e2                	ld	ra,24(sp)
    80002920:	6442                	ld	s0,16(sp)
    80002922:	64a2                	ld	s1,8(sp)
    80002924:	6902                	ld	s2,0(sp)
    80002926:	6105                	addi	sp,sp,32
    80002928:	8082                	ret
    return -1;
    8000292a:	557d                	li	a0,-1
    8000292c:	bfcd                	j	8000291e <fetchaddr+0x36>
    8000292e:	557d                	li	a0,-1
    80002930:	b7fd                	j	8000291e <fetchaddr+0x36>

0000000080002932 <fetchstr>:
{
    80002932:	7179                	addi	sp,sp,-48
    80002934:	f406                	sd	ra,40(sp)
    80002936:	f022                	sd	s0,32(sp)
    80002938:	ec26                	sd	s1,24(sp)
    8000293a:	e84a                	sd	s2,16(sp)
    8000293c:	e44e                	sd	s3,8(sp)
    8000293e:	1800                	addi	s0,sp,48
    80002940:	892a                	mv	s2,a0
    80002942:	84ae                	mv	s1,a1
    80002944:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002946:	f89fe0ef          	jal	800018ce <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    8000294a:	86ce                	mv	a3,s3
    8000294c:	864a                	mv	a2,s2
    8000294e:	85a6                	mv	a1,s1
    80002950:	6928                	ld	a0,80(a0)
    80002952:	b37fe0ef          	jal	80001488 <copyinstr>
    80002956:	00054c63          	bltz	a0,8000296e <fetchstr+0x3c>
  return strlen(buf);
    8000295a:	8526                	mv	a0,s1
    8000295c:	cb6fe0ef          	jal	80000e12 <strlen>
}
    80002960:	70a2                	ld	ra,40(sp)
    80002962:	7402                	ld	s0,32(sp)
    80002964:	64e2                	ld	s1,24(sp)
    80002966:	6942                	ld	s2,16(sp)
    80002968:	69a2                	ld	s3,8(sp)
    8000296a:	6145                	addi	sp,sp,48
    8000296c:	8082                	ret
    return -1;
    8000296e:	557d                	li	a0,-1
    80002970:	bfc5                	j	80002960 <fetchstr+0x2e>

0000000080002972 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002972:	1101                	addi	sp,sp,-32
    80002974:	ec06                	sd	ra,24(sp)
    80002976:	e822                	sd	s0,16(sp)
    80002978:	e426                	sd	s1,8(sp)
    8000297a:	1000                	addi	s0,sp,32
    8000297c:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000297e:	f0bff0ef          	jal	80002888 <argraw>
    80002982:	c088                	sw	a0,0(s1)
}
    80002984:	60e2                	ld	ra,24(sp)
    80002986:	6442                	ld	s0,16(sp)
    80002988:	64a2                	ld	s1,8(sp)
    8000298a:	6105                	addi	sp,sp,32
    8000298c:	8082                	ret

000000008000298e <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    8000298e:	1101                	addi	sp,sp,-32
    80002990:	ec06                	sd	ra,24(sp)
    80002992:	e822                	sd	s0,16(sp)
    80002994:	e426                	sd	s1,8(sp)
    80002996:	1000                	addi	s0,sp,32
    80002998:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000299a:	eefff0ef          	jal	80002888 <argraw>
    8000299e:	e088                	sd	a0,0(s1)
}
    800029a0:	60e2                	ld	ra,24(sp)
    800029a2:	6442                	ld	s0,16(sp)
    800029a4:	64a2                	ld	s1,8(sp)
    800029a6:	6105                	addi	sp,sp,32
    800029a8:	8082                	ret

00000000800029aa <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    800029aa:	7179                	addi	sp,sp,-48
    800029ac:	f406                	sd	ra,40(sp)
    800029ae:	f022                	sd	s0,32(sp)
    800029b0:	ec26                	sd	s1,24(sp)
    800029b2:	e84a                	sd	s2,16(sp)
    800029b4:	1800                	addi	s0,sp,48
    800029b6:	84ae                	mv	s1,a1
    800029b8:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    800029ba:	fd840593          	addi	a1,s0,-40
    800029be:	fd1ff0ef          	jal	8000298e <argaddr>
  return fetchstr(addr, buf, max);
    800029c2:	864a                	mv	a2,s2
    800029c4:	85a6                	mv	a1,s1
    800029c6:	fd843503          	ld	a0,-40(s0)
    800029ca:	f69ff0ef          	jal	80002932 <fetchstr>
}
    800029ce:	70a2                	ld	ra,40(sp)
    800029d0:	7402                	ld	s0,32(sp)
    800029d2:	64e2                	ld	s1,24(sp)
    800029d4:	6942                	ld	s2,16(sp)
    800029d6:	6145                	addi	sp,sp,48
    800029d8:	8082                	ret

00000000800029da <syscall>:
[SYS_ps] sys_ps,
};

void
syscall(void)
{
    800029da:	1101                	addi	sp,sp,-32
    800029dc:	ec06                	sd	ra,24(sp)
    800029de:	e822                	sd	s0,16(sp)
    800029e0:	e426                	sd	s1,8(sp)
    800029e2:	e04a                	sd	s2,0(sp)
    800029e4:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    800029e6:	ee9fe0ef          	jal	800018ce <myproc>
    800029ea:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    800029ec:	05853903          	ld	s2,88(a0)
    800029f0:	0a893783          	ld	a5,168(s2)
    800029f4:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    800029f8:	37fd                	addiw	a5,a5,-1
    800029fa:	4759                	li	a4,22
    800029fc:	00f76f63          	bltu	a4,a5,80002a1a <syscall+0x40>
    80002a00:	00369713          	slli	a4,a3,0x3
    80002a04:	00005797          	auipc	a5,0x5
    80002a08:	d8c78793          	addi	a5,a5,-628 # 80007790 <syscalls>
    80002a0c:	97ba                	add	a5,a5,a4
    80002a0e:	639c                	ld	a5,0(a5)
    80002a10:	c789                	beqz	a5,80002a1a <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002a12:	9782                	jalr	a5
    80002a14:	06a93823          	sd	a0,112(s2)
    80002a18:	a829                	j	80002a32 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002a1a:	15848613          	addi	a2,s1,344
    80002a1e:	588c                	lw	a1,48(s1)
    80002a20:	00005517          	auipc	a0,0x5
    80002a24:	97050513          	addi	a0,a0,-1680 # 80007390 <etext+0x390>
    80002a28:	ad3fd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002a2c:	6cbc                	ld	a5,88(s1)
    80002a2e:	577d                	li	a4,-1
    80002a30:	fbb8                	sd	a4,112(a5)
  }
}
    80002a32:	60e2                	ld	ra,24(sp)
    80002a34:	6442                	ld	s0,16(sp)
    80002a36:	64a2                	ld	s1,8(sp)
    80002a38:	6902                	ld	s2,0(sp)
    80002a3a:	6105                	addi	sp,sp,32
    80002a3c:	8082                	ret

0000000080002a3e <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002a3e:	1101                	addi	sp,sp,-32
    80002a40:	ec06                	sd	ra,24(sp)
    80002a42:	e822                	sd	s0,16(sp)
    80002a44:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002a46:	fec40593          	addi	a1,s0,-20
    80002a4a:	4501                	li	a0,0
    80002a4c:	f27ff0ef          	jal	80002972 <argint>
  kexit(n);
    80002a50:	fec42503          	lw	a0,-20(s0)
    80002a54:	da2ff0ef          	jal	80001ff6 <kexit>
  return 0;  // not reached
}
    80002a58:	4501                	li	a0,0
    80002a5a:	60e2                	ld	ra,24(sp)
    80002a5c:	6442                	ld	s0,16(sp)
    80002a5e:	6105                	addi	sp,sp,32
    80002a60:	8082                	ret

0000000080002a62 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002a62:	1141                	addi	sp,sp,-16
    80002a64:	e406                	sd	ra,8(sp)
    80002a66:	e022                	sd	s0,0(sp)
    80002a68:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002a6a:	e65fe0ef          	jal	800018ce <myproc>
}
    80002a6e:	5908                	lw	a0,48(a0)
    80002a70:	60a2                	ld	ra,8(sp)
    80002a72:	6402                	ld	s0,0(sp)
    80002a74:	0141                	addi	sp,sp,16
    80002a76:	8082                	ret

0000000080002a78 <sys_fork>:

uint64
sys_fork(void)
{
    80002a78:	1141                	addi	sp,sp,-16
    80002a7a:	e406                	sd	ra,8(sp)
    80002a7c:	e022                	sd	s0,0(sp)
    80002a7e:	0800                	addi	s0,sp,16
  return kfork();
    80002a80:	9c0ff0ef          	jal	80001c40 <kfork>
}
    80002a84:	60a2                	ld	ra,8(sp)
    80002a86:	6402                	ld	s0,0(sp)
    80002a88:	0141                	addi	sp,sp,16
    80002a8a:	8082                	ret

0000000080002a8c <sys_wait>:

uint64
sys_wait(void)
{
    80002a8c:	1101                	addi	sp,sp,-32
    80002a8e:	ec06                	sd	ra,24(sp)
    80002a90:	e822                	sd	s0,16(sp)
    80002a92:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002a94:	fe840593          	addi	a1,s0,-24
    80002a98:	4501                	li	a0,0
    80002a9a:	ef5ff0ef          	jal	8000298e <argaddr>
  return kwait(p);
    80002a9e:	fe843503          	ld	a0,-24(s0)
    80002aa2:	eaaff0ef          	jal	8000214c <kwait>
}
    80002aa6:	60e2                	ld	ra,24(sp)
    80002aa8:	6442                	ld	s0,16(sp)
    80002aaa:	6105                	addi	sp,sp,32
    80002aac:	8082                	ret

0000000080002aae <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002aae:	7179                	addi	sp,sp,-48
    80002ab0:	f406                	sd	ra,40(sp)
    80002ab2:	f022                	sd	s0,32(sp)
    80002ab4:	ec26                	sd	s1,24(sp)
    80002ab6:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002ab8:	fd840593          	addi	a1,s0,-40
    80002abc:	4501                	li	a0,0
    80002abe:	eb5ff0ef          	jal	80002972 <argint>
  argint(1, &t);
    80002ac2:	fdc40593          	addi	a1,s0,-36
    80002ac6:	4505                	li	a0,1
    80002ac8:	eabff0ef          	jal	80002972 <argint>
  addr = myproc()->sz;
    80002acc:	e03fe0ef          	jal	800018ce <myproc>
    80002ad0:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002ad2:	fdc42703          	lw	a4,-36(s0)
    80002ad6:	4785                	li	a5,1
    80002ad8:	02f70763          	beq	a4,a5,80002b06 <sys_sbrk+0x58>
    80002adc:	fd842783          	lw	a5,-40(s0)
    80002ae0:	0207c363          	bltz	a5,80002b06 <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002ae4:	97a6                	add	a5,a5,s1
    80002ae6:	0297ee63          	bltu	a5,s1,80002b22 <sys_sbrk+0x74>
      return -1;
    if(addr + n > TRAPFRAME)
    80002aea:	02000737          	lui	a4,0x2000
    80002aee:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    80002af0:	0736                	slli	a4,a4,0xd
    80002af2:	02f76a63          	bltu	a4,a5,80002b26 <sys_sbrk+0x78>
      return -1;
    myproc()->sz += n;
    80002af6:	dd9fe0ef          	jal	800018ce <myproc>
    80002afa:	fd842703          	lw	a4,-40(s0)
    80002afe:	653c                	ld	a5,72(a0)
    80002b00:	97ba                	add	a5,a5,a4
    80002b02:	e53c                	sd	a5,72(a0)
    80002b04:	a039                	j	80002b12 <sys_sbrk+0x64>
    if(growproc(n) < 0) {
    80002b06:	fd842503          	lw	a0,-40(s0)
    80002b0a:	8d4ff0ef          	jal	80001bde <growproc>
    80002b0e:	00054863          	bltz	a0,80002b1e <sys_sbrk+0x70>
  }
  return addr;
}
    80002b12:	8526                	mv	a0,s1
    80002b14:	70a2                	ld	ra,40(sp)
    80002b16:	7402                	ld	s0,32(sp)
    80002b18:	64e2                	ld	s1,24(sp)
    80002b1a:	6145                	addi	sp,sp,48
    80002b1c:	8082                	ret
      return -1;
    80002b1e:	54fd                	li	s1,-1
    80002b20:	bfcd                	j	80002b12 <sys_sbrk+0x64>
      return -1;
    80002b22:	54fd                	li	s1,-1
    80002b24:	b7fd                	j	80002b12 <sys_sbrk+0x64>
      return -1;
    80002b26:	54fd                	li	s1,-1
    80002b28:	b7ed                	j	80002b12 <sys_sbrk+0x64>

0000000080002b2a <sys_pause>:

uint64
sys_pause(void)
{
    80002b2a:	7139                	addi	sp,sp,-64
    80002b2c:	fc06                	sd	ra,56(sp)
    80002b2e:	f822                	sd	s0,48(sp)
    80002b30:	f04a                	sd	s2,32(sp)
    80002b32:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002b34:	fcc40593          	addi	a1,s0,-52
    80002b38:	4501                	li	a0,0
    80002b3a:	e39ff0ef          	jal	80002972 <argint>
  if(n < 0)
    80002b3e:	fcc42783          	lw	a5,-52(s0)
    80002b42:	0607c763          	bltz	a5,80002bb0 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002b46:	00016517          	auipc	a0,0x16
    80002b4a:	a8250513          	addi	a0,a0,-1406 # 800185c8 <tickslock>
    80002b4e:	880fe0ef          	jal	80000bce <acquire>
  ticks0 = ticks;
    80002b52:	00007917          	auipc	s2,0x7
    80002b56:	74692903          	lw	s2,1862(s2) # 8000a298 <ticks>
  while(ticks - ticks0 < n){
    80002b5a:	fcc42783          	lw	a5,-52(s0)
    80002b5e:	cf8d                	beqz	a5,80002b98 <sys_pause+0x6e>
    80002b60:	f426                	sd	s1,40(sp)
    80002b62:	ec4e                	sd	s3,24(sp)
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002b64:	00016997          	auipc	s3,0x16
    80002b68:	a6498993          	addi	s3,s3,-1436 # 800185c8 <tickslock>
    80002b6c:	00007497          	auipc	s1,0x7
    80002b70:	72c48493          	addi	s1,s1,1836 # 8000a298 <ticks>
    if(killed(myproc())){
    80002b74:	d5bfe0ef          	jal	800018ce <myproc>
    80002b78:	daaff0ef          	jal	80002122 <killed>
    80002b7c:	ed0d                	bnez	a0,80002bb6 <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002b7e:	85ce                	mv	a1,s3
    80002b80:	8526                	mv	a0,s1
    80002b82:	b68ff0ef          	jal	80001eea <sleep>
  while(ticks - ticks0 < n){
    80002b86:	409c                	lw	a5,0(s1)
    80002b88:	412787bb          	subw	a5,a5,s2
    80002b8c:	fcc42703          	lw	a4,-52(s0)
    80002b90:	fee7e2e3          	bltu	a5,a4,80002b74 <sys_pause+0x4a>
    80002b94:	74a2                	ld	s1,40(sp)
    80002b96:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002b98:	00016517          	auipc	a0,0x16
    80002b9c:	a3050513          	addi	a0,a0,-1488 # 800185c8 <tickslock>
    80002ba0:	8c6fe0ef          	jal	80000c66 <release>
  return 0;
    80002ba4:	4501                	li	a0,0
}
    80002ba6:	70e2                	ld	ra,56(sp)
    80002ba8:	7442                	ld	s0,48(sp)
    80002baa:	7902                	ld	s2,32(sp)
    80002bac:	6121                	addi	sp,sp,64
    80002bae:	8082                	ret
    n = 0;
    80002bb0:	fc042623          	sw	zero,-52(s0)
    80002bb4:	bf49                	j	80002b46 <sys_pause+0x1c>
      release(&tickslock);
    80002bb6:	00016517          	auipc	a0,0x16
    80002bba:	a1250513          	addi	a0,a0,-1518 # 800185c8 <tickslock>
    80002bbe:	8a8fe0ef          	jal	80000c66 <release>
      return -1;
    80002bc2:	557d                	li	a0,-1
    80002bc4:	74a2                	ld	s1,40(sp)
    80002bc6:	69e2                	ld	s3,24(sp)
    80002bc8:	bff9                	j	80002ba6 <sys_pause+0x7c>

0000000080002bca <sys_kill>:

uint64
sys_kill(void)
{
    80002bca:	1101                	addi	sp,sp,-32
    80002bcc:	ec06                	sd	ra,24(sp)
    80002bce:	e822                	sd	s0,16(sp)
    80002bd0:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002bd2:	fec40593          	addi	a1,s0,-20
    80002bd6:	4501                	li	a0,0
    80002bd8:	d9bff0ef          	jal	80002972 <argint>
  return kkill(pid);
    80002bdc:	fec42503          	lw	a0,-20(s0)
    80002be0:	cb8ff0ef          	jal	80002098 <kkill>
}
    80002be4:	60e2                	ld	ra,24(sp)
    80002be6:	6442                	ld	s0,16(sp)
    80002be8:	6105                	addi	sp,sp,32
    80002bea:	8082                	ret

0000000080002bec <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002bec:	1101                	addi	sp,sp,-32
    80002bee:	ec06                	sd	ra,24(sp)
    80002bf0:	e822                	sd	s0,16(sp)
    80002bf2:	e426                	sd	s1,8(sp)
    80002bf4:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002bf6:	00016517          	auipc	a0,0x16
    80002bfa:	9d250513          	addi	a0,a0,-1582 # 800185c8 <tickslock>
    80002bfe:	fd1fd0ef          	jal	80000bce <acquire>
  xticks = ticks;
    80002c02:	00007497          	auipc	s1,0x7
    80002c06:	6964a483          	lw	s1,1686(s1) # 8000a298 <ticks>
  release(&tickslock);
    80002c0a:	00016517          	auipc	a0,0x16
    80002c0e:	9be50513          	addi	a0,a0,-1602 # 800185c8 <tickslock>
    80002c12:	854fe0ef          	jal	80000c66 <release>
  return xticks;
}
    80002c16:	02049513          	slli	a0,s1,0x20
    80002c1a:	9101                	srli	a0,a0,0x20
    80002c1c:	60e2                	ld	ra,24(sp)
    80002c1e:	6442                	ld	s0,16(sp)
    80002c20:	64a2                	ld	s1,8(sp)
    80002c22:	6105                	addi	sp,sp,32
    80002c24:	8082                	ret

0000000080002c26 <sys_setquantum>:


// NEW: System call to change time quantum
uint64
sys_setquantum(void)
{
    80002c26:	1101                	addi	sp,sp,-32
    80002c28:	ec06                	sd	ra,24(sp)
    80002c2a:	e822                	sd	s0,16(sp)
    80002c2c:	1000                	addi	s0,sp,32
  int new_quantum;
  
  argint(0, &new_quantum);  // Get argument from user
    80002c2e:	fec40593          	addi	a1,s0,-20
    80002c32:	4501                	li	a0,0
    80002c34:	d3fff0ef          	jal	80002972 <argint>
  
  if(new_quantum < 1 || new_quantum > 100)  // Safety limits
    80002c38:	fec42783          	lw	a5,-20(s0)
    80002c3c:	fff7869b          	addiw	a3,a5,-1
    80002c40:	06300713          	li	a4,99
    return -1;
    80002c44:	557d                	li	a0,-1
  if(new_quantum < 1 || new_quantum > 100)  // Safety limits
    80002c46:	00d76763          	bltu	a4,a3,80002c54 <sys_setquantum+0x2e>
    
  time_quantum = new_quantum;
    80002c4a:	00007717          	auipc	a4,0x7
    80002c4e:	5ef72f23          	sw	a5,1534(a4) # 8000a248 <time_quantum>
  return 0;
    80002c52:	4501                	li	a0,0
}
    80002c54:	60e2                	ld	ra,24(sp)
    80002c56:	6442                	ld	s0,16(sp)
    80002c58:	6105                	addi	sp,sp,32
    80002c5a:	8082                	ret

0000000080002c5c <sys_ps>:


uint64
sys_ps(void)
{
    80002c5c:	1141                	addi	sp,sp,-16
    80002c5e:	e406                	sd	ra,8(sp)
    80002c60:	e022                	sd	s0,0(sp)
    80002c62:	0800                	addi	s0,sp,16
  procdump();
    80002c64:	e76ff0ef          	jal	800022da <procdump>
  return 0;
}
    80002c68:	4501                	li	a0,0
    80002c6a:	60a2                	ld	ra,8(sp)
    80002c6c:	6402                	ld	s0,0(sp)
    80002c6e:	0141                	addi	sp,sp,16
    80002c70:	8082                	ret

0000000080002c72 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002c72:	7179                	addi	sp,sp,-48
    80002c74:	f406                	sd	ra,40(sp)
    80002c76:	f022                	sd	s0,32(sp)
    80002c78:	ec26                	sd	s1,24(sp)
    80002c7a:	e84a                	sd	s2,16(sp)
    80002c7c:	e44e                	sd	s3,8(sp)
    80002c7e:	e052                	sd	s4,0(sp)
    80002c80:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002c82:	00004597          	auipc	a1,0x4
    80002c86:	72e58593          	addi	a1,a1,1838 # 800073b0 <etext+0x3b0>
    80002c8a:	00016517          	auipc	a0,0x16
    80002c8e:	95650513          	addi	a0,a0,-1706 # 800185e0 <bcache>
    80002c92:	ebdfd0ef          	jal	80000b4e <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002c96:	0001e797          	auipc	a5,0x1e
    80002c9a:	94a78793          	addi	a5,a5,-1718 # 800205e0 <bcache+0x8000>
    80002c9e:	0001e717          	auipc	a4,0x1e
    80002ca2:	baa70713          	addi	a4,a4,-1110 # 80020848 <bcache+0x8268>
    80002ca6:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002caa:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002cae:	00016497          	auipc	s1,0x16
    80002cb2:	94a48493          	addi	s1,s1,-1718 # 800185f8 <bcache+0x18>
    b->next = bcache.head.next;
    80002cb6:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002cb8:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002cba:	00004a17          	auipc	s4,0x4
    80002cbe:	6fea0a13          	addi	s4,s4,1790 # 800073b8 <etext+0x3b8>
    b->next = bcache.head.next;
    80002cc2:	2b893783          	ld	a5,696(s2)
    80002cc6:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002cc8:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002ccc:	85d2                	mv	a1,s4
    80002cce:	01048513          	addi	a0,s1,16
    80002cd2:	322010ef          	jal	80003ff4 <initsleeplock>
    bcache.head.next->prev = b;
    80002cd6:	2b893783          	ld	a5,696(s2)
    80002cda:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002cdc:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002ce0:	45848493          	addi	s1,s1,1112
    80002ce4:	fd349fe3          	bne	s1,s3,80002cc2 <binit+0x50>
  }
}
    80002ce8:	70a2                	ld	ra,40(sp)
    80002cea:	7402                	ld	s0,32(sp)
    80002cec:	64e2                	ld	s1,24(sp)
    80002cee:	6942                	ld	s2,16(sp)
    80002cf0:	69a2                	ld	s3,8(sp)
    80002cf2:	6a02                	ld	s4,0(sp)
    80002cf4:	6145                	addi	sp,sp,48
    80002cf6:	8082                	ret

0000000080002cf8 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002cf8:	7179                	addi	sp,sp,-48
    80002cfa:	f406                	sd	ra,40(sp)
    80002cfc:	f022                	sd	s0,32(sp)
    80002cfe:	ec26                	sd	s1,24(sp)
    80002d00:	e84a                	sd	s2,16(sp)
    80002d02:	e44e                	sd	s3,8(sp)
    80002d04:	1800                	addi	s0,sp,48
    80002d06:	892a                	mv	s2,a0
    80002d08:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002d0a:	00016517          	auipc	a0,0x16
    80002d0e:	8d650513          	addi	a0,a0,-1834 # 800185e0 <bcache>
    80002d12:	ebdfd0ef          	jal	80000bce <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002d16:	0001e497          	auipc	s1,0x1e
    80002d1a:	b824b483          	ld	s1,-1150(s1) # 80020898 <bcache+0x82b8>
    80002d1e:	0001e797          	auipc	a5,0x1e
    80002d22:	b2a78793          	addi	a5,a5,-1238 # 80020848 <bcache+0x8268>
    80002d26:	02f48b63          	beq	s1,a5,80002d5c <bread+0x64>
    80002d2a:	873e                	mv	a4,a5
    80002d2c:	a021                	j	80002d34 <bread+0x3c>
    80002d2e:	68a4                	ld	s1,80(s1)
    80002d30:	02e48663          	beq	s1,a4,80002d5c <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002d34:	449c                	lw	a5,8(s1)
    80002d36:	ff279ce3          	bne	a5,s2,80002d2e <bread+0x36>
    80002d3a:	44dc                	lw	a5,12(s1)
    80002d3c:	ff3799e3          	bne	a5,s3,80002d2e <bread+0x36>
      b->refcnt++;
    80002d40:	40bc                	lw	a5,64(s1)
    80002d42:	2785                	addiw	a5,a5,1
    80002d44:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002d46:	00016517          	auipc	a0,0x16
    80002d4a:	89a50513          	addi	a0,a0,-1894 # 800185e0 <bcache>
    80002d4e:	f19fd0ef          	jal	80000c66 <release>
      acquiresleep(&b->lock);
    80002d52:	01048513          	addi	a0,s1,16
    80002d56:	2d4010ef          	jal	8000402a <acquiresleep>
      return b;
    80002d5a:	a889                	j	80002dac <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002d5c:	0001e497          	auipc	s1,0x1e
    80002d60:	b344b483          	ld	s1,-1228(s1) # 80020890 <bcache+0x82b0>
    80002d64:	0001e797          	auipc	a5,0x1e
    80002d68:	ae478793          	addi	a5,a5,-1308 # 80020848 <bcache+0x8268>
    80002d6c:	00f48863          	beq	s1,a5,80002d7c <bread+0x84>
    80002d70:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002d72:	40bc                	lw	a5,64(s1)
    80002d74:	cb91                	beqz	a5,80002d88 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002d76:	64a4                	ld	s1,72(s1)
    80002d78:	fee49de3          	bne	s1,a4,80002d72 <bread+0x7a>
  panic("bget: no buffers");
    80002d7c:	00004517          	auipc	a0,0x4
    80002d80:	64450513          	addi	a0,a0,1604 # 800073c0 <etext+0x3c0>
    80002d84:	a5dfd0ef          	jal	800007e0 <panic>
      b->dev = dev;
    80002d88:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002d8c:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002d90:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002d94:	4785                	li	a5,1
    80002d96:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002d98:	00016517          	auipc	a0,0x16
    80002d9c:	84850513          	addi	a0,a0,-1976 # 800185e0 <bcache>
    80002da0:	ec7fd0ef          	jal	80000c66 <release>
      acquiresleep(&b->lock);
    80002da4:	01048513          	addi	a0,s1,16
    80002da8:	282010ef          	jal	8000402a <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002dac:	409c                	lw	a5,0(s1)
    80002dae:	cb89                	beqz	a5,80002dc0 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002db0:	8526                	mv	a0,s1
    80002db2:	70a2                	ld	ra,40(sp)
    80002db4:	7402                	ld	s0,32(sp)
    80002db6:	64e2                	ld	s1,24(sp)
    80002db8:	6942                	ld	s2,16(sp)
    80002dba:	69a2                	ld	s3,8(sp)
    80002dbc:	6145                	addi	sp,sp,48
    80002dbe:	8082                	ret
    virtio_disk_rw(b, 0);
    80002dc0:	4581                	li	a1,0
    80002dc2:	8526                	mv	a0,s1
    80002dc4:	2cd020ef          	jal	80005890 <virtio_disk_rw>
    b->valid = 1;
    80002dc8:	4785                	li	a5,1
    80002dca:	c09c                	sw	a5,0(s1)
  return b;
    80002dcc:	b7d5                	j	80002db0 <bread+0xb8>

0000000080002dce <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002dce:	1101                	addi	sp,sp,-32
    80002dd0:	ec06                	sd	ra,24(sp)
    80002dd2:	e822                	sd	s0,16(sp)
    80002dd4:	e426                	sd	s1,8(sp)
    80002dd6:	1000                	addi	s0,sp,32
    80002dd8:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002dda:	0541                	addi	a0,a0,16
    80002ddc:	2cc010ef          	jal	800040a8 <holdingsleep>
    80002de0:	c911                	beqz	a0,80002df4 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002de2:	4585                	li	a1,1
    80002de4:	8526                	mv	a0,s1
    80002de6:	2ab020ef          	jal	80005890 <virtio_disk_rw>
}
    80002dea:	60e2                	ld	ra,24(sp)
    80002dec:	6442                	ld	s0,16(sp)
    80002dee:	64a2                	ld	s1,8(sp)
    80002df0:	6105                	addi	sp,sp,32
    80002df2:	8082                	ret
    panic("bwrite");
    80002df4:	00004517          	auipc	a0,0x4
    80002df8:	5e450513          	addi	a0,a0,1508 # 800073d8 <etext+0x3d8>
    80002dfc:	9e5fd0ef          	jal	800007e0 <panic>

0000000080002e00 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002e00:	1101                	addi	sp,sp,-32
    80002e02:	ec06                	sd	ra,24(sp)
    80002e04:	e822                	sd	s0,16(sp)
    80002e06:	e426                	sd	s1,8(sp)
    80002e08:	e04a                	sd	s2,0(sp)
    80002e0a:	1000                	addi	s0,sp,32
    80002e0c:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002e0e:	01050913          	addi	s2,a0,16
    80002e12:	854a                	mv	a0,s2
    80002e14:	294010ef          	jal	800040a8 <holdingsleep>
    80002e18:	c135                	beqz	a0,80002e7c <brelse+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    80002e1a:	854a                	mv	a0,s2
    80002e1c:	254010ef          	jal	80004070 <releasesleep>

  acquire(&bcache.lock);
    80002e20:	00015517          	auipc	a0,0x15
    80002e24:	7c050513          	addi	a0,a0,1984 # 800185e0 <bcache>
    80002e28:	da7fd0ef          	jal	80000bce <acquire>
  b->refcnt--;
    80002e2c:	40bc                	lw	a5,64(s1)
    80002e2e:	37fd                	addiw	a5,a5,-1
    80002e30:	0007871b          	sext.w	a4,a5
    80002e34:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002e36:	e71d                	bnez	a4,80002e64 <brelse+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002e38:	68b8                	ld	a4,80(s1)
    80002e3a:	64bc                	ld	a5,72(s1)
    80002e3c:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002e3e:	68b8                	ld	a4,80(s1)
    80002e40:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002e42:	0001d797          	auipc	a5,0x1d
    80002e46:	79e78793          	addi	a5,a5,1950 # 800205e0 <bcache+0x8000>
    80002e4a:	2b87b703          	ld	a4,696(a5)
    80002e4e:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002e50:	0001e717          	auipc	a4,0x1e
    80002e54:	9f870713          	addi	a4,a4,-1544 # 80020848 <bcache+0x8268>
    80002e58:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002e5a:	2b87b703          	ld	a4,696(a5)
    80002e5e:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002e60:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002e64:	00015517          	auipc	a0,0x15
    80002e68:	77c50513          	addi	a0,a0,1916 # 800185e0 <bcache>
    80002e6c:	dfbfd0ef          	jal	80000c66 <release>
}
    80002e70:	60e2                	ld	ra,24(sp)
    80002e72:	6442                	ld	s0,16(sp)
    80002e74:	64a2                	ld	s1,8(sp)
    80002e76:	6902                	ld	s2,0(sp)
    80002e78:	6105                	addi	sp,sp,32
    80002e7a:	8082                	ret
    panic("brelse");
    80002e7c:	00004517          	auipc	a0,0x4
    80002e80:	56450513          	addi	a0,a0,1380 # 800073e0 <etext+0x3e0>
    80002e84:	95dfd0ef          	jal	800007e0 <panic>

0000000080002e88 <bpin>:

void
bpin(struct buf *b) {
    80002e88:	1101                	addi	sp,sp,-32
    80002e8a:	ec06                	sd	ra,24(sp)
    80002e8c:	e822                	sd	s0,16(sp)
    80002e8e:	e426                	sd	s1,8(sp)
    80002e90:	1000                	addi	s0,sp,32
    80002e92:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002e94:	00015517          	auipc	a0,0x15
    80002e98:	74c50513          	addi	a0,a0,1868 # 800185e0 <bcache>
    80002e9c:	d33fd0ef          	jal	80000bce <acquire>
  b->refcnt++;
    80002ea0:	40bc                	lw	a5,64(s1)
    80002ea2:	2785                	addiw	a5,a5,1
    80002ea4:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002ea6:	00015517          	auipc	a0,0x15
    80002eaa:	73a50513          	addi	a0,a0,1850 # 800185e0 <bcache>
    80002eae:	db9fd0ef          	jal	80000c66 <release>
}
    80002eb2:	60e2                	ld	ra,24(sp)
    80002eb4:	6442                	ld	s0,16(sp)
    80002eb6:	64a2                	ld	s1,8(sp)
    80002eb8:	6105                	addi	sp,sp,32
    80002eba:	8082                	ret

0000000080002ebc <bunpin>:

void
bunpin(struct buf *b) {
    80002ebc:	1101                	addi	sp,sp,-32
    80002ebe:	ec06                	sd	ra,24(sp)
    80002ec0:	e822                	sd	s0,16(sp)
    80002ec2:	e426                	sd	s1,8(sp)
    80002ec4:	1000                	addi	s0,sp,32
    80002ec6:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002ec8:	00015517          	auipc	a0,0x15
    80002ecc:	71850513          	addi	a0,a0,1816 # 800185e0 <bcache>
    80002ed0:	cfffd0ef          	jal	80000bce <acquire>
  b->refcnt--;
    80002ed4:	40bc                	lw	a5,64(s1)
    80002ed6:	37fd                	addiw	a5,a5,-1
    80002ed8:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002eda:	00015517          	auipc	a0,0x15
    80002ede:	70650513          	addi	a0,a0,1798 # 800185e0 <bcache>
    80002ee2:	d85fd0ef          	jal	80000c66 <release>
}
    80002ee6:	60e2                	ld	ra,24(sp)
    80002ee8:	6442                	ld	s0,16(sp)
    80002eea:	64a2                	ld	s1,8(sp)
    80002eec:	6105                	addi	sp,sp,32
    80002eee:	8082                	ret

0000000080002ef0 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002ef0:	1101                	addi	sp,sp,-32
    80002ef2:	ec06                	sd	ra,24(sp)
    80002ef4:	e822                	sd	s0,16(sp)
    80002ef6:	e426                	sd	s1,8(sp)
    80002ef8:	e04a                	sd	s2,0(sp)
    80002efa:	1000                	addi	s0,sp,32
    80002efc:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002efe:	00d5d59b          	srliw	a1,a1,0xd
    80002f02:	0001e797          	auipc	a5,0x1e
    80002f06:	dba7a783          	lw	a5,-582(a5) # 80020cbc <sb+0x1c>
    80002f0a:	9dbd                	addw	a1,a1,a5
    80002f0c:	dedff0ef          	jal	80002cf8 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002f10:	0074f713          	andi	a4,s1,7
    80002f14:	4785                	li	a5,1
    80002f16:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    80002f1a:	14ce                	slli	s1,s1,0x33
    80002f1c:	90d9                	srli	s1,s1,0x36
    80002f1e:	00950733          	add	a4,a0,s1
    80002f22:	05874703          	lbu	a4,88(a4)
    80002f26:	00e7f6b3          	and	a3,a5,a4
    80002f2a:	c29d                	beqz	a3,80002f50 <bfree+0x60>
    80002f2c:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002f2e:	94aa                	add	s1,s1,a0
    80002f30:	fff7c793          	not	a5,a5
    80002f34:	8f7d                	and	a4,a4,a5
    80002f36:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002f3a:	7f9000ef          	jal	80003f32 <log_write>
  brelse(bp);
    80002f3e:	854a                	mv	a0,s2
    80002f40:	ec1ff0ef          	jal	80002e00 <brelse>
}
    80002f44:	60e2                	ld	ra,24(sp)
    80002f46:	6442                	ld	s0,16(sp)
    80002f48:	64a2                	ld	s1,8(sp)
    80002f4a:	6902                	ld	s2,0(sp)
    80002f4c:	6105                	addi	sp,sp,32
    80002f4e:	8082                	ret
    panic("freeing free block");
    80002f50:	00004517          	auipc	a0,0x4
    80002f54:	49850513          	addi	a0,a0,1176 # 800073e8 <etext+0x3e8>
    80002f58:	889fd0ef          	jal	800007e0 <panic>

0000000080002f5c <balloc>:
{
    80002f5c:	711d                	addi	sp,sp,-96
    80002f5e:	ec86                	sd	ra,88(sp)
    80002f60:	e8a2                	sd	s0,80(sp)
    80002f62:	e4a6                	sd	s1,72(sp)
    80002f64:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80002f66:	0001e797          	auipc	a5,0x1e
    80002f6a:	d3e7a783          	lw	a5,-706(a5) # 80020ca4 <sb+0x4>
    80002f6e:	0e078f63          	beqz	a5,8000306c <balloc+0x110>
    80002f72:	e0ca                	sd	s2,64(sp)
    80002f74:	fc4e                	sd	s3,56(sp)
    80002f76:	f852                	sd	s4,48(sp)
    80002f78:	f456                	sd	s5,40(sp)
    80002f7a:	f05a                	sd	s6,32(sp)
    80002f7c:	ec5e                	sd	s7,24(sp)
    80002f7e:	e862                	sd	s8,16(sp)
    80002f80:	e466                	sd	s9,8(sp)
    80002f82:	8baa                	mv	s7,a0
    80002f84:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002f86:	0001eb17          	auipc	s6,0x1e
    80002f8a:	d1ab0b13          	addi	s6,s6,-742 # 80020ca0 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f8e:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80002f90:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f92:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002f94:	6c89                	lui	s9,0x2
    80002f96:	a0b5                	j	80003002 <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002f98:	97ca                	add	a5,a5,s2
    80002f9a:	8e55                	or	a2,a2,a3
    80002f9c:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002fa0:	854a                	mv	a0,s2
    80002fa2:	791000ef          	jal	80003f32 <log_write>
        brelse(bp);
    80002fa6:	854a                	mv	a0,s2
    80002fa8:	e59ff0ef          	jal	80002e00 <brelse>
  bp = bread(dev, bno);
    80002fac:	85a6                	mv	a1,s1
    80002fae:	855e                	mv	a0,s7
    80002fb0:	d49ff0ef          	jal	80002cf8 <bread>
    80002fb4:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002fb6:	40000613          	li	a2,1024
    80002fba:	4581                	li	a1,0
    80002fbc:	05850513          	addi	a0,a0,88
    80002fc0:	ce3fd0ef          	jal	80000ca2 <memset>
  log_write(bp);
    80002fc4:	854a                	mv	a0,s2
    80002fc6:	76d000ef          	jal	80003f32 <log_write>
  brelse(bp);
    80002fca:	854a                	mv	a0,s2
    80002fcc:	e35ff0ef          	jal	80002e00 <brelse>
}
    80002fd0:	6906                	ld	s2,64(sp)
    80002fd2:	79e2                	ld	s3,56(sp)
    80002fd4:	7a42                	ld	s4,48(sp)
    80002fd6:	7aa2                	ld	s5,40(sp)
    80002fd8:	7b02                	ld	s6,32(sp)
    80002fda:	6be2                	ld	s7,24(sp)
    80002fdc:	6c42                	ld	s8,16(sp)
    80002fde:	6ca2                	ld	s9,8(sp)
}
    80002fe0:	8526                	mv	a0,s1
    80002fe2:	60e6                	ld	ra,88(sp)
    80002fe4:	6446                	ld	s0,80(sp)
    80002fe6:	64a6                	ld	s1,72(sp)
    80002fe8:	6125                	addi	sp,sp,96
    80002fea:	8082                	ret
    brelse(bp);
    80002fec:	854a                	mv	a0,s2
    80002fee:	e13ff0ef          	jal	80002e00 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002ff2:	015c87bb          	addw	a5,s9,s5
    80002ff6:	00078a9b          	sext.w	s5,a5
    80002ffa:	004b2703          	lw	a4,4(s6)
    80002ffe:	04eaff63          	bgeu	s5,a4,8000305c <balloc+0x100>
    bp = bread(dev, BBLOCK(b, sb));
    80003002:	41fad79b          	sraiw	a5,s5,0x1f
    80003006:	0137d79b          	srliw	a5,a5,0x13
    8000300a:	015787bb          	addw	a5,a5,s5
    8000300e:	40d7d79b          	sraiw	a5,a5,0xd
    80003012:	01cb2583          	lw	a1,28(s6)
    80003016:	9dbd                	addw	a1,a1,a5
    80003018:	855e                	mv	a0,s7
    8000301a:	cdfff0ef          	jal	80002cf8 <bread>
    8000301e:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003020:	004b2503          	lw	a0,4(s6)
    80003024:	000a849b          	sext.w	s1,s5
    80003028:	8762                	mv	a4,s8
    8000302a:	fca4f1e3          	bgeu	s1,a0,80002fec <balloc+0x90>
      m = 1 << (bi % 8);
    8000302e:	00777693          	andi	a3,a4,7
    80003032:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80003036:	41f7579b          	sraiw	a5,a4,0x1f
    8000303a:	01d7d79b          	srliw	a5,a5,0x1d
    8000303e:	9fb9                	addw	a5,a5,a4
    80003040:	4037d79b          	sraiw	a5,a5,0x3
    80003044:	00f90633          	add	a2,s2,a5
    80003048:	05864603          	lbu	a2,88(a2)
    8000304c:	00c6f5b3          	and	a1,a3,a2
    80003050:	d5a1                	beqz	a1,80002f98 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003052:	2705                	addiw	a4,a4,1
    80003054:	2485                	addiw	s1,s1,1
    80003056:	fd471ae3          	bne	a4,s4,8000302a <balloc+0xce>
    8000305a:	bf49                	j	80002fec <balloc+0x90>
    8000305c:	6906                	ld	s2,64(sp)
    8000305e:	79e2                	ld	s3,56(sp)
    80003060:	7a42                	ld	s4,48(sp)
    80003062:	7aa2                	ld	s5,40(sp)
    80003064:	7b02                	ld	s6,32(sp)
    80003066:	6be2                	ld	s7,24(sp)
    80003068:	6c42                	ld	s8,16(sp)
    8000306a:	6ca2                	ld	s9,8(sp)
  printf("balloc: out of blocks\n");
    8000306c:	00004517          	auipc	a0,0x4
    80003070:	39450513          	addi	a0,a0,916 # 80007400 <etext+0x400>
    80003074:	c86fd0ef          	jal	800004fa <printf>
  return 0;
    80003078:	4481                	li	s1,0
    8000307a:	b79d                	j	80002fe0 <balloc+0x84>

000000008000307c <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    8000307c:	7179                	addi	sp,sp,-48
    8000307e:	f406                	sd	ra,40(sp)
    80003080:	f022                	sd	s0,32(sp)
    80003082:	ec26                	sd	s1,24(sp)
    80003084:	e84a                	sd	s2,16(sp)
    80003086:	e44e                	sd	s3,8(sp)
    80003088:	1800                	addi	s0,sp,48
    8000308a:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    8000308c:	47ad                	li	a5,11
    8000308e:	02b7e663          	bltu	a5,a1,800030ba <bmap+0x3e>
    if((addr = ip->addrs[bn]) == 0){
    80003092:	02059793          	slli	a5,a1,0x20
    80003096:	01e7d593          	srli	a1,a5,0x1e
    8000309a:	00b504b3          	add	s1,a0,a1
    8000309e:	0504a903          	lw	s2,80(s1)
    800030a2:	06091a63          	bnez	s2,80003116 <bmap+0x9a>
      addr = balloc(ip->dev);
    800030a6:	4108                	lw	a0,0(a0)
    800030a8:	eb5ff0ef          	jal	80002f5c <balloc>
    800030ac:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800030b0:	06090363          	beqz	s2,80003116 <bmap+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    800030b4:	0524a823          	sw	s2,80(s1)
    800030b8:	a8b9                	j	80003116 <bmap+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    800030ba:	ff45849b          	addiw	s1,a1,-12
    800030be:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    800030c2:	0ff00793          	li	a5,255
    800030c6:	06e7ee63          	bltu	a5,a4,80003142 <bmap+0xc6>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    800030ca:	08052903          	lw	s2,128(a0)
    800030ce:	00091d63          	bnez	s2,800030e8 <bmap+0x6c>
      addr = balloc(ip->dev);
    800030d2:	4108                	lw	a0,0(a0)
    800030d4:	e89ff0ef          	jal	80002f5c <balloc>
    800030d8:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800030dc:	02090d63          	beqz	s2,80003116 <bmap+0x9a>
    800030e0:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    800030e2:	0929a023          	sw	s2,128(s3)
    800030e6:	a011                	j	800030ea <bmap+0x6e>
    800030e8:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    800030ea:	85ca                	mv	a1,s2
    800030ec:	0009a503          	lw	a0,0(s3)
    800030f0:	c09ff0ef          	jal	80002cf8 <bread>
    800030f4:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    800030f6:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    800030fa:	02049713          	slli	a4,s1,0x20
    800030fe:	01e75593          	srli	a1,a4,0x1e
    80003102:	00b784b3          	add	s1,a5,a1
    80003106:	0004a903          	lw	s2,0(s1)
    8000310a:	00090e63          	beqz	s2,80003126 <bmap+0xaa>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000310e:	8552                	mv	a0,s4
    80003110:	cf1ff0ef          	jal	80002e00 <brelse>
    return addr;
    80003114:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80003116:	854a                	mv	a0,s2
    80003118:	70a2                	ld	ra,40(sp)
    8000311a:	7402                	ld	s0,32(sp)
    8000311c:	64e2                	ld	s1,24(sp)
    8000311e:	6942                	ld	s2,16(sp)
    80003120:	69a2                	ld	s3,8(sp)
    80003122:	6145                	addi	sp,sp,48
    80003124:	8082                	ret
      addr = balloc(ip->dev);
    80003126:	0009a503          	lw	a0,0(s3)
    8000312a:	e33ff0ef          	jal	80002f5c <balloc>
    8000312e:	0005091b          	sext.w	s2,a0
      if(addr){
    80003132:	fc090ee3          	beqz	s2,8000310e <bmap+0x92>
        a[bn] = addr;
    80003136:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    8000313a:	8552                	mv	a0,s4
    8000313c:	5f7000ef          	jal	80003f32 <log_write>
    80003140:	b7f9                	j	8000310e <bmap+0x92>
    80003142:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003144:	00004517          	auipc	a0,0x4
    80003148:	2d450513          	addi	a0,a0,724 # 80007418 <etext+0x418>
    8000314c:	e94fd0ef          	jal	800007e0 <panic>

0000000080003150 <iget>:
{
    80003150:	7179                	addi	sp,sp,-48
    80003152:	f406                	sd	ra,40(sp)
    80003154:	f022                	sd	s0,32(sp)
    80003156:	ec26                	sd	s1,24(sp)
    80003158:	e84a                	sd	s2,16(sp)
    8000315a:	e44e                	sd	s3,8(sp)
    8000315c:	e052                	sd	s4,0(sp)
    8000315e:	1800                	addi	s0,sp,48
    80003160:	89aa                	mv	s3,a0
    80003162:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003164:	0001e517          	auipc	a0,0x1e
    80003168:	b5c50513          	addi	a0,a0,-1188 # 80020cc0 <itable>
    8000316c:	a63fd0ef          	jal	80000bce <acquire>
  empty = 0;
    80003170:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003172:	0001e497          	auipc	s1,0x1e
    80003176:	b6648493          	addi	s1,s1,-1178 # 80020cd8 <itable+0x18>
    8000317a:	0001f697          	auipc	a3,0x1f
    8000317e:	5ee68693          	addi	a3,a3,1518 # 80022768 <log>
    80003182:	a039                	j	80003190 <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003184:	02090963          	beqz	s2,800031b6 <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003188:	08848493          	addi	s1,s1,136
    8000318c:	02d48863          	beq	s1,a3,800031bc <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80003190:	449c                	lw	a5,8(s1)
    80003192:	fef059e3          	blez	a5,80003184 <iget+0x34>
    80003196:	4098                	lw	a4,0(s1)
    80003198:	ff3716e3          	bne	a4,s3,80003184 <iget+0x34>
    8000319c:	40d8                	lw	a4,4(s1)
    8000319e:	ff4713e3          	bne	a4,s4,80003184 <iget+0x34>
      ip->ref++;
    800031a2:	2785                	addiw	a5,a5,1
    800031a4:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800031a6:	0001e517          	auipc	a0,0x1e
    800031aa:	b1a50513          	addi	a0,a0,-1254 # 80020cc0 <itable>
    800031ae:	ab9fd0ef          	jal	80000c66 <release>
      return ip;
    800031b2:	8926                	mv	s2,s1
    800031b4:	a02d                	j	800031de <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800031b6:	fbe9                	bnez	a5,80003188 <iget+0x38>
      empty = ip;
    800031b8:	8926                	mv	s2,s1
    800031ba:	b7f9                	j	80003188 <iget+0x38>
  if(empty == 0)
    800031bc:	02090a63          	beqz	s2,800031f0 <iget+0xa0>
  ip->dev = dev;
    800031c0:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    800031c4:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    800031c8:	4785                	li	a5,1
    800031ca:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    800031ce:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    800031d2:	0001e517          	auipc	a0,0x1e
    800031d6:	aee50513          	addi	a0,a0,-1298 # 80020cc0 <itable>
    800031da:	a8dfd0ef          	jal	80000c66 <release>
}
    800031de:	854a                	mv	a0,s2
    800031e0:	70a2                	ld	ra,40(sp)
    800031e2:	7402                	ld	s0,32(sp)
    800031e4:	64e2                	ld	s1,24(sp)
    800031e6:	6942                	ld	s2,16(sp)
    800031e8:	69a2                	ld	s3,8(sp)
    800031ea:	6a02                	ld	s4,0(sp)
    800031ec:	6145                	addi	sp,sp,48
    800031ee:	8082                	ret
    panic("iget: no inodes");
    800031f0:	00004517          	auipc	a0,0x4
    800031f4:	24050513          	addi	a0,a0,576 # 80007430 <etext+0x430>
    800031f8:	de8fd0ef          	jal	800007e0 <panic>

00000000800031fc <iinit>:
{
    800031fc:	7179                	addi	sp,sp,-48
    800031fe:	f406                	sd	ra,40(sp)
    80003200:	f022                	sd	s0,32(sp)
    80003202:	ec26                	sd	s1,24(sp)
    80003204:	e84a                	sd	s2,16(sp)
    80003206:	e44e                	sd	s3,8(sp)
    80003208:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    8000320a:	00004597          	auipc	a1,0x4
    8000320e:	23658593          	addi	a1,a1,566 # 80007440 <etext+0x440>
    80003212:	0001e517          	auipc	a0,0x1e
    80003216:	aae50513          	addi	a0,a0,-1362 # 80020cc0 <itable>
    8000321a:	935fd0ef          	jal	80000b4e <initlock>
  for(i = 0; i < NINODE; i++) {
    8000321e:	0001e497          	auipc	s1,0x1e
    80003222:	aca48493          	addi	s1,s1,-1334 # 80020ce8 <itable+0x28>
    80003226:	0001f997          	auipc	s3,0x1f
    8000322a:	55298993          	addi	s3,s3,1362 # 80022778 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000322e:	00004917          	auipc	s2,0x4
    80003232:	21a90913          	addi	s2,s2,538 # 80007448 <etext+0x448>
    80003236:	85ca                	mv	a1,s2
    80003238:	8526                	mv	a0,s1
    8000323a:	5bb000ef          	jal	80003ff4 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    8000323e:	08848493          	addi	s1,s1,136
    80003242:	ff349ae3          	bne	s1,s3,80003236 <iinit+0x3a>
}
    80003246:	70a2                	ld	ra,40(sp)
    80003248:	7402                	ld	s0,32(sp)
    8000324a:	64e2                	ld	s1,24(sp)
    8000324c:	6942                	ld	s2,16(sp)
    8000324e:	69a2                	ld	s3,8(sp)
    80003250:	6145                	addi	sp,sp,48
    80003252:	8082                	ret

0000000080003254 <ialloc>:
{
    80003254:	7139                	addi	sp,sp,-64
    80003256:	fc06                	sd	ra,56(sp)
    80003258:	f822                	sd	s0,48(sp)
    8000325a:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    8000325c:	0001e717          	auipc	a4,0x1e
    80003260:	a5072703          	lw	a4,-1456(a4) # 80020cac <sb+0xc>
    80003264:	4785                	li	a5,1
    80003266:	06e7f063          	bgeu	a5,a4,800032c6 <ialloc+0x72>
    8000326a:	f426                	sd	s1,40(sp)
    8000326c:	f04a                	sd	s2,32(sp)
    8000326e:	ec4e                	sd	s3,24(sp)
    80003270:	e852                	sd	s4,16(sp)
    80003272:	e456                	sd	s5,8(sp)
    80003274:	e05a                	sd	s6,0(sp)
    80003276:	8aaa                	mv	s5,a0
    80003278:	8b2e                	mv	s6,a1
    8000327a:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    8000327c:	0001ea17          	auipc	s4,0x1e
    80003280:	a24a0a13          	addi	s4,s4,-1500 # 80020ca0 <sb>
    80003284:	00495593          	srli	a1,s2,0x4
    80003288:	018a2783          	lw	a5,24(s4)
    8000328c:	9dbd                	addw	a1,a1,a5
    8000328e:	8556                	mv	a0,s5
    80003290:	a69ff0ef          	jal	80002cf8 <bread>
    80003294:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80003296:	05850993          	addi	s3,a0,88
    8000329a:	00f97793          	andi	a5,s2,15
    8000329e:	079a                	slli	a5,a5,0x6
    800032a0:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800032a2:	00099783          	lh	a5,0(s3)
    800032a6:	cb9d                	beqz	a5,800032dc <ialloc+0x88>
    brelse(bp);
    800032a8:	b59ff0ef          	jal	80002e00 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800032ac:	0905                	addi	s2,s2,1
    800032ae:	00ca2703          	lw	a4,12(s4)
    800032b2:	0009079b          	sext.w	a5,s2
    800032b6:	fce7e7e3          	bltu	a5,a4,80003284 <ialloc+0x30>
    800032ba:	74a2                	ld	s1,40(sp)
    800032bc:	7902                	ld	s2,32(sp)
    800032be:	69e2                	ld	s3,24(sp)
    800032c0:	6a42                	ld	s4,16(sp)
    800032c2:	6aa2                	ld	s5,8(sp)
    800032c4:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800032c6:	00004517          	auipc	a0,0x4
    800032ca:	18a50513          	addi	a0,a0,394 # 80007450 <etext+0x450>
    800032ce:	a2cfd0ef          	jal	800004fa <printf>
  return 0;
    800032d2:	4501                	li	a0,0
}
    800032d4:	70e2                	ld	ra,56(sp)
    800032d6:	7442                	ld	s0,48(sp)
    800032d8:	6121                	addi	sp,sp,64
    800032da:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800032dc:	04000613          	li	a2,64
    800032e0:	4581                	li	a1,0
    800032e2:	854e                	mv	a0,s3
    800032e4:	9bffd0ef          	jal	80000ca2 <memset>
      dip->type = type;
    800032e8:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800032ec:	8526                	mv	a0,s1
    800032ee:	445000ef          	jal	80003f32 <log_write>
      brelse(bp);
    800032f2:	8526                	mv	a0,s1
    800032f4:	b0dff0ef          	jal	80002e00 <brelse>
      return iget(dev, inum);
    800032f8:	0009059b          	sext.w	a1,s2
    800032fc:	8556                	mv	a0,s5
    800032fe:	e53ff0ef          	jal	80003150 <iget>
    80003302:	74a2                	ld	s1,40(sp)
    80003304:	7902                	ld	s2,32(sp)
    80003306:	69e2                	ld	s3,24(sp)
    80003308:	6a42                	ld	s4,16(sp)
    8000330a:	6aa2                	ld	s5,8(sp)
    8000330c:	6b02                	ld	s6,0(sp)
    8000330e:	b7d9                	j	800032d4 <ialloc+0x80>

0000000080003310 <iupdate>:
{
    80003310:	1101                	addi	sp,sp,-32
    80003312:	ec06                	sd	ra,24(sp)
    80003314:	e822                	sd	s0,16(sp)
    80003316:	e426                	sd	s1,8(sp)
    80003318:	e04a                	sd	s2,0(sp)
    8000331a:	1000                	addi	s0,sp,32
    8000331c:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000331e:	415c                	lw	a5,4(a0)
    80003320:	0047d79b          	srliw	a5,a5,0x4
    80003324:	0001e597          	auipc	a1,0x1e
    80003328:	9945a583          	lw	a1,-1644(a1) # 80020cb8 <sb+0x18>
    8000332c:	9dbd                	addw	a1,a1,a5
    8000332e:	4108                	lw	a0,0(a0)
    80003330:	9c9ff0ef          	jal	80002cf8 <bread>
    80003334:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003336:	05850793          	addi	a5,a0,88
    8000333a:	40d8                	lw	a4,4(s1)
    8000333c:	8b3d                	andi	a4,a4,15
    8000333e:	071a                	slli	a4,a4,0x6
    80003340:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003342:	04449703          	lh	a4,68(s1)
    80003346:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000334a:	04649703          	lh	a4,70(s1)
    8000334e:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003352:	04849703          	lh	a4,72(s1)
    80003356:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000335a:	04a49703          	lh	a4,74(s1)
    8000335e:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003362:	44f8                	lw	a4,76(s1)
    80003364:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003366:	03400613          	li	a2,52
    8000336a:	05048593          	addi	a1,s1,80
    8000336e:	00c78513          	addi	a0,a5,12
    80003372:	98dfd0ef          	jal	80000cfe <memmove>
  log_write(bp);
    80003376:	854a                	mv	a0,s2
    80003378:	3bb000ef          	jal	80003f32 <log_write>
  brelse(bp);
    8000337c:	854a                	mv	a0,s2
    8000337e:	a83ff0ef          	jal	80002e00 <brelse>
}
    80003382:	60e2                	ld	ra,24(sp)
    80003384:	6442                	ld	s0,16(sp)
    80003386:	64a2                	ld	s1,8(sp)
    80003388:	6902                	ld	s2,0(sp)
    8000338a:	6105                	addi	sp,sp,32
    8000338c:	8082                	ret

000000008000338e <idup>:
{
    8000338e:	1101                	addi	sp,sp,-32
    80003390:	ec06                	sd	ra,24(sp)
    80003392:	e822                	sd	s0,16(sp)
    80003394:	e426                	sd	s1,8(sp)
    80003396:	1000                	addi	s0,sp,32
    80003398:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000339a:	0001e517          	auipc	a0,0x1e
    8000339e:	92650513          	addi	a0,a0,-1754 # 80020cc0 <itable>
    800033a2:	82dfd0ef          	jal	80000bce <acquire>
  ip->ref++;
    800033a6:	449c                	lw	a5,8(s1)
    800033a8:	2785                	addiw	a5,a5,1
    800033aa:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800033ac:	0001e517          	auipc	a0,0x1e
    800033b0:	91450513          	addi	a0,a0,-1772 # 80020cc0 <itable>
    800033b4:	8b3fd0ef          	jal	80000c66 <release>
}
    800033b8:	8526                	mv	a0,s1
    800033ba:	60e2                	ld	ra,24(sp)
    800033bc:	6442                	ld	s0,16(sp)
    800033be:	64a2                	ld	s1,8(sp)
    800033c0:	6105                	addi	sp,sp,32
    800033c2:	8082                	ret

00000000800033c4 <ilock>:
{
    800033c4:	1101                	addi	sp,sp,-32
    800033c6:	ec06                	sd	ra,24(sp)
    800033c8:	e822                	sd	s0,16(sp)
    800033ca:	e426                	sd	s1,8(sp)
    800033cc:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    800033ce:	cd19                	beqz	a0,800033ec <ilock+0x28>
    800033d0:	84aa                	mv	s1,a0
    800033d2:	451c                	lw	a5,8(a0)
    800033d4:	00f05c63          	blez	a5,800033ec <ilock+0x28>
  acquiresleep(&ip->lock);
    800033d8:	0541                	addi	a0,a0,16
    800033da:	451000ef          	jal	8000402a <acquiresleep>
  if(ip->valid == 0){
    800033de:	40bc                	lw	a5,64(s1)
    800033e0:	cf89                	beqz	a5,800033fa <ilock+0x36>
}
    800033e2:	60e2                	ld	ra,24(sp)
    800033e4:	6442                	ld	s0,16(sp)
    800033e6:	64a2                	ld	s1,8(sp)
    800033e8:	6105                	addi	sp,sp,32
    800033ea:	8082                	ret
    800033ec:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800033ee:	00004517          	auipc	a0,0x4
    800033f2:	07a50513          	addi	a0,a0,122 # 80007468 <etext+0x468>
    800033f6:	beafd0ef          	jal	800007e0 <panic>
    800033fa:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800033fc:	40dc                	lw	a5,4(s1)
    800033fe:	0047d79b          	srliw	a5,a5,0x4
    80003402:	0001e597          	auipc	a1,0x1e
    80003406:	8b65a583          	lw	a1,-1866(a1) # 80020cb8 <sb+0x18>
    8000340a:	9dbd                	addw	a1,a1,a5
    8000340c:	4088                	lw	a0,0(s1)
    8000340e:	8ebff0ef          	jal	80002cf8 <bread>
    80003412:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003414:	05850593          	addi	a1,a0,88
    80003418:	40dc                	lw	a5,4(s1)
    8000341a:	8bbd                	andi	a5,a5,15
    8000341c:	079a                	slli	a5,a5,0x6
    8000341e:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003420:	00059783          	lh	a5,0(a1)
    80003424:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003428:	00259783          	lh	a5,2(a1)
    8000342c:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003430:	00459783          	lh	a5,4(a1)
    80003434:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003438:	00659783          	lh	a5,6(a1)
    8000343c:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003440:	459c                	lw	a5,8(a1)
    80003442:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003444:	03400613          	li	a2,52
    80003448:	05b1                	addi	a1,a1,12
    8000344a:	05048513          	addi	a0,s1,80
    8000344e:	8b1fd0ef          	jal	80000cfe <memmove>
    brelse(bp);
    80003452:	854a                	mv	a0,s2
    80003454:	9adff0ef          	jal	80002e00 <brelse>
    ip->valid = 1;
    80003458:	4785                	li	a5,1
    8000345a:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    8000345c:	04449783          	lh	a5,68(s1)
    80003460:	c399                	beqz	a5,80003466 <ilock+0xa2>
    80003462:	6902                	ld	s2,0(sp)
    80003464:	bfbd                	j	800033e2 <ilock+0x1e>
      panic("ilock: no type");
    80003466:	00004517          	auipc	a0,0x4
    8000346a:	00a50513          	addi	a0,a0,10 # 80007470 <etext+0x470>
    8000346e:	b72fd0ef          	jal	800007e0 <panic>

0000000080003472 <iunlock>:
{
    80003472:	1101                	addi	sp,sp,-32
    80003474:	ec06                	sd	ra,24(sp)
    80003476:	e822                	sd	s0,16(sp)
    80003478:	e426                	sd	s1,8(sp)
    8000347a:	e04a                	sd	s2,0(sp)
    8000347c:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000347e:	c505                	beqz	a0,800034a6 <iunlock+0x34>
    80003480:	84aa                	mv	s1,a0
    80003482:	01050913          	addi	s2,a0,16
    80003486:	854a                	mv	a0,s2
    80003488:	421000ef          	jal	800040a8 <holdingsleep>
    8000348c:	cd09                	beqz	a0,800034a6 <iunlock+0x34>
    8000348e:	449c                	lw	a5,8(s1)
    80003490:	00f05b63          	blez	a5,800034a6 <iunlock+0x34>
  releasesleep(&ip->lock);
    80003494:	854a                	mv	a0,s2
    80003496:	3db000ef          	jal	80004070 <releasesleep>
}
    8000349a:	60e2                	ld	ra,24(sp)
    8000349c:	6442                	ld	s0,16(sp)
    8000349e:	64a2                	ld	s1,8(sp)
    800034a0:	6902                	ld	s2,0(sp)
    800034a2:	6105                	addi	sp,sp,32
    800034a4:	8082                	ret
    panic("iunlock");
    800034a6:	00004517          	auipc	a0,0x4
    800034aa:	fda50513          	addi	a0,a0,-38 # 80007480 <etext+0x480>
    800034ae:	b32fd0ef          	jal	800007e0 <panic>

00000000800034b2 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800034b2:	7179                	addi	sp,sp,-48
    800034b4:	f406                	sd	ra,40(sp)
    800034b6:	f022                	sd	s0,32(sp)
    800034b8:	ec26                	sd	s1,24(sp)
    800034ba:	e84a                	sd	s2,16(sp)
    800034bc:	e44e                	sd	s3,8(sp)
    800034be:	1800                	addi	s0,sp,48
    800034c0:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800034c2:	05050493          	addi	s1,a0,80
    800034c6:	08050913          	addi	s2,a0,128
    800034ca:	a021                	j	800034d2 <itrunc+0x20>
    800034cc:	0491                	addi	s1,s1,4
    800034ce:	01248b63          	beq	s1,s2,800034e4 <itrunc+0x32>
    if(ip->addrs[i]){
    800034d2:	408c                	lw	a1,0(s1)
    800034d4:	dde5                	beqz	a1,800034cc <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800034d6:	0009a503          	lw	a0,0(s3)
    800034da:	a17ff0ef          	jal	80002ef0 <bfree>
      ip->addrs[i] = 0;
    800034de:	0004a023          	sw	zero,0(s1)
    800034e2:	b7ed                	j	800034cc <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    800034e4:	0809a583          	lw	a1,128(s3)
    800034e8:	ed89                	bnez	a1,80003502 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800034ea:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800034ee:	854e                	mv	a0,s3
    800034f0:	e21ff0ef          	jal	80003310 <iupdate>
}
    800034f4:	70a2                	ld	ra,40(sp)
    800034f6:	7402                	ld	s0,32(sp)
    800034f8:	64e2                	ld	s1,24(sp)
    800034fa:	6942                	ld	s2,16(sp)
    800034fc:	69a2                	ld	s3,8(sp)
    800034fe:	6145                	addi	sp,sp,48
    80003500:	8082                	ret
    80003502:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003504:	0009a503          	lw	a0,0(s3)
    80003508:	ff0ff0ef          	jal	80002cf8 <bread>
    8000350c:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    8000350e:	05850493          	addi	s1,a0,88
    80003512:	45850913          	addi	s2,a0,1112
    80003516:	a021                	j	8000351e <itrunc+0x6c>
    80003518:	0491                	addi	s1,s1,4
    8000351a:	01248963          	beq	s1,s2,8000352c <itrunc+0x7a>
      if(a[j])
    8000351e:	408c                	lw	a1,0(s1)
    80003520:	dde5                	beqz	a1,80003518 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003522:	0009a503          	lw	a0,0(s3)
    80003526:	9cbff0ef          	jal	80002ef0 <bfree>
    8000352a:	b7fd                	j	80003518 <itrunc+0x66>
    brelse(bp);
    8000352c:	8552                	mv	a0,s4
    8000352e:	8d3ff0ef          	jal	80002e00 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003532:	0809a583          	lw	a1,128(s3)
    80003536:	0009a503          	lw	a0,0(s3)
    8000353a:	9b7ff0ef          	jal	80002ef0 <bfree>
    ip->addrs[NDIRECT] = 0;
    8000353e:	0809a023          	sw	zero,128(s3)
    80003542:	6a02                	ld	s4,0(sp)
    80003544:	b75d                	j	800034ea <itrunc+0x38>

0000000080003546 <iput>:
{
    80003546:	1101                	addi	sp,sp,-32
    80003548:	ec06                	sd	ra,24(sp)
    8000354a:	e822                	sd	s0,16(sp)
    8000354c:	e426                	sd	s1,8(sp)
    8000354e:	1000                	addi	s0,sp,32
    80003550:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003552:	0001d517          	auipc	a0,0x1d
    80003556:	76e50513          	addi	a0,a0,1902 # 80020cc0 <itable>
    8000355a:	e74fd0ef          	jal	80000bce <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000355e:	4498                	lw	a4,8(s1)
    80003560:	4785                	li	a5,1
    80003562:	02f70063          	beq	a4,a5,80003582 <iput+0x3c>
  ip->ref--;
    80003566:	449c                	lw	a5,8(s1)
    80003568:	37fd                	addiw	a5,a5,-1
    8000356a:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000356c:	0001d517          	auipc	a0,0x1d
    80003570:	75450513          	addi	a0,a0,1876 # 80020cc0 <itable>
    80003574:	ef2fd0ef          	jal	80000c66 <release>
}
    80003578:	60e2                	ld	ra,24(sp)
    8000357a:	6442                	ld	s0,16(sp)
    8000357c:	64a2                	ld	s1,8(sp)
    8000357e:	6105                	addi	sp,sp,32
    80003580:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003582:	40bc                	lw	a5,64(s1)
    80003584:	d3ed                	beqz	a5,80003566 <iput+0x20>
    80003586:	04a49783          	lh	a5,74(s1)
    8000358a:	fff1                	bnez	a5,80003566 <iput+0x20>
    8000358c:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    8000358e:	01048913          	addi	s2,s1,16
    80003592:	854a                	mv	a0,s2
    80003594:	297000ef          	jal	8000402a <acquiresleep>
    release(&itable.lock);
    80003598:	0001d517          	auipc	a0,0x1d
    8000359c:	72850513          	addi	a0,a0,1832 # 80020cc0 <itable>
    800035a0:	ec6fd0ef          	jal	80000c66 <release>
    itrunc(ip);
    800035a4:	8526                	mv	a0,s1
    800035a6:	f0dff0ef          	jal	800034b2 <itrunc>
    ip->type = 0;
    800035aa:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800035ae:	8526                	mv	a0,s1
    800035b0:	d61ff0ef          	jal	80003310 <iupdate>
    ip->valid = 0;
    800035b4:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800035b8:	854a                	mv	a0,s2
    800035ba:	2b7000ef          	jal	80004070 <releasesleep>
    acquire(&itable.lock);
    800035be:	0001d517          	auipc	a0,0x1d
    800035c2:	70250513          	addi	a0,a0,1794 # 80020cc0 <itable>
    800035c6:	e08fd0ef          	jal	80000bce <acquire>
    800035ca:	6902                	ld	s2,0(sp)
    800035cc:	bf69                	j	80003566 <iput+0x20>

00000000800035ce <iunlockput>:
{
    800035ce:	1101                	addi	sp,sp,-32
    800035d0:	ec06                	sd	ra,24(sp)
    800035d2:	e822                	sd	s0,16(sp)
    800035d4:	e426                	sd	s1,8(sp)
    800035d6:	1000                	addi	s0,sp,32
    800035d8:	84aa                	mv	s1,a0
  iunlock(ip);
    800035da:	e99ff0ef          	jal	80003472 <iunlock>
  iput(ip);
    800035de:	8526                	mv	a0,s1
    800035e0:	f67ff0ef          	jal	80003546 <iput>
}
    800035e4:	60e2                	ld	ra,24(sp)
    800035e6:	6442                	ld	s0,16(sp)
    800035e8:	64a2                	ld	s1,8(sp)
    800035ea:	6105                	addi	sp,sp,32
    800035ec:	8082                	ret

00000000800035ee <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800035ee:	0001d717          	auipc	a4,0x1d
    800035f2:	6be72703          	lw	a4,1726(a4) # 80020cac <sb+0xc>
    800035f6:	4785                	li	a5,1
    800035f8:	0ae7ff63          	bgeu	a5,a4,800036b6 <ireclaim+0xc8>
{
    800035fc:	7139                	addi	sp,sp,-64
    800035fe:	fc06                	sd	ra,56(sp)
    80003600:	f822                	sd	s0,48(sp)
    80003602:	f426                	sd	s1,40(sp)
    80003604:	f04a                	sd	s2,32(sp)
    80003606:	ec4e                	sd	s3,24(sp)
    80003608:	e852                	sd	s4,16(sp)
    8000360a:	e456                	sd	s5,8(sp)
    8000360c:	e05a                	sd	s6,0(sp)
    8000360e:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003610:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003612:	00050a1b          	sext.w	s4,a0
    80003616:	0001da97          	auipc	s5,0x1d
    8000361a:	68aa8a93          	addi	s5,s5,1674 # 80020ca0 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    8000361e:	00004b17          	auipc	s6,0x4
    80003622:	e6ab0b13          	addi	s6,s6,-406 # 80007488 <etext+0x488>
    80003626:	a099                	j	8000366c <ireclaim+0x7e>
    80003628:	85ce                	mv	a1,s3
    8000362a:	855a                	mv	a0,s6
    8000362c:	ecffc0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    80003630:	85ce                	mv	a1,s3
    80003632:	8552                	mv	a0,s4
    80003634:	b1dff0ef          	jal	80003150 <iget>
    80003638:	89aa                	mv	s3,a0
    brelse(bp);
    8000363a:	854a                	mv	a0,s2
    8000363c:	fc4ff0ef          	jal	80002e00 <brelse>
    if (ip) {
    80003640:	00098f63          	beqz	s3,8000365e <ireclaim+0x70>
      begin_op();
    80003644:	76a000ef          	jal	80003dae <begin_op>
      ilock(ip);
    80003648:	854e                	mv	a0,s3
    8000364a:	d7bff0ef          	jal	800033c4 <ilock>
      iunlock(ip);
    8000364e:	854e                	mv	a0,s3
    80003650:	e23ff0ef          	jal	80003472 <iunlock>
      iput(ip);
    80003654:	854e                	mv	a0,s3
    80003656:	ef1ff0ef          	jal	80003546 <iput>
      end_op();
    8000365a:	7be000ef          	jal	80003e18 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000365e:	0485                	addi	s1,s1,1
    80003660:	00caa703          	lw	a4,12(s5)
    80003664:	0004879b          	sext.w	a5,s1
    80003668:	02e7fd63          	bgeu	a5,a4,800036a2 <ireclaim+0xb4>
    8000366c:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003670:	0044d593          	srli	a1,s1,0x4
    80003674:	018aa783          	lw	a5,24(s5)
    80003678:	9dbd                	addw	a1,a1,a5
    8000367a:	8552                	mv	a0,s4
    8000367c:	e7cff0ef          	jal	80002cf8 <bread>
    80003680:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003682:	05850793          	addi	a5,a0,88
    80003686:	00f9f713          	andi	a4,s3,15
    8000368a:	071a                	slli	a4,a4,0x6
    8000368c:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    8000368e:	00079703          	lh	a4,0(a5)
    80003692:	c701                	beqz	a4,8000369a <ireclaim+0xac>
    80003694:	00679783          	lh	a5,6(a5)
    80003698:	dbc1                	beqz	a5,80003628 <ireclaim+0x3a>
    brelse(bp);
    8000369a:	854a                	mv	a0,s2
    8000369c:	f64ff0ef          	jal	80002e00 <brelse>
    if (ip) {
    800036a0:	bf7d                	j	8000365e <ireclaim+0x70>
}
    800036a2:	70e2                	ld	ra,56(sp)
    800036a4:	7442                	ld	s0,48(sp)
    800036a6:	74a2                	ld	s1,40(sp)
    800036a8:	7902                	ld	s2,32(sp)
    800036aa:	69e2                	ld	s3,24(sp)
    800036ac:	6a42                	ld	s4,16(sp)
    800036ae:	6aa2                	ld	s5,8(sp)
    800036b0:	6b02                	ld	s6,0(sp)
    800036b2:	6121                	addi	sp,sp,64
    800036b4:	8082                	ret
    800036b6:	8082                	ret

00000000800036b8 <fsinit>:
fsinit(int dev) {
    800036b8:	7179                	addi	sp,sp,-48
    800036ba:	f406                	sd	ra,40(sp)
    800036bc:	f022                	sd	s0,32(sp)
    800036be:	ec26                	sd	s1,24(sp)
    800036c0:	e84a                	sd	s2,16(sp)
    800036c2:	e44e                	sd	s3,8(sp)
    800036c4:	1800                	addi	s0,sp,48
    800036c6:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    800036c8:	4585                	li	a1,1
    800036ca:	e2eff0ef          	jal	80002cf8 <bread>
    800036ce:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    800036d0:	0001d997          	auipc	s3,0x1d
    800036d4:	5d098993          	addi	s3,s3,1488 # 80020ca0 <sb>
    800036d8:	02000613          	li	a2,32
    800036dc:	05850593          	addi	a1,a0,88
    800036e0:	854e                	mv	a0,s3
    800036e2:	e1cfd0ef          	jal	80000cfe <memmove>
  brelse(bp);
    800036e6:	854a                	mv	a0,s2
    800036e8:	f18ff0ef          	jal	80002e00 <brelse>
  if(sb.magic != FSMAGIC)
    800036ec:	0009a703          	lw	a4,0(s3)
    800036f0:	102037b7          	lui	a5,0x10203
    800036f4:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800036f8:	02f71363          	bne	a4,a5,8000371e <fsinit+0x66>
  initlog(dev, &sb);
    800036fc:	0001d597          	auipc	a1,0x1d
    80003700:	5a458593          	addi	a1,a1,1444 # 80020ca0 <sb>
    80003704:	8526                	mv	a0,s1
    80003706:	62a000ef          	jal	80003d30 <initlog>
  ireclaim(dev);
    8000370a:	8526                	mv	a0,s1
    8000370c:	ee3ff0ef          	jal	800035ee <ireclaim>
}
    80003710:	70a2                	ld	ra,40(sp)
    80003712:	7402                	ld	s0,32(sp)
    80003714:	64e2                	ld	s1,24(sp)
    80003716:	6942                	ld	s2,16(sp)
    80003718:	69a2                	ld	s3,8(sp)
    8000371a:	6145                	addi	sp,sp,48
    8000371c:	8082                	ret
    panic("invalid file system");
    8000371e:	00004517          	auipc	a0,0x4
    80003722:	d8a50513          	addi	a0,a0,-630 # 800074a8 <etext+0x4a8>
    80003726:	8bafd0ef          	jal	800007e0 <panic>

000000008000372a <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    8000372a:	1141                	addi	sp,sp,-16
    8000372c:	e422                	sd	s0,8(sp)
    8000372e:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003730:	411c                	lw	a5,0(a0)
    80003732:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003734:	415c                	lw	a5,4(a0)
    80003736:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003738:	04451783          	lh	a5,68(a0)
    8000373c:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003740:	04a51783          	lh	a5,74(a0)
    80003744:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003748:	04c56783          	lwu	a5,76(a0)
    8000374c:	e99c                	sd	a5,16(a1)
}
    8000374e:	6422                	ld	s0,8(sp)
    80003750:	0141                	addi	sp,sp,16
    80003752:	8082                	ret

0000000080003754 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003754:	457c                	lw	a5,76(a0)
    80003756:	0ed7eb63          	bltu	a5,a3,8000384c <readi+0xf8>
{
    8000375a:	7159                	addi	sp,sp,-112
    8000375c:	f486                	sd	ra,104(sp)
    8000375e:	f0a2                	sd	s0,96(sp)
    80003760:	eca6                	sd	s1,88(sp)
    80003762:	e0d2                	sd	s4,64(sp)
    80003764:	fc56                	sd	s5,56(sp)
    80003766:	f85a                	sd	s6,48(sp)
    80003768:	f45e                	sd	s7,40(sp)
    8000376a:	1880                	addi	s0,sp,112
    8000376c:	8b2a                	mv	s6,a0
    8000376e:	8bae                	mv	s7,a1
    80003770:	8a32                	mv	s4,a2
    80003772:	84b6                	mv	s1,a3
    80003774:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003776:	9f35                	addw	a4,a4,a3
    return 0;
    80003778:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    8000377a:	0cd76063          	bltu	a4,a3,8000383a <readi+0xe6>
    8000377e:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80003780:	00e7f463          	bgeu	a5,a4,80003788 <readi+0x34>
    n = ip->size - off;
    80003784:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003788:	080a8f63          	beqz	s5,80003826 <readi+0xd2>
    8000378c:	e8ca                	sd	s2,80(sp)
    8000378e:	f062                	sd	s8,32(sp)
    80003790:	ec66                	sd	s9,24(sp)
    80003792:	e86a                	sd	s10,16(sp)
    80003794:	e46e                	sd	s11,8(sp)
    80003796:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003798:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    8000379c:	5c7d                	li	s8,-1
    8000379e:	a80d                	j	800037d0 <readi+0x7c>
    800037a0:	020d1d93          	slli	s11,s10,0x20
    800037a4:	020ddd93          	srli	s11,s11,0x20
    800037a8:	05890613          	addi	a2,s2,88
    800037ac:	86ee                	mv	a3,s11
    800037ae:	963a                	add	a2,a2,a4
    800037b0:	85d2                	mv	a1,s4
    800037b2:	855e                	mv	a0,s7
    800037b4:	a93fe0ef          	jal	80002246 <either_copyout>
    800037b8:	05850763          	beq	a0,s8,80003806 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800037bc:	854a                	mv	a0,s2
    800037be:	e42ff0ef          	jal	80002e00 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800037c2:	013d09bb          	addw	s3,s10,s3
    800037c6:	009d04bb          	addw	s1,s10,s1
    800037ca:	9a6e                	add	s4,s4,s11
    800037cc:	0559f763          	bgeu	s3,s5,8000381a <readi+0xc6>
    uint addr = bmap(ip, off/BSIZE);
    800037d0:	00a4d59b          	srliw	a1,s1,0xa
    800037d4:	855a                	mv	a0,s6
    800037d6:	8a7ff0ef          	jal	8000307c <bmap>
    800037da:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    800037de:	c5b1                	beqz	a1,8000382a <readi+0xd6>
    bp = bread(ip->dev, addr);
    800037e0:	000b2503          	lw	a0,0(s6)
    800037e4:	d14ff0ef          	jal	80002cf8 <bread>
    800037e8:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800037ea:	3ff4f713          	andi	a4,s1,1023
    800037ee:	40ec87bb          	subw	a5,s9,a4
    800037f2:	413a86bb          	subw	a3,s5,s3
    800037f6:	8d3e                	mv	s10,a5
    800037f8:	2781                	sext.w	a5,a5
    800037fa:	0006861b          	sext.w	a2,a3
    800037fe:	faf671e3          	bgeu	a2,a5,800037a0 <readi+0x4c>
    80003802:	8d36                	mv	s10,a3
    80003804:	bf71                	j	800037a0 <readi+0x4c>
      brelse(bp);
    80003806:	854a                	mv	a0,s2
    80003808:	df8ff0ef          	jal	80002e00 <brelse>
      tot = -1;
    8000380c:	59fd                	li	s3,-1
      break;
    8000380e:	6946                	ld	s2,80(sp)
    80003810:	7c02                	ld	s8,32(sp)
    80003812:	6ce2                	ld	s9,24(sp)
    80003814:	6d42                	ld	s10,16(sp)
    80003816:	6da2                	ld	s11,8(sp)
    80003818:	a831                	j	80003834 <readi+0xe0>
    8000381a:	6946                	ld	s2,80(sp)
    8000381c:	7c02                	ld	s8,32(sp)
    8000381e:	6ce2                	ld	s9,24(sp)
    80003820:	6d42                	ld	s10,16(sp)
    80003822:	6da2                	ld	s11,8(sp)
    80003824:	a801                	j	80003834 <readi+0xe0>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003826:	89d6                	mv	s3,s5
    80003828:	a031                	j	80003834 <readi+0xe0>
    8000382a:	6946                	ld	s2,80(sp)
    8000382c:	7c02                	ld	s8,32(sp)
    8000382e:	6ce2                	ld	s9,24(sp)
    80003830:	6d42                	ld	s10,16(sp)
    80003832:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003834:	0009851b          	sext.w	a0,s3
    80003838:	69a6                	ld	s3,72(sp)
}
    8000383a:	70a6                	ld	ra,104(sp)
    8000383c:	7406                	ld	s0,96(sp)
    8000383e:	64e6                	ld	s1,88(sp)
    80003840:	6a06                	ld	s4,64(sp)
    80003842:	7ae2                	ld	s5,56(sp)
    80003844:	7b42                	ld	s6,48(sp)
    80003846:	7ba2                	ld	s7,40(sp)
    80003848:	6165                	addi	sp,sp,112
    8000384a:	8082                	ret
    return 0;
    8000384c:	4501                	li	a0,0
}
    8000384e:	8082                	ret

0000000080003850 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003850:	457c                	lw	a5,76(a0)
    80003852:	10d7e063          	bltu	a5,a3,80003952 <writei+0x102>
{
    80003856:	7159                	addi	sp,sp,-112
    80003858:	f486                	sd	ra,104(sp)
    8000385a:	f0a2                	sd	s0,96(sp)
    8000385c:	e8ca                	sd	s2,80(sp)
    8000385e:	e0d2                	sd	s4,64(sp)
    80003860:	fc56                	sd	s5,56(sp)
    80003862:	f85a                	sd	s6,48(sp)
    80003864:	f45e                	sd	s7,40(sp)
    80003866:	1880                	addi	s0,sp,112
    80003868:	8aaa                	mv	s5,a0
    8000386a:	8bae                	mv	s7,a1
    8000386c:	8a32                	mv	s4,a2
    8000386e:	8936                	mv	s2,a3
    80003870:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003872:	00e687bb          	addw	a5,a3,a4
    80003876:	0ed7e063          	bltu	a5,a3,80003956 <writei+0x106>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    8000387a:	00043737          	lui	a4,0x43
    8000387e:	0cf76e63          	bltu	a4,a5,8000395a <writei+0x10a>
    80003882:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003884:	0a0b0f63          	beqz	s6,80003942 <writei+0xf2>
    80003888:	eca6                	sd	s1,88(sp)
    8000388a:	f062                	sd	s8,32(sp)
    8000388c:	ec66                	sd	s9,24(sp)
    8000388e:	e86a                	sd	s10,16(sp)
    80003890:	e46e                	sd	s11,8(sp)
    80003892:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003894:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003898:	5c7d                	li	s8,-1
    8000389a:	a825                	j	800038d2 <writei+0x82>
    8000389c:	020d1d93          	slli	s11,s10,0x20
    800038a0:	020ddd93          	srli	s11,s11,0x20
    800038a4:	05848513          	addi	a0,s1,88
    800038a8:	86ee                	mv	a3,s11
    800038aa:	8652                	mv	a2,s4
    800038ac:	85de                	mv	a1,s7
    800038ae:	953a                	add	a0,a0,a4
    800038b0:	9e1fe0ef          	jal	80002290 <either_copyin>
    800038b4:	05850a63          	beq	a0,s8,80003908 <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    800038b8:	8526                	mv	a0,s1
    800038ba:	678000ef          	jal	80003f32 <log_write>
    brelse(bp);
    800038be:	8526                	mv	a0,s1
    800038c0:	d40ff0ef          	jal	80002e00 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800038c4:	013d09bb          	addw	s3,s10,s3
    800038c8:	012d093b          	addw	s2,s10,s2
    800038cc:	9a6e                	add	s4,s4,s11
    800038ce:	0569f063          	bgeu	s3,s6,8000390e <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    800038d2:	00a9559b          	srliw	a1,s2,0xa
    800038d6:	8556                	mv	a0,s5
    800038d8:	fa4ff0ef          	jal	8000307c <bmap>
    800038dc:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    800038e0:	c59d                	beqz	a1,8000390e <writei+0xbe>
    bp = bread(ip->dev, addr);
    800038e2:	000aa503          	lw	a0,0(s5)
    800038e6:	c12ff0ef          	jal	80002cf8 <bread>
    800038ea:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800038ec:	3ff97713          	andi	a4,s2,1023
    800038f0:	40ec87bb          	subw	a5,s9,a4
    800038f4:	413b06bb          	subw	a3,s6,s3
    800038f8:	8d3e                	mv	s10,a5
    800038fa:	2781                	sext.w	a5,a5
    800038fc:	0006861b          	sext.w	a2,a3
    80003900:	f8f67ee3          	bgeu	a2,a5,8000389c <writei+0x4c>
    80003904:	8d36                	mv	s10,a3
    80003906:	bf59                	j	8000389c <writei+0x4c>
      brelse(bp);
    80003908:	8526                	mv	a0,s1
    8000390a:	cf6ff0ef          	jal	80002e00 <brelse>
  }

  if(off > ip->size)
    8000390e:	04caa783          	lw	a5,76(s5)
    80003912:	0327fa63          	bgeu	a5,s2,80003946 <writei+0xf6>
    ip->size = off;
    80003916:	052aa623          	sw	s2,76(s5)
    8000391a:	64e6                	ld	s1,88(sp)
    8000391c:	7c02                	ld	s8,32(sp)
    8000391e:	6ce2                	ld	s9,24(sp)
    80003920:	6d42                	ld	s10,16(sp)
    80003922:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003924:	8556                	mv	a0,s5
    80003926:	9ebff0ef          	jal	80003310 <iupdate>

  return tot;
    8000392a:	0009851b          	sext.w	a0,s3
    8000392e:	69a6                	ld	s3,72(sp)
}
    80003930:	70a6                	ld	ra,104(sp)
    80003932:	7406                	ld	s0,96(sp)
    80003934:	6946                	ld	s2,80(sp)
    80003936:	6a06                	ld	s4,64(sp)
    80003938:	7ae2                	ld	s5,56(sp)
    8000393a:	7b42                	ld	s6,48(sp)
    8000393c:	7ba2                	ld	s7,40(sp)
    8000393e:	6165                	addi	sp,sp,112
    80003940:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003942:	89da                	mv	s3,s6
    80003944:	b7c5                	j	80003924 <writei+0xd4>
    80003946:	64e6                	ld	s1,88(sp)
    80003948:	7c02                	ld	s8,32(sp)
    8000394a:	6ce2                	ld	s9,24(sp)
    8000394c:	6d42                	ld	s10,16(sp)
    8000394e:	6da2                	ld	s11,8(sp)
    80003950:	bfd1                	j	80003924 <writei+0xd4>
    return -1;
    80003952:	557d                	li	a0,-1
}
    80003954:	8082                	ret
    return -1;
    80003956:	557d                	li	a0,-1
    80003958:	bfe1                	j	80003930 <writei+0xe0>
    return -1;
    8000395a:	557d                	li	a0,-1
    8000395c:	bfd1                	j	80003930 <writei+0xe0>

000000008000395e <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    8000395e:	1141                	addi	sp,sp,-16
    80003960:	e406                	sd	ra,8(sp)
    80003962:	e022                	sd	s0,0(sp)
    80003964:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003966:	4639                	li	a2,14
    80003968:	c06fd0ef          	jal	80000d6e <strncmp>
}
    8000396c:	60a2                	ld	ra,8(sp)
    8000396e:	6402                	ld	s0,0(sp)
    80003970:	0141                	addi	sp,sp,16
    80003972:	8082                	ret

0000000080003974 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003974:	7139                	addi	sp,sp,-64
    80003976:	fc06                	sd	ra,56(sp)
    80003978:	f822                	sd	s0,48(sp)
    8000397a:	f426                	sd	s1,40(sp)
    8000397c:	f04a                	sd	s2,32(sp)
    8000397e:	ec4e                	sd	s3,24(sp)
    80003980:	e852                	sd	s4,16(sp)
    80003982:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003984:	04451703          	lh	a4,68(a0)
    80003988:	4785                	li	a5,1
    8000398a:	00f71a63          	bne	a4,a5,8000399e <dirlookup+0x2a>
    8000398e:	892a                	mv	s2,a0
    80003990:	89ae                	mv	s3,a1
    80003992:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003994:	457c                	lw	a5,76(a0)
    80003996:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003998:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000399a:	e39d                	bnez	a5,800039c0 <dirlookup+0x4c>
    8000399c:	a095                	j	80003a00 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    8000399e:	00004517          	auipc	a0,0x4
    800039a2:	b2250513          	addi	a0,a0,-1246 # 800074c0 <etext+0x4c0>
    800039a6:	e3bfc0ef          	jal	800007e0 <panic>
      panic("dirlookup read");
    800039aa:	00004517          	auipc	a0,0x4
    800039ae:	b2e50513          	addi	a0,a0,-1234 # 800074d8 <etext+0x4d8>
    800039b2:	e2ffc0ef          	jal	800007e0 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    800039b6:	24c1                	addiw	s1,s1,16
    800039b8:	04c92783          	lw	a5,76(s2)
    800039bc:	04f4f163          	bgeu	s1,a5,800039fe <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800039c0:	4741                	li	a4,16
    800039c2:	86a6                	mv	a3,s1
    800039c4:	fc040613          	addi	a2,s0,-64
    800039c8:	4581                	li	a1,0
    800039ca:	854a                	mv	a0,s2
    800039cc:	d89ff0ef          	jal	80003754 <readi>
    800039d0:	47c1                	li	a5,16
    800039d2:	fcf51ce3          	bne	a0,a5,800039aa <dirlookup+0x36>
    if(de.inum == 0)
    800039d6:	fc045783          	lhu	a5,-64(s0)
    800039da:	dff1                	beqz	a5,800039b6 <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    800039dc:	fc240593          	addi	a1,s0,-62
    800039e0:	854e                	mv	a0,s3
    800039e2:	f7dff0ef          	jal	8000395e <namecmp>
    800039e6:	f961                	bnez	a0,800039b6 <dirlookup+0x42>
      if(poff)
    800039e8:	000a0463          	beqz	s4,800039f0 <dirlookup+0x7c>
        *poff = off;
    800039ec:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    800039f0:	fc045583          	lhu	a1,-64(s0)
    800039f4:	00092503          	lw	a0,0(s2)
    800039f8:	f58ff0ef          	jal	80003150 <iget>
    800039fc:	a011                	j	80003a00 <dirlookup+0x8c>
  return 0;
    800039fe:	4501                	li	a0,0
}
    80003a00:	70e2                	ld	ra,56(sp)
    80003a02:	7442                	ld	s0,48(sp)
    80003a04:	74a2                	ld	s1,40(sp)
    80003a06:	7902                	ld	s2,32(sp)
    80003a08:	69e2                	ld	s3,24(sp)
    80003a0a:	6a42                	ld	s4,16(sp)
    80003a0c:	6121                	addi	sp,sp,64
    80003a0e:	8082                	ret

0000000080003a10 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003a10:	711d                	addi	sp,sp,-96
    80003a12:	ec86                	sd	ra,88(sp)
    80003a14:	e8a2                	sd	s0,80(sp)
    80003a16:	e4a6                	sd	s1,72(sp)
    80003a18:	e0ca                	sd	s2,64(sp)
    80003a1a:	fc4e                	sd	s3,56(sp)
    80003a1c:	f852                	sd	s4,48(sp)
    80003a1e:	f456                	sd	s5,40(sp)
    80003a20:	f05a                	sd	s6,32(sp)
    80003a22:	ec5e                	sd	s7,24(sp)
    80003a24:	e862                	sd	s8,16(sp)
    80003a26:	e466                	sd	s9,8(sp)
    80003a28:	1080                	addi	s0,sp,96
    80003a2a:	84aa                	mv	s1,a0
    80003a2c:	8b2e                	mv	s6,a1
    80003a2e:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003a30:	00054703          	lbu	a4,0(a0)
    80003a34:	02f00793          	li	a5,47
    80003a38:	00f70e63          	beq	a4,a5,80003a54 <namex+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003a3c:	e93fd0ef          	jal	800018ce <myproc>
    80003a40:	15053503          	ld	a0,336(a0)
    80003a44:	94bff0ef          	jal	8000338e <idup>
    80003a48:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003a4a:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    80003a4e:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003a50:	4b85                	li	s7,1
    80003a52:	a871                	j	80003aee <namex+0xde>
    ip = iget(ROOTDEV, ROOTINO);
    80003a54:	4585                	li	a1,1
    80003a56:	4505                	li	a0,1
    80003a58:	ef8ff0ef          	jal	80003150 <iget>
    80003a5c:	8a2a                	mv	s4,a0
    80003a5e:	b7f5                	j	80003a4a <namex+0x3a>
      iunlockput(ip);
    80003a60:	8552                	mv	a0,s4
    80003a62:	b6dff0ef          	jal	800035ce <iunlockput>
      return 0;
    80003a66:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003a68:	8552                	mv	a0,s4
    80003a6a:	60e6                	ld	ra,88(sp)
    80003a6c:	6446                	ld	s0,80(sp)
    80003a6e:	64a6                	ld	s1,72(sp)
    80003a70:	6906                	ld	s2,64(sp)
    80003a72:	79e2                	ld	s3,56(sp)
    80003a74:	7a42                	ld	s4,48(sp)
    80003a76:	7aa2                	ld	s5,40(sp)
    80003a78:	7b02                	ld	s6,32(sp)
    80003a7a:	6be2                	ld	s7,24(sp)
    80003a7c:	6c42                	ld	s8,16(sp)
    80003a7e:	6ca2                	ld	s9,8(sp)
    80003a80:	6125                	addi	sp,sp,96
    80003a82:	8082                	ret
      iunlock(ip);
    80003a84:	8552                	mv	a0,s4
    80003a86:	9edff0ef          	jal	80003472 <iunlock>
      return ip;
    80003a8a:	bff9                	j	80003a68 <namex+0x58>
      iunlockput(ip);
    80003a8c:	8552                	mv	a0,s4
    80003a8e:	b41ff0ef          	jal	800035ce <iunlockput>
      return 0;
    80003a92:	8a4e                	mv	s4,s3
    80003a94:	bfd1                	j	80003a68 <namex+0x58>
  len = path - s;
    80003a96:	40998633          	sub	a2,s3,s1
    80003a9a:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003a9e:	099c5063          	bge	s8,s9,80003b1e <namex+0x10e>
    memmove(name, s, DIRSIZ);
    80003aa2:	4639                	li	a2,14
    80003aa4:	85a6                	mv	a1,s1
    80003aa6:	8556                	mv	a0,s5
    80003aa8:	a56fd0ef          	jal	80000cfe <memmove>
    80003aac:	84ce                	mv	s1,s3
  while(*path == '/')
    80003aae:	0004c783          	lbu	a5,0(s1)
    80003ab2:	01279763          	bne	a5,s2,80003ac0 <namex+0xb0>
    path++;
    80003ab6:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003ab8:	0004c783          	lbu	a5,0(s1)
    80003abc:	ff278de3          	beq	a5,s2,80003ab6 <namex+0xa6>
    ilock(ip);
    80003ac0:	8552                	mv	a0,s4
    80003ac2:	903ff0ef          	jal	800033c4 <ilock>
    if(ip->type != T_DIR){
    80003ac6:	044a1783          	lh	a5,68(s4)
    80003aca:	f9779be3          	bne	a5,s7,80003a60 <namex+0x50>
    if(nameiparent && *path == '\0'){
    80003ace:	000b0563          	beqz	s6,80003ad8 <namex+0xc8>
    80003ad2:	0004c783          	lbu	a5,0(s1)
    80003ad6:	d7dd                	beqz	a5,80003a84 <namex+0x74>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003ad8:	4601                	li	a2,0
    80003ada:	85d6                	mv	a1,s5
    80003adc:	8552                	mv	a0,s4
    80003ade:	e97ff0ef          	jal	80003974 <dirlookup>
    80003ae2:	89aa                	mv	s3,a0
    80003ae4:	d545                	beqz	a0,80003a8c <namex+0x7c>
    iunlockput(ip);
    80003ae6:	8552                	mv	a0,s4
    80003ae8:	ae7ff0ef          	jal	800035ce <iunlockput>
    ip = next;
    80003aec:	8a4e                	mv	s4,s3
  while(*path == '/')
    80003aee:	0004c783          	lbu	a5,0(s1)
    80003af2:	01279763          	bne	a5,s2,80003b00 <namex+0xf0>
    path++;
    80003af6:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003af8:	0004c783          	lbu	a5,0(s1)
    80003afc:	ff278de3          	beq	a5,s2,80003af6 <namex+0xe6>
  if(*path == 0)
    80003b00:	cb8d                	beqz	a5,80003b32 <namex+0x122>
  while(*path != '/' && *path != 0)
    80003b02:	0004c783          	lbu	a5,0(s1)
    80003b06:	89a6                	mv	s3,s1
  len = path - s;
    80003b08:	4c81                	li	s9,0
    80003b0a:	4601                	li	a2,0
  while(*path != '/' && *path != 0)
    80003b0c:	01278963          	beq	a5,s2,80003b1e <namex+0x10e>
    80003b10:	d3d9                	beqz	a5,80003a96 <namex+0x86>
    path++;
    80003b12:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    80003b14:	0009c783          	lbu	a5,0(s3)
    80003b18:	ff279ce3          	bne	a5,s2,80003b10 <namex+0x100>
    80003b1c:	bfad                	j	80003a96 <namex+0x86>
    memmove(name, s, len);
    80003b1e:	2601                	sext.w	a2,a2
    80003b20:	85a6                	mv	a1,s1
    80003b22:	8556                	mv	a0,s5
    80003b24:	9dafd0ef          	jal	80000cfe <memmove>
    name[len] = 0;
    80003b28:	9cd6                	add	s9,s9,s5
    80003b2a:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003b2e:	84ce                	mv	s1,s3
    80003b30:	bfbd                	j	80003aae <namex+0x9e>
  if(nameiparent){
    80003b32:	f20b0be3          	beqz	s6,80003a68 <namex+0x58>
    iput(ip);
    80003b36:	8552                	mv	a0,s4
    80003b38:	a0fff0ef          	jal	80003546 <iput>
    return 0;
    80003b3c:	4a01                	li	s4,0
    80003b3e:	b72d                	j	80003a68 <namex+0x58>

0000000080003b40 <dirlink>:
{
    80003b40:	7139                	addi	sp,sp,-64
    80003b42:	fc06                	sd	ra,56(sp)
    80003b44:	f822                	sd	s0,48(sp)
    80003b46:	f04a                	sd	s2,32(sp)
    80003b48:	ec4e                	sd	s3,24(sp)
    80003b4a:	e852                	sd	s4,16(sp)
    80003b4c:	0080                	addi	s0,sp,64
    80003b4e:	892a                	mv	s2,a0
    80003b50:	8a2e                	mv	s4,a1
    80003b52:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003b54:	4601                	li	a2,0
    80003b56:	e1fff0ef          	jal	80003974 <dirlookup>
    80003b5a:	e535                	bnez	a0,80003bc6 <dirlink+0x86>
    80003b5c:	f426                	sd	s1,40(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003b5e:	04c92483          	lw	s1,76(s2)
    80003b62:	c48d                	beqz	s1,80003b8c <dirlink+0x4c>
    80003b64:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b66:	4741                	li	a4,16
    80003b68:	86a6                	mv	a3,s1
    80003b6a:	fc040613          	addi	a2,s0,-64
    80003b6e:	4581                	li	a1,0
    80003b70:	854a                	mv	a0,s2
    80003b72:	be3ff0ef          	jal	80003754 <readi>
    80003b76:	47c1                	li	a5,16
    80003b78:	04f51b63          	bne	a0,a5,80003bce <dirlink+0x8e>
    if(de.inum == 0)
    80003b7c:	fc045783          	lhu	a5,-64(s0)
    80003b80:	c791                	beqz	a5,80003b8c <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003b82:	24c1                	addiw	s1,s1,16
    80003b84:	04c92783          	lw	a5,76(s2)
    80003b88:	fcf4efe3          	bltu	s1,a5,80003b66 <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003b8c:	4639                	li	a2,14
    80003b8e:	85d2                	mv	a1,s4
    80003b90:	fc240513          	addi	a0,s0,-62
    80003b94:	a10fd0ef          	jal	80000da4 <strncpy>
  de.inum = inum;
    80003b98:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b9c:	4741                	li	a4,16
    80003b9e:	86a6                	mv	a3,s1
    80003ba0:	fc040613          	addi	a2,s0,-64
    80003ba4:	4581                	li	a1,0
    80003ba6:	854a                	mv	a0,s2
    80003ba8:	ca9ff0ef          	jal	80003850 <writei>
    80003bac:	1541                	addi	a0,a0,-16
    80003bae:	00a03533          	snez	a0,a0
    80003bb2:	40a00533          	neg	a0,a0
    80003bb6:	74a2                	ld	s1,40(sp)
}
    80003bb8:	70e2                	ld	ra,56(sp)
    80003bba:	7442                	ld	s0,48(sp)
    80003bbc:	7902                	ld	s2,32(sp)
    80003bbe:	69e2                	ld	s3,24(sp)
    80003bc0:	6a42                	ld	s4,16(sp)
    80003bc2:	6121                	addi	sp,sp,64
    80003bc4:	8082                	ret
    iput(ip);
    80003bc6:	981ff0ef          	jal	80003546 <iput>
    return -1;
    80003bca:	557d                	li	a0,-1
    80003bcc:	b7f5                	j	80003bb8 <dirlink+0x78>
      panic("dirlink read");
    80003bce:	00004517          	auipc	a0,0x4
    80003bd2:	91a50513          	addi	a0,a0,-1766 # 800074e8 <etext+0x4e8>
    80003bd6:	c0bfc0ef          	jal	800007e0 <panic>

0000000080003bda <namei>:

struct inode*
namei(char *path)
{
    80003bda:	1101                	addi	sp,sp,-32
    80003bdc:	ec06                	sd	ra,24(sp)
    80003bde:	e822                	sd	s0,16(sp)
    80003be0:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003be2:	fe040613          	addi	a2,s0,-32
    80003be6:	4581                	li	a1,0
    80003be8:	e29ff0ef          	jal	80003a10 <namex>
}
    80003bec:	60e2                	ld	ra,24(sp)
    80003bee:	6442                	ld	s0,16(sp)
    80003bf0:	6105                	addi	sp,sp,32
    80003bf2:	8082                	ret

0000000080003bf4 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003bf4:	1141                	addi	sp,sp,-16
    80003bf6:	e406                	sd	ra,8(sp)
    80003bf8:	e022                	sd	s0,0(sp)
    80003bfa:	0800                	addi	s0,sp,16
    80003bfc:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003bfe:	4585                	li	a1,1
    80003c00:	e11ff0ef          	jal	80003a10 <namex>
}
    80003c04:	60a2                	ld	ra,8(sp)
    80003c06:	6402                	ld	s0,0(sp)
    80003c08:	0141                	addi	sp,sp,16
    80003c0a:	8082                	ret

0000000080003c0c <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003c0c:	1101                	addi	sp,sp,-32
    80003c0e:	ec06                	sd	ra,24(sp)
    80003c10:	e822                	sd	s0,16(sp)
    80003c12:	e426                	sd	s1,8(sp)
    80003c14:	e04a                	sd	s2,0(sp)
    80003c16:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003c18:	0001f917          	auipc	s2,0x1f
    80003c1c:	b5090913          	addi	s2,s2,-1200 # 80022768 <log>
    80003c20:	01892583          	lw	a1,24(s2)
    80003c24:	02492503          	lw	a0,36(s2)
    80003c28:	8d0ff0ef          	jal	80002cf8 <bread>
    80003c2c:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003c2e:	02892603          	lw	a2,40(s2)
    80003c32:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003c34:	00c05f63          	blez	a2,80003c52 <write_head+0x46>
    80003c38:	0001f717          	auipc	a4,0x1f
    80003c3c:	b5c70713          	addi	a4,a4,-1188 # 80022794 <log+0x2c>
    80003c40:	87aa                	mv	a5,a0
    80003c42:	060a                	slli	a2,a2,0x2
    80003c44:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003c46:	4314                	lw	a3,0(a4)
    80003c48:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003c4a:	0711                	addi	a4,a4,4
    80003c4c:	0791                	addi	a5,a5,4
    80003c4e:	fec79ce3          	bne	a5,a2,80003c46 <write_head+0x3a>
  }
  bwrite(buf);
    80003c52:	8526                	mv	a0,s1
    80003c54:	97aff0ef          	jal	80002dce <bwrite>
  brelse(buf);
    80003c58:	8526                	mv	a0,s1
    80003c5a:	9a6ff0ef          	jal	80002e00 <brelse>
}
    80003c5e:	60e2                	ld	ra,24(sp)
    80003c60:	6442                	ld	s0,16(sp)
    80003c62:	64a2                	ld	s1,8(sp)
    80003c64:	6902                	ld	s2,0(sp)
    80003c66:	6105                	addi	sp,sp,32
    80003c68:	8082                	ret

0000000080003c6a <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c6a:	0001f797          	auipc	a5,0x1f
    80003c6e:	b267a783          	lw	a5,-1242(a5) # 80022790 <log+0x28>
    80003c72:	0af05e63          	blez	a5,80003d2e <install_trans+0xc4>
{
    80003c76:	715d                	addi	sp,sp,-80
    80003c78:	e486                	sd	ra,72(sp)
    80003c7a:	e0a2                	sd	s0,64(sp)
    80003c7c:	fc26                	sd	s1,56(sp)
    80003c7e:	f84a                	sd	s2,48(sp)
    80003c80:	f44e                	sd	s3,40(sp)
    80003c82:	f052                	sd	s4,32(sp)
    80003c84:	ec56                	sd	s5,24(sp)
    80003c86:	e85a                	sd	s6,16(sp)
    80003c88:	e45e                	sd	s7,8(sp)
    80003c8a:	0880                	addi	s0,sp,80
    80003c8c:	8b2a                	mv	s6,a0
    80003c8e:	0001fa97          	auipc	s5,0x1f
    80003c92:	b06a8a93          	addi	s5,s5,-1274 # 80022794 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c96:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003c98:	00004b97          	auipc	s7,0x4
    80003c9c:	860b8b93          	addi	s7,s7,-1952 # 800074f8 <etext+0x4f8>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003ca0:	0001fa17          	auipc	s4,0x1f
    80003ca4:	ac8a0a13          	addi	s4,s4,-1336 # 80022768 <log>
    80003ca8:	a025                	j	80003cd0 <install_trans+0x66>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003caa:	000aa603          	lw	a2,0(s5)
    80003cae:	85ce                	mv	a1,s3
    80003cb0:	855e                	mv	a0,s7
    80003cb2:	849fc0ef          	jal	800004fa <printf>
    80003cb6:	a839                	j	80003cd4 <install_trans+0x6a>
    brelse(lbuf);
    80003cb8:	854a                	mv	a0,s2
    80003cba:	946ff0ef          	jal	80002e00 <brelse>
    brelse(dbuf);
    80003cbe:	8526                	mv	a0,s1
    80003cc0:	940ff0ef          	jal	80002e00 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003cc4:	2985                	addiw	s3,s3,1
    80003cc6:	0a91                	addi	s5,s5,4
    80003cc8:	028a2783          	lw	a5,40(s4)
    80003ccc:	04f9d663          	bge	s3,a5,80003d18 <install_trans+0xae>
    if(recovering) {
    80003cd0:	fc0b1de3          	bnez	s6,80003caa <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003cd4:	018a2583          	lw	a1,24(s4)
    80003cd8:	013585bb          	addw	a1,a1,s3
    80003cdc:	2585                	addiw	a1,a1,1
    80003cde:	024a2503          	lw	a0,36(s4)
    80003ce2:	816ff0ef          	jal	80002cf8 <bread>
    80003ce6:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003ce8:	000aa583          	lw	a1,0(s5)
    80003cec:	024a2503          	lw	a0,36(s4)
    80003cf0:	808ff0ef          	jal	80002cf8 <bread>
    80003cf4:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003cf6:	40000613          	li	a2,1024
    80003cfa:	05890593          	addi	a1,s2,88
    80003cfe:	05850513          	addi	a0,a0,88
    80003d02:	ffdfc0ef          	jal	80000cfe <memmove>
    bwrite(dbuf);  // write dst to disk
    80003d06:	8526                	mv	a0,s1
    80003d08:	8c6ff0ef          	jal	80002dce <bwrite>
    if(recovering == 0)
    80003d0c:	fa0b16e3          	bnez	s6,80003cb8 <install_trans+0x4e>
      bunpin(dbuf);
    80003d10:	8526                	mv	a0,s1
    80003d12:	9aaff0ef          	jal	80002ebc <bunpin>
    80003d16:	b74d                	j	80003cb8 <install_trans+0x4e>
}
    80003d18:	60a6                	ld	ra,72(sp)
    80003d1a:	6406                	ld	s0,64(sp)
    80003d1c:	74e2                	ld	s1,56(sp)
    80003d1e:	7942                	ld	s2,48(sp)
    80003d20:	79a2                	ld	s3,40(sp)
    80003d22:	7a02                	ld	s4,32(sp)
    80003d24:	6ae2                	ld	s5,24(sp)
    80003d26:	6b42                	ld	s6,16(sp)
    80003d28:	6ba2                	ld	s7,8(sp)
    80003d2a:	6161                	addi	sp,sp,80
    80003d2c:	8082                	ret
    80003d2e:	8082                	ret

0000000080003d30 <initlog>:
{
    80003d30:	7179                	addi	sp,sp,-48
    80003d32:	f406                	sd	ra,40(sp)
    80003d34:	f022                	sd	s0,32(sp)
    80003d36:	ec26                	sd	s1,24(sp)
    80003d38:	e84a                	sd	s2,16(sp)
    80003d3a:	e44e                	sd	s3,8(sp)
    80003d3c:	1800                	addi	s0,sp,48
    80003d3e:	892a                	mv	s2,a0
    80003d40:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003d42:	0001f497          	auipc	s1,0x1f
    80003d46:	a2648493          	addi	s1,s1,-1498 # 80022768 <log>
    80003d4a:	00003597          	auipc	a1,0x3
    80003d4e:	7ce58593          	addi	a1,a1,1998 # 80007518 <etext+0x518>
    80003d52:	8526                	mv	a0,s1
    80003d54:	dfbfc0ef          	jal	80000b4e <initlock>
  log.start = sb->logstart;
    80003d58:	0149a583          	lw	a1,20(s3)
    80003d5c:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    80003d5e:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003d62:	854a                	mv	a0,s2
    80003d64:	f95fe0ef          	jal	80002cf8 <bread>
  log.lh.n = lh->n;
    80003d68:	4d30                	lw	a2,88(a0)
    80003d6a:	d490                	sw	a2,40(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003d6c:	00c05f63          	blez	a2,80003d8a <initlog+0x5a>
    80003d70:	87aa                	mv	a5,a0
    80003d72:	0001f717          	auipc	a4,0x1f
    80003d76:	a2270713          	addi	a4,a4,-1502 # 80022794 <log+0x2c>
    80003d7a:	060a                	slli	a2,a2,0x2
    80003d7c:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003d7e:	4ff4                	lw	a3,92(a5)
    80003d80:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003d82:	0791                	addi	a5,a5,4
    80003d84:	0711                	addi	a4,a4,4
    80003d86:	fec79ce3          	bne	a5,a2,80003d7e <initlog+0x4e>
  brelse(buf);
    80003d8a:	876ff0ef          	jal	80002e00 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003d8e:	4505                	li	a0,1
    80003d90:	edbff0ef          	jal	80003c6a <install_trans>
  log.lh.n = 0;
    80003d94:	0001f797          	auipc	a5,0x1f
    80003d98:	9e07ae23          	sw	zero,-1540(a5) # 80022790 <log+0x28>
  write_head(); // clear the log
    80003d9c:	e71ff0ef          	jal	80003c0c <write_head>
}
    80003da0:	70a2                	ld	ra,40(sp)
    80003da2:	7402                	ld	s0,32(sp)
    80003da4:	64e2                	ld	s1,24(sp)
    80003da6:	6942                	ld	s2,16(sp)
    80003da8:	69a2                	ld	s3,8(sp)
    80003daa:	6145                	addi	sp,sp,48
    80003dac:	8082                	ret

0000000080003dae <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003dae:	1101                	addi	sp,sp,-32
    80003db0:	ec06                	sd	ra,24(sp)
    80003db2:	e822                	sd	s0,16(sp)
    80003db4:	e426                	sd	s1,8(sp)
    80003db6:	e04a                	sd	s2,0(sp)
    80003db8:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003dba:	0001f517          	auipc	a0,0x1f
    80003dbe:	9ae50513          	addi	a0,a0,-1618 # 80022768 <log>
    80003dc2:	e0dfc0ef          	jal	80000bce <acquire>
  while(1){
    if(log.committing){
    80003dc6:	0001f497          	auipc	s1,0x1f
    80003dca:	9a248493          	addi	s1,s1,-1630 # 80022768 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003dce:	4979                	li	s2,30
    80003dd0:	a029                	j	80003dda <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003dd2:	85a6                	mv	a1,s1
    80003dd4:	8526                	mv	a0,s1
    80003dd6:	914fe0ef          	jal	80001eea <sleep>
    if(log.committing){
    80003dda:	509c                	lw	a5,32(s1)
    80003ddc:	fbfd                	bnez	a5,80003dd2 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003dde:	4cd8                	lw	a4,28(s1)
    80003de0:	2705                	addiw	a4,a4,1
    80003de2:	0027179b          	slliw	a5,a4,0x2
    80003de6:	9fb9                	addw	a5,a5,a4
    80003de8:	0017979b          	slliw	a5,a5,0x1
    80003dec:	5494                	lw	a3,40(s1)
    80003dee:	9fb5                	addw	a5,a5,a3
    80003df0:	00f95763          	bge	s2,a5,80003dfe <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003df4:	85a6                	mv	a1,s1
    80003df6:	8526                	mv	a0,s1
    80003df8:	8f2fe0ef          	jal	80001eea <sleep>
    80003dfc:	bff9                	j	80003dda <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003dfe:	0001f517          	auipc	a0,0x1f
    80003e02:	96a50513          	addi	a0,a0,-1686 # 80022768 <log>
    80003e06:	cd58                	sw	a4,28(a0)
      release(&log.lock);
    80003e08:	e5ffc0ef          	jal	80000c66 <release>
      break;
    }
  }
}
    80003e0c:	60e2                	ld	ra,24(sp)
    80003e0e:	6442                	ld	s0,16(sp)
    80003e10:	64a2                	ld	s1,8(sp)
    80003e12:	6902                	ld	s2,0(sp)
    80003e14:	6105                	addi	sp,sp,32
    80003e16:	8082                	ret

0000000080003e18 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003e18:	7139                	addi	sp,sp,-64
    80003e1a:	fc06                	sd	ra,56(sp)
    80003e1c:	f822                	sd	s0,48(sp)
    80003e1e:	f426                	sd	s1,40(sp)
    80003e20:	f04a                	sd	s2,32(sp)
    80003e22:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003e24:	0001f497          	auipc	s1,0x1f
    80003e28:	94448493          	addi	s1,s1,-1724 # 80022768 <log>
    80003e2c:	8526                	mv	a0,s1
    80003e2e:	da1fc0ef          	jal	80000bce <acquire>
  log.outstanding -= 1;
    80003e32:	4cdc                	lw	a5,28(s1)
    80003e34:	37fd                	addiw	a5,a5,-1
    80003e36:	0007891b          	sext.w	s2,a5
    80003e3a:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80003e3c:	509c                	lw	a5,32(s1)
    80003e3e:	ef9d                	bnez	a5,80003e7c <end_op+0x64>
    panic("log.committing");
  if(log.outstanding == 0){
    80003e40:	04091763          	bnez	s2,80003e8e <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    80003e44:	0001f497          	auipc	s1,0x1f
    80003e48:	92448493          	addi	s1,s1,-1756 # 80022768 <log>
    80003e4c:	4785                	li	a5,1
    80003e4e:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003e50:	8526                	mv	a0,s1
    80003e52:	e15fc0ef          	jal	80000c66 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003e56:	549c                	lw	a5,40(s1)
    80003e58:	04f04b63          	bgtz	a5,80003eae <end_op+0x96>
    acquire(&log.lock);
    80003e5c:	0001f497          	auipc	s1,0x1f
    80003e60:	90c48493          	addi	s1,s1,-1780 # 80022768 <log>
    80003e64:	8526                	mv	a0,s1
    80003e66:	d69fc0ef          	jal	80000bce <acquire>
    log.committing = 0;
    80003e6a:	0204a023          	sw	zero,32(s1)
    wakeup(&log);
    80003e6e:	8526                	mv	a0,s1
    80003e70:	8c6fe0ef          	jal	80001f36 <wakeup>
    release(&log.lock);
    80003e74:	8526                	mv	a0,s1
    80003e76:	df1fc0ef          	jal	80000c66 <release>
}
    80003e7a:	a025                	j	80003ea2 <end_op+0x8a>
    80003e7c:	ec4e                	sd	s3,24(sp)
    80003e7e:	e852                	sd	s4,16(sp)
    80003e80:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003e82:	00003517          	auipc	a0,0x3
    80003e86:	69e50513          	addi	a0,a0,1694 # 80007520 <etext+0x520>
    80003e8a:	957fc0ef          	jal	800007e0 <panic>
    wakeup(&log);
    80003e8e:	0001f497          	auipc	s1,0x1f
    80003e92:	8da48493          	addi	s1,s1,-1830 # 80022768 <log>
    80003e96:	8526                	mv	a0,s1
    80003e98:	89efe0ef          	jal	80001f36 <wakeup>
  release(&log.lock);
    80003e9c:	8526                	mv	a0,s1
    80003e9e:	dc9fc0ef          	jal	80000c66 <release>
}
    80003ea2:	70e2                	ld	ra,56(sp)
    80003ea4:	7442                	ld	s0,48(sp)
    80003ea6:	74a2                	ld	s1,40(sp)
    80003ea8:	7902                	ld	s2,32(sp)
    80003eaa:	6121                	addi	sp,sp,64
    80003eac:	8082                	ret
    80003eae:	ec4e                	sd	s3,24(sp)
    80003eb0:	e852                	sd	s4,16(sp)
    80003eb2:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003eb4:	0001fa97          	auipc	s5,0x1f
    80003eb8:	8e0a8a93          	addi	s5,s5,-1824 # 80022794 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003ebc:	0001fa17          	auipc	s4,0x1f
    80003ec0:	8aca0a13          	addi	s4,s4,-1876 # 80022768 <log>
    80003ec4:	018a2583          	lw	a1,24(s4)
    80003ec8:	012585bb          	addw	a1,a1,s2
    80003ecc:	2585                	addiw	a1,a1,1
    80003ece:	024a2503          	lw	a0,36(s4)
    80003ed2:	e27fe0ef          	jal	80002cf8 <bread>
    80003ed6:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003ed8:	000aa583          	lw	a1,0(s5)
    80003edc:	024a2503          	lw	a0,36(s4)
    80003ee0:	e19fe0ef          	jal	80002cf8 <bread>
    80003ee4:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003ee6:	40000613          	li	a2,1024
    80003eea:	05850593          	addi	a1,a0,88
    80003eee:	05848513          	addi	a0,s1,88
    80003ef2:	e0dfc0ef          	jal	80000cfe <memmove>
    bwrite(to);  // write the log
    80003ef6:	8526                	mv	a0,s1
    80003ef8:	ed7fe0ef          	jal	80002dce <bwrite>
    brelse(from);
    80003efc:	854e                	mv	a0,s3
    80003efe:	f03fe0ef          	jal	80002e00 <brelse>
    brelse(to);
    80003f02:	8526                	mv	a0,s1
    80003f04:	efdfe0ef          	jal	80002e00 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003f08:	2905                	addiw	s2,s2,1
    80003f0a:	0a91                	addi	s5,s5,4
    80003f0c:	028a2783          	lw	a5,40(s4)
    80003f10:	faf94ae3          	blt	s2,a5,80003ec4 <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003f14:	cf9ff0ef          	jal	80003c0c <write_head>
    install_trans(0); // Now install writes to home locations
    80003f18:	4501                	li	a0,0
    80003f1a:	d51ff0ef          	jal	80003c6a <install_trans>
    log.lh.n = 0;
    80003f1e:	0001f797          	auipc	a5,0x1f
    80003f22:	8607a923          	sw	zero,-1934(a5) # 80022790 <log+0x28>
    write_head();    // Erase the transaction from the log
    80003f26:	ce7ff0ef          	jal	80003c0c <write_head>
    80003f2a:	69e2                	ld	s3,24(sp)
    80003f2c:	6a42                	ld	s4,16(sp)
    80003f2e:	6aa2                	ld	s5,8(sp)
    80003f30:	b735                	j	80003e5c <end_op+0x44>

0000000080003f32 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003f32:	1101                	addi	sp,sp,-32
    80003f34:	ec06                	sd	ra,24(sp)
    80003f36:	e822                	sd	s0,16(sp)
    80003f38:	e426                	sd	s1,8(sp)
    80003f3a:	e04a                	sd	s2,0(sp)
    80003f3c:	1000                	addi	s0,sp,32
    80003f3e:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003f40:	0001f917          	auipc	s2,0x1f
    80003f44:	82890913          	addi	s2,s2,-2008 # 80022768 <log>
    80003f48:	854a                	mv	a0,s2
    80003f4a:	c85fc0ef          	jal	80000bce <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003f4e:	02892603          	lw	a2,40(s2)
    80003f52:	47f5                	li	a5,29
    80003f54:	04c7cc63          	blt	a5,a2,80003fac <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003f58:	0001f797          	auipc	a5,0x1f
    80003f5c:	82c7a783          	lw	a5,-2004(a5) # 80022784 <log+0x1c>
    80003f60:	04f05c63          	blez	a5,80003fb8 <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003f64:	4781                	li	a5,0
    80003f66:	04c05f63          	blez	a2,80003fc4 <log_write+0x92>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003f6a:	44cc                	lw	a1,12(s1)
    80003f6c:	0001f717          	auipc	a4,0x1f
    80003f70:	82870713          	addi	a4,a4,-2008 # 80022794 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    80003f74:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003f76:	4314                	lw	a3,0(a4)
    80003f78:	04b68663          	beq	a3,a1,80003fc4 <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    80003f7c:	2785                	addiw	a5,a5,1
    80003f7e:	0711                	addi	a4,a4,4
    80003f80:	fef61be3          	bne	a2,a5,80003f76 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003f84:	0621                	addi	a2,a2,8
    80003f86:	060a                	slli	a2,a2,0x2
    80003f88:	0001e797          	auipc	a5,0x1e
    80003f8c:	7e078793          	addi	a5,a5,2016 # 80022768 <log>
    80003f90:	97b2                	add	a5,a5,a2
    80003f92:	44d8                	lw	a4,12(s1)
    80003f94:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003f96:	8526                	mv	a0,s1
    80003f98:	ef1fe0ef          	jal	80002e88 <bpin>
    log.lh.n++;
    80003f9c:	0001e717          	auipc	a4,0x1e
    80003fa0:	7cc70713          	addi	a4,a4,1996 # 80022768 <log>
    80003fa4:	571c                	lw	a5,40(a4)
    80003fa6:	2785                	addiw	a5,a5,1
    80003fa8:	d71c                	sw	a5,40(a4)
    80003faa:	a80d                	j	80003fdc <log_write+0xaa>
    panic("too big a transaction");
    80003fac:	00003517          	auipc	a0,0x3
    80003fb0:	58450513          	addi	a0,a0,1412 # 80007530 <etext+0x530>
    80003fb4:	82dfc0ef          	jal	800007e0 <panic>
    panic("log_write outside of trans");
    80003fb8:	00003517          	auipc	a0,0x3
    80003fbc:	59050513          	addi	a0,a0,1424 # 80007548 <etext+0x548>
    80003fc0:	821fc0ef          	jal	800007e0 <panic>
  log.lh.block[i] = b->blockno;
    80003fc4:	00878693          	addi	a3,a5,8
    80003fc8:	068a                	slli	a3,a3,0x2
    80003fca:	0001e717          	auipc	a4,0x1e
    80003fce:	79e70713          	addi	a4,a4,1950 # 80022768 <log>
    80003fd2:	9736                	add	a4,a4,a3
    80003fd4:	44d4                	lw	a3,12(s1)
    80003fd6:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003fd8:	faf60fe3          	beq	a2,a5,80003f96 <log_write+0x64>
  }
  release(&log.lock);
    80003fdc:	0001e517          	auipc	a0,0x1e
    80003fe0:	78c50513          	addi	a0,a0,1932 # 80022768 <log>
    80003fe4:	c83fc0ef          	jal	80000c66 <release>
}
    80003fe8:	60e2                	ld	ra,24(sp)
    80003fea:	6442                	ld	s0,16(sp)
    80003fec:	64a2                	ld	s1,8(sp)
    80003fee:	6902                	ld	s2,0(sp)
    80003ff0:	6105                	addi	sp,sp,32
    80003ff2:	8082                	ret

0000000080003ff4 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003ff4:	1101                	addi	sp,sp,-32
    80003ff6:	ec06                	sd	ra,24(sp)
    80003ff8:	e822                	sd	s0,16(sp)
    80003ffa:	e426                	sd	s1,8(sp)
    80003ffc:	e04a                	sd	s2,0(sp)
    80003ffe:	1000                	addi	s0,sp,32
    80004000:	84aa                	mv	s1,a0
    80004002:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80004004:	00003597          	auipc	a1,0x3
    80004008:	56458593          	addi	a1,a1,1380 # 80007568 <etext+0x568>
    8000400c:	0521                	addi	a0,a0,8
    8000400e:	b41fc0ef          	jal	80000b4e <initlock>
  lk->name = name;
    80004012:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004016:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000401a:	0204a423          	sw	zero,40(s1)
}
    8000401e:	60e2                	ld	ra,24(sp)
    80004020:	6442                	ld	s0,16(sp)
    80004022:	64a2                	ld	s1,8(sp)
    80004024:	6902                	ld	s2,0(sp)
    80004026:	6105                	addi	sp,sp,32
    80004028:	8082                	ret

000000008000402a <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000402a:	1101                	addi	sp,sp,-32
    8000402c:	ec06                	sd	ra,24(sp)
    8000402e:	e822                	sd	s0,16(sp)
    80004030:	e426                	sd	s1,8(sp)
    80004032:	e04a                	sd	s2,0(sp)
    80004034:	1000                	addi	s0,sp,32
    80004036:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004038:	00850913          	addi	s2,a0,8
    8000403c:	854a                	mv	a0,s2
    8000403e:	b91fc0ef          	jal	80000bce <acquire>
  while (lk->locked) {
    80004042:	409c                	lw	a5,0(s1)
    80004044:	c799                	beqz	a5,80004052 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80004046:	85ca                	mv	a1,s2
    80004048:	8526                	mv	a0,s1
    8000404a:	ea1fd0ef          	jal	80001eea <sleep>
  while (lk->locked) {
    8000404e:	409c                	lw	a5,0(s1)
    80004050:	fbfd                	bnez	a5,80004046 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80004052:	4785                	li	a5,1
    80004054:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004056:	879fd0ef          	jal	800018ce <myproc>
    8000405a:	591c                	lw	a5,48(a0)
    8000405c:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    8000405e:	854a                	mv	a0,s2
    80004060:	c07fc0ef          	jal	80000c66 <release>
}
    80004064:	60e2                	ld	ra,24(sp)
    80004066:	6442                	ld	s0,16(sp)
    80004068:	64a2                	ld	s1,8(sp)
    8000406a:	6902                	ld	s2,0(sp)
    8000406c:	6105                	addi	sp,sp,32
    8000406e:	8082                	ret

0000000080004070 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80004070:	1101                	addi	sp,sp,-32
    80004072:	ec06                	sd	ra,24(sp)
    80004074:	e822                	sd	s0,16(sp)
    80004076:	e426                	sd	s1,8(sp)
    80004078:	e04a                	sd	s2,0(sp)
    8000407a:	1000                	addi	s0,sp,32
    8000407c:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000407e:	00850913          	addi	s2,a0,8
    80004082:	854a                	mv	a0,s2
    80004084:	b4bfc0ef          	jal	80000bce <acquire>
  lk->locked = 0;
    80004088:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000408c:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80004090:	8526                	mv	a0,s1
    80004092:	ea5fd0ef          	jal	80001f36 <wakeup>
  release(&lk->lk);
    80004096:	854a                	mv	a0,s2
    80004098:	bcffc0ef          	jal	80000c66 <release>
}
    8000409c:	60e2                	ld	ra,24(sp)
    8000409e:	6442                	ld	s0,16(sp)
    800040a0:	64a2                	ld	s1,8(sp)
    800040a2:	6902                	ld	s2,0(sp)
    800040a4:	6105                	addi	sp,sp,32
    800040a6:	8082                	ret

00000000800040a8 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800040a8:	7179                	addi	sp,sp,-48
    800040aa:	f406                	sd	ra,40(sp)
    800040ac:	f022                	sd	s0,32(sp)
    800040ae:	ec26                	sd	s1,24(sp)
    800040b0:	e84a                	sd	s2,16(sp)
    800040b2:	1800                	addi	s0,sp,48
    800040b4:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    800040b6:	00850913          	addi	s2,a0,8
    800040ba:	854a                	mv	a0,s2
    800040bc:	b13fc0ef          	jal	80000bce <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800040c0:	409c                	lw	a5,0(s1)
    800040c2:	ef81                	bnez	a5,800040da <holdingsleep+0x32>
    800040c4:	4481                	li	s1,0
  release(&lk->lk);
    800040c6:	854a                	mv	a0,s2
    800040c8:	b9ffc0ef          	jal	80000c66 <release>
  return r;
}
    800040cc:	8526                	mv	a0,s1
    800040ce:	70a2                	ld	ra,40(sp)
    800040d0:	7402                	ld	s0,32(sp)
    800040d2:	64e2                	ld	s1,24(sp)
    800040d4:	6942                	ld	s2,16(sp)
    800040d6:	6145                	addi	sp,sp,48
    800040d8:	8082                	ret
    800040da:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800040dc:	0284a983          	lw	s3,40(s1)
    800040e0:	feefd0ef          	jal	800018ce <myproc>
    800040e4:	5904                	lw	s1,48(a0)
    800040e6:	413484b3          	sub	s1,s1,s3
    800040ea:	0014b493          	seqz	s1,s1
    800040ee:	69a2                	ld	s3,8(sp)
    800040f0:	bfd9                	j	800040c6 <holdingsleep+0x1e>

00000000800040f2 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800040f2:	1141                	addi	sp,sp,-16
    800040f4:	e406                	sd	ra,8(sp)
    800040f6:	e022                	sd	s0,0(sp)
    800040f8:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800040fa:	00003597          	auipc	a1,0x3
    800040fe:	47e58593          	addi	a1,a1,1150 # 80007578 <etext+0x578>
    80004102:	0001e517          	auipc	a0,0x1e
    80004106:	7ae50513          	addi	a0,a0,1966 # 800228b0 <ftable>
    8000410a:	a45fc0ef          	jal	80000b4e <initlock>
}
    8000410e:	60a2                	ld	ra,8(sp)
    80004110:	6402                	ld	s0,0(sp)
    80004112:	0141                	addi	sp,sp,16
    80004114:	8082                	ret

0000000080004116 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80004116:	1101                	addi	sp,sp,-32
    80004118:	ec06                	sd	ra,24(sp)
    8000411a:	e822                	sd	s0,16(sp)
    8000411c:	e426                	sd	s1,8(sp)
    8000411e:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004120:	0001e517          	auipc	a0,0x1e
    80004124:	79050513          	addi	a0,a0,1936 # 800228b0 <ftable>
    80004128:	aa7fc0ef          	jal	80000bce <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    8000412c:	0001e497          	auipc	s1,0x1e
    80004130:	79c48493          	addi	s1,s1,1948 # 800228c8 <ftable+0x18>
    80004134:	0001f717          	auipc	a4,0x1f
    80004138:	73470713          	addi	a4,a4,1844 # 80023868 <disk>
    if(f->ref == 0){
    8000413c:	40dc                	lw	a5,4(s1)
    8000413e:	cf89                	beqz	a5,80004158 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004140:	02848493          	addi	s1,s1,40
    80004144:	fee49ce3          	bne	s1,a4,8000413c <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004148:	0001e517          	auipc	a0,0x1e
    8000414c:	76850513          	addi	a0,a0,1896 # 800228b0 <ftable>
    80004150:	b17fc0ef          	jal	80000c66 <release>
  return 0;
    80004154:	4481                	li	s1,0
    80004156:	a809                	j	80004168 <filealloc+0x52>
      f->ref = 1;
    80004158:	4785                	li	a5,1
    8000415a:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    8000415c:	0001e517          	auipc	a0,0x1e
    80004160:	75450513          	addi	a0,a0,1876 # 800228b0 <ftable>
    80004164:	b03fc0ef          	jal	80000c66 <release>
}
    80004168:	8526                	mv	a0,s1
    8000416a:	60e2                	ld	ra,24(sp)
    8000416c:	6442                	ld	s0,16(sp)
    8000416e:	64a2                	ld	s1,8(sp)
    80004170:	6105                	addi	sp,sp,32
    80004172:	8082                	ret

0000000080004174 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80004174:	1101                	addi	sp,sp,-32
    80004176:	ec06                	sd	ra,24(sp)
    80004178:	e822                	sd	s0,16(sp)
    8000417a:	e426                	sd	s1,8(sp)
    8000417c:	1000                	addi	s0,sp,32
    8000417e:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004180:	0001e517          	auipc	a0,0x1e
    80004184:	73050513          	addi	a0,a0,1840 # 800228b0 <ftable>
    80004188:	a47fc0ef          	jal	80000bce <acquire>
  if(f->ref < 1)
    8000418c:	40dc                	lw	a5,4(s1)
    8000418e:	02f05063          	blez	a5,800041ae <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004192:	2785                	addiw	a5,a5,1
    80004194:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004196:	0001e517          	auipc	a0,0x1e
    8000419a:	71a50513          	addi	a0,a0,1818 # 800228b0 <ftable>
    8000419e:	ac9fc0ef          	jal	80000c66 <release>
  return f;
}
    800041a2:	8526                	mv	a0,s1
    800041a4:	60e2                	ld	ra,24(sp)
    800041a6:	6442                	ld	s0,16(sp)
    800041a8:	64a2                	ld	s1,8(sp)
    800041aa:	6105                	addi	sp,sp,32
    800041ac:	8082                	ret
    panic("filedup");
    800041ae:	00003517          	auipc	a0,0x3
    800041b2:	3d250513          	addi	a0,a0,978 # 80007580 <etext+0x580>
    800041b6:	e2afc0ef          	jal	800007e0 <panic>

00000000800041ba <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800041ba:	7139                	addi	sp,sp,-64
    800041bc:	fc06                	sd	ra,56(sp)
    800041be:	f822                	sd	s0,48(sp)
    800041c0:	f426                	sd	s1,40(sp)
    800041c2:	0080                	addi	s0,sp,64
    800041c4:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800041c6:	0001e517          	auipc	a0,0x1e
    800041ca:	6ea50513          	addi	a0,a0,1770 # 800228b0 <ftable>
    800041ce:	a01fc0ef          	jal	80000bce <acquire>
  if(f->ref < 1)
    800041d2:	40dc                	lw	a5,4(s1)
    800041d4:	04f05a63          	blez	a5,80004228 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    800041d8:	37fd                	addiw	a5,a5,-1
    800041da:	0007871b          	sext.w	a4,a5
    800041de:	c0dc                	sw	a5,4(s1)
    800041e0:	04e04e63          	bgtz	a4,8000423c <fileclose+0x82>
    800041e4:	f04a                	sd	s2,32(sp)
    800041e6:	ec4e                	sd	s3,24(sp)
    800041e8:	e852                	sd	s4,16(sp)
    800041ea:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800041ec:	0004a903          	lw	s2,0(s1)
    800041f0:	0094ca83          	lbu	s5,9(s1)
    800041f4:	0104ba03          	ld	s4,16(s1)
    800041f8:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    800041fc:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004200:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004204:	0001e517          	auipc	a0,0x1e
    80004208:	6ac50513          	addi	a0,a0,1708 # 800228b0 <ftable>
    8000420c:	a5bfc0ef          	jal	80000c66 <release>

  if(ff.type == FD_PIPE){
    80004210:	4785                	li	a5,1
    80004212:	04f90063          	beq	s2,a5,80004252 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004216:	3979                	addiw	s2,s2,-2
    80004218:	4785                	li	a5,1
    8000421a:	0527f563          	bgeu	a5,s2,80004264 <fileclose+0xaa>
    8000421e:	7902                	ld	s2,32(sp)
    80004220:	69e2                	ld	s3,24(sp)
    80004222:	6a42                	ld	s4,16(sp)
    80004224:	6aa2                	ld	s5,8(sp)
    80004226:	a00d                	j	80004248 <fileclose+0x8e>
    80004228:	f04a                	sd	s2,32(sp)
    8000422a:	ec4e                	sd	s3,24(sp)
    8000422c:	e852                	sd	s4,16(sp)
    8000422e:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004230:	00003517          	auipc	a0,0x3
    80004234:	35850513          	addi	a0,a0,856 # 80007588 <etext+0x588>
    80004238:	da8fc0ef          	jal	800007e0 <panic>
    release(&ftable.lock);
    8000423c:	0001e517          	auipc	a0,0x1e
    80004240:	67450513          	addi	a0,a0,1652 # 800228b0 <ftable>
    80004244:	a23fc0ef          	jal	80000c66 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80004248:	70e2                	ld	ra,56(sp)
    8000424a:	7442                	ld	s0,48(sp)
    8000424c:	74a2                	ld	s1,40(sp)
    8000424e:	6121                	addi	sp,sp,64
    80004250:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004252:	85d6                	mv	a1,s5
    80004254:	8552                	mv	a0,s4
    80004256:	336000ef          	jal	8000458c <pipeclose>
    8000425a:	7902                	ld	s2,32(sp)
    8000425c:	69e2                	ld	s3,24(sp)
    8000425e:	6a42                	ld	s4,16(sp)
    80004260:	6aa2                	ld	s5,8(sp)
    80004262:	b7dd                	j	80004248 <fileclose+0x8e>
    begin_op();
    80004264:	b4bff0ef          	jal	80003dae <begin_op>
    iput(ff.ip);
    80004268:	854e                	mv	a0,s3
    8000426a:	adcff0ef          	jal	80003546 <iput>
    end_op();
    8000426e:	babff0ef          	jal	80003e18 <end_op>
    80004272:	7902                	ld	s2,32(sp)
    80004274:	69e2                	ld	s3,24(sp)
    80004276:	6a42                	ld	s4,16(sp)
    80004278:	6aa2                	ld	s5,8(sp)
    8000427a:	b7f9                	j	80004248 <fileclose+0x8e>

000000008000427c <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    8000427c:	715d                	addi	sp,sp,-80
    8000427e:	e486                	sd	ra,72(sp)
    80004280:	e0a2                	sd	s0,64(sp)
    80004282:	fc26                	sd	s1,56(sp)
    80004284:	f44e                	sd	s3,40(sp)
    80004286:	0880                	addi	s0,sp,80
    80004288:	84aa                	mv	s1,a0
    8000428a:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    8000428c:	e42fd0ef          	jal	800018ce <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004290:	409c                	lw	a5,0(s1)
    80004292:	37f9                	addiw	a5,a5,-2
    80004294:	4705                	li	a4,1
    80004296:	04f76063          	bltu	a4,a5,800042d6 <filestat+0x5a>
    8000429a:	f84a                	sd	s2,48(sp)
    8000429c:	892a                	mv	s2,a0
    ilock(f->ip);
    8000429e:	6c88                	ld	a0,24(s1)
    800042a0:	924ff0ef          	jal	800033c4 <ilock>
    stati(f->ip, &st);
    800042a4:	fb840593          	addi	a1,s0,-72
    800042a8:	6c88                	ld	a0,24(s1)
    800042aa:	c80ff0ef          	jal	8000372a <stati>
    iunlock(f->ip);
    800042ae:	6c88                	ld	a0,24(s1)
    800042b0:	9c2ff0ef          	jal	80003472 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800042b4:	46e1                	li	a3,24
    800042b6:	fb840613          	addi	a2,s0,-72
    800042ba:	85ce                	mv	a1,s3
    800042bc:	05093503          	ld	a0,80(s2)
    800042c0:	b22fd0ef          	jal	800015e2 <copyout>
    800042c4:	41f5551b          	sraiw	a0,a0,0x1f
    800042c8:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800042ca:	60a6                	ld	ra,72(sp)
    800042cc:	6406                	ld	s0,64(sp)
    800042ce:	74e2                	ld	s1,56(sp)
    800042d0:	79a2                	ld	s3,40(sp)
    800042d2:	6161                	addi	sp,sp,80
    800042d4:	8082                	ret
  return -1;
    800042d6:	557d                	li	a0,-1
    800042d8:	bfcd                	j	800042ca <filestat+0x4e>

00000000800042da <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800042da:	7179                	addi	sp,sp,-48
    800042dc:	f406                	sd	ra,40(sp)
    800042de:	f022                	sd	s0,32(sp)
    800042e0:	e84a                	sd	s2,16(sp)
    800042e2:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800042e4:	00854783          	lbu	a5,8(a0)
    800042e8:	cfd1                	beqz	a5,80004384 <fileread+0xaa>
    800042ea:	ec26                	sd	s1,24(sp)
    800042ec:	e44e                	sd	s3,8(sp)
    800042ee:	84aa                	mv	s1,a0
    800042f0:	89ae                	mv	s3,a1
    800042f2:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    800042f4:	411c                	lw	a5,0(a0)
    800042f6:	4705                	li	a4,1
    800042f8:	04e78363          	beq	a5,a4,8000433e <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800042fc:	470d                	li	a4,3
    800042fe:	04e78763          	beq	a5,a4,8000434c <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004302:	4709                	li	a4,2
    80004304:	06e79a63          	bne	a5,a4,80004378 <fileread+0x9e>
    ilock(f->ip);
    80004308:	6d08                	ld	a0,24(a0)
    8000430a:	8baff0ef          	jal	800033c4 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000430e:	874a                	mv	a4,s2
    80004310:	5094                	lw	a3,32(s1)
    80004312:	864e                	mv	a2,s3
    80004314:	4585                	li	a1,1
    80004316:	6c88                	ld	a0,24(s1)
    80004318:	c3cff0ef          	jal	80003754 <readi>
    8000431c:	892a                	mv	s2,a0
    8000431e:	00a05563          	blez	a0,80004328 <fileread+0x4e>
      f->off += r;
    80004322:	509c                	lw	a5,32(s1)
    80004324:	9fa9                	addw	a5,a5,a0
    80004326:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004328:	6c88                	ld	a0,24(s1)
    8000432a:	948ff0ef          	jal	80003472 <iunlock>
    8000432e:	64e2                	ld	s1,24(sp)
    80004330:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004332:	854a                	mv	a0,s2
    80004334:	70a2                	ld	ra,40(sp)
    80004336:	7402                	ld	s0,32(sp)
    80004338:	6942                	ld	s2,16(sp)
    8000433a:	6145                	addi	sp,sp,48
    8000433c:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000433e:	6908                	ld	a0,16(a0)
    80004340:	388000ef          	jal	800046c8 <piperead>
    80004344:	892a                	mv	s2,a0
    80004346:	64e2                	ld	s1,24(sp)
    80004348:	69a2                	ld	s3,8(sp)
    8000434a:	b7e5                	j	80004332 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    8000434c:	02451783          	lh	a5,36(a0)
    80004350:	03079693          	slli	a3,a5,0x30
    80004354:	92c1                	srli	a3,a3,0x30
    80004356:	4725                	li	a4,9
    80004358:	02d76863          	bltu	a4,a3,80004388 <fileread+0xae>
    8000435c:	0792                	slli	a5,a5,0x4
    8000435e:	0001e717          	auipc	a4,0x1e
    80004362:	4b270713          	addi	a4,a4,1202 # 80022810 <devsw>
    80004366:	97ba                	add	a5,a5,a4
    80004368:	639c                	ld	a5,0(a5)
    8000436a:	c39d                	beqz	a5,80004390 <fileread+0xb6>
    r = devsw[f->major].read(1, addr, n);
    8000436c:	4505                	li	a0,1
    8000436e:	9782                	jalr	a5
    80004370:	892a                	mv	s2,a0
    80004372:	64e2                	ld	s1,24(sp)
    80004374:	69a2                	ld	s3,8(sp)
    80004376:	bf75                	j	80004332 <fileread+0x58>
    panic("fileread");
    80004378:	00003517          	auipc	a0,0x3
    8000437c:	22050513          	addi	a0,a0,544 # 80007598 <etext+0x598>
    80004380:	c60fc0ef          	jal	800007e0 <panic>
    return -1;
    80004384:	597d                	li	s2,-1
    80004386:	b775                	j	80004332 <fileread+0x58>
      return -1;
    80004388:	597d                	li	s2,-1
    8000438a:	64e2                	ld	s1,24(sp)
    8000438c:	69a2                	ld	s3,8(sp)
    8000438e:	b755                	j	80004332 <fileread+0x58>
    80004390:	597d                	li	s2,-1
    80004392:	64e2                	ld	s1,24(sp)
    80004394:	69a2                	ld	s3,8(sp)
    80004396:	bf71                	j	80004332 <fileread+0x58>

0000000080004398 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80004398:	00954783          	lbu	a5,9(a0)
    8000439c:	10078b63          	beqz	a5,800044b2 <filewrite+0x11a>
{
    800043a0:	715d                	addi	sp,sp,-80
    800043a2:	e486                	sd	ra,72(sp)
    800043a4:	e0a2                	sd	s0,64(sp)
    800043a6:	f84a                	sd	s2,48(sp)
    800043a8:	f052                	sd	s4,32(sp)
    800043aa:	e85a                	sd	s6,16(sp)
    800043ac:	0880                	addi	s0,sp,80
    800043ae:	892a                	mv	s2,a0
    800043b0:	8b2e                	mv	s6,a1
    800043b2:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800043b4:	411c                	lw	a5,0(a0)
    800043b6:	4705                	li	a4,1
    800043b8:	02e78763          	beq	a5,a4,800043e6 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800043bc:	470d                	li	a4,3
    800043be:	02e78863          	beq	a5,a4,800043ee <filewrite+0x56>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800043c2:	4709                	li	a4,2
    800043c4:	0ce79c63          	bne	a5,a4,8000449c <filewrite+0x104>
    800043c8:	f44e                	sd	s3,40(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800043ca:	0ac05863          	blez	a2,8000447a <filewrite+0xe2>
    800043ce:	fc26                	sd	s1,56(sp)
    800043d0:	ec56                	sd	s5,24(sp)
    800043d2:	e45e                	sd	s7,8(sp)
    800043d4:	e062                	sd	s8,0(sp)
    int i = 0;
    800043d6:	4981                	li	s3,0
      int n1 = n - i;
      if(n1 > max)
    800043d8:	6b85                	lui	s7,0x1
    800043da:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800043de:	6c05                	lui	s8,0x1
    800043e0:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    800043e4:	a8b5                	j	80004460 <filewrite+0xc8>
    ret = pipewrite(f->pipe, addr, n);
    800043e6:	6908                	ld	a0,16(a0)
    800043e8:	1fc000ef          	jal	800045e4 <pipewrite>
    800043ec:	a04d                	j	8000448e <filewrite+0xf6>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800043ee:	02451783          	lh	a5,36(a0)
    800043f2:	03079693          	slli	a3,a5,0x30
    800043f6:	92c1                	srli	a3,a3,0x30
    800043f8:	4725                	li	a4,9
    800043fa:	0ad76e63          	bltu	a4,a3,800044b6 <filewrite+0x11e>
    800043fe:	0792                	slli	a5,a5,0x4
    80004400:	0001e717          	auipc	a4,0x1e
    80004404:	41070713          	addi	a4,a4,1040 # 80022810 <devsw>
    80004408:	97ba                	add	a5,a5,a4
    8000440a:	679c                	ld	a5,8(a5)
    8000440c:	c7dd                	beqz	a5,800044ba <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    8000440e:	4505                	li	a0,1
    80004410:	9782                	jalr	a5
    80004412:	a8b5                	j	8000448e <filewrite+0xf6>
      if(n1 > max)
    80004414:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    80004418:	997ff0ef          	jal	80003dae <begin_op>
      ilock(f->ip);
    8000441c:	01893503          	ld	a0,24(s2)
    80004420:	fa5fe0ef          	jal	800033c4 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004424:	8756                	mv	a4,s5
    80004426:	02092683          	lw	a3,32(s2)
    8000442a:	01698633          	add	a2,s3,s6
    8000442e:	4585                	li	a1,1
    80004430:	01893503          	ld	a0,24(s2)
    80004434:	c1cff0ef          	jal	80003850 <writei>
    80004438:	84aa                	mv	s1,a0
    8000443a:	00a05763          	blez	a0,80004448 <filewrite+0xb0>
        f->off += r;
    8000443e:	02092783          	lw	a5,32(s2)
    80004442:	9fa9                	addw	a5,a5,a0
    80004444:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004448:	01893503          	ld	a0,24(s2)
    8000444c:	826ff0ef          	jal	80003472 <iunlock>
      end_op();
    80004450:	9c9ff0ef          	jal	80003e18 <end_op>

      if(r != n1){
    80004454:	029a9563          	bne	s5,s1,8000447e <filewrite+0xe6>
        // error from writei
        break;
      }
      i += r;
    80004458:	013489bb          	addw	s3,s1,s3
    while(i < n){
    8000445c:	0149da63          	bge	s3,s4,80004470 <filewrite+0xd8>
      int n1 = n - i;
    80004460:	413a04bb          	subw	s1,s4,s3
      if(n1 > max)
    80004464:	0004879b          	sext.w	a5,s1
    80004468:	fafbd6e3          	bge	s7,a5,80004414 <filewrite+0x7c>
    8000446c:	84e2                	mv	s1,s8
    8000446e:	b75d                	j	80004414 <filewrite+0x7c>
    80004470:	74e2                	ld	s1,56(sp)
    80004472:	6ae2                	ld	s5,24(sp)
    80004474:	6ba2                	ld	s7,8(sp)
    80004476:	6c02                	ld	s8,0(sp)
    80004478:	a039                	j	80004486 <filewrite+0xee>
    int i = 0;
    8000447a:	4981                	li	s3,0
    8000447c:	a029                	j	80004486 <filewrite+0xee>
    8000447e:	74e2                	ld	s1,56(sp)
    80004480:	6ae2                	ld	s5,24(sp)
    80004482:	6ba2                	ld	s7,8(sp)
    80004484:	6c02                	ld	s8,0(sp)
    }
    ret = (i == n ? n : -1);
    80004486:	033a1c63          	bne	s4,s3,800044be <filewrite+0x126>
    8000448a:	8552                	mv	a0,s4
    8000448c:	79a2                	ld	s3,40(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000448e:	60a6                	ld	ra,72(sp)
    80004490:	6406                	ld	s0,64(sp)
    80004492:	7942                	ld	s2,48(sp)
    80004494:	7a02                	ld	s4,32(sp)
    80004496:	6b42                	ld	s6,16(sp)
    80004498:	6161                	addi	sp,sp,80
    8000449a:	8082                	ret
    8000449c:	fc26                	sd	s1,56(sp)
    8000449e:	f44e                	sd	s3,40(sp)
    800044a0:	ec56                	sd	s5,24(sp)
    800044a2:	e45e                	sd	s7,8(sp)
    800044a4:	e062                	sd	s8,0(sp)
    panic("filewrite");
    800044a6:	00003517          	auipc	a0,0x3
    800044aa:	10250513          	addi	a0,a0,258 # 800075a8 <etext+0x5a8>
    800044ae:	b32fc0ef          	jal	800007e0 <panic>
    return -1;
    800044b2:	557d                	li	a0,-1
}
    800044b4:	8082                	ret
      return -1;
    800044b6:	557d                	li	a0,-1
    800044b8:	bfd9                	j	8000448e <filewrite+0xf6>
    800044ba:	557d                	li	a0,-1
    800044bc:	bfc9                	j	8000448e <filewrite+0xf6>
    ret = (i == n ? n : -1);
    800044be:	557d                	li	a0,-1
    800044c0:	79a2                	ld	s3,40(sp)
    800044c2:	b7f1                	j	8000448e <filewrite+0xf6>

00000000800044c4 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800044c4:	7179                	addi	sp,sp,-48
    800044c6:	f406                	sd	ra,40(sp)
    800044c8:	f022                	sd	s0,32(sp)
    800044ca:	ec26                	sd	s1,24(sp)
    800044cc:	e052                	sd	s4,0(sp)
    800044ce:	1800                	addi	s0,sp,48
    800044d0:	84aa                	mv	s1,a0
    800044d2:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800044d4:	0005b023          	sd	zero,0(a1)
    800044d8:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800044dc:	c3bff0ef          	jal	80004116 <filealloc>
    800044e0:	e088                	sd	a0,0(s1)
    800044e2:	c549                	beqz	a0,8000456c <pipealloc+0xa8>
    800044e4:	c33ff0ef          	jal	80004116 <filealloc>
    800044e8:	00aa3023          	sd	a0,0(s4)
    800044ec:	cd25                	beqz	a0,80004564 <pipealloc+0xa0>
    800044ee:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800044f0:	e0efc0ef          	jal	80000afe <kalloc>
    800044f4:	892a                	mv	s2,a0
    800044f6:	c12d                	beqz	a0,80004558 <pipealloc+0x94>
    800044f8:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800044fa:	4985                	li	s3,1
    800044fc:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004500:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004504:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004508:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    8000450c:	00003597          	auipc	a1,0x3
    80004510:	0ac58593          	addi	a1,a1,172 # 800075b8 <etext+0x5b8>
    80004514:	e3afc0ef          	jal	80000b4e <initlock>
  (*f0)->type = FD_PIPE;
    80004518:	609c                	ld	a5,0(s1)
    8000451a:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    8000451e:	609c                	ld	a5,0(s1)
    80004520:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004524:	609c                	ld	a5,0(s1)
    80004526:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    8000452a:	609c                	ld	a5,0(s1)
    8000452c:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004530:	000a3783          	ld	a5,0(s4)
    80004534:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004538:	000a3783          	ld	a5,0(s4)
    8000453c:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004540:	000a3783          	ld	a5,0(s4)
    80004544:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004548:	000a3783          	ld	a5,0(s4)
    8000454c:	0127b823          	sd	s2,16(a5)
  return 0;
    80004550:	4501                	li	a0,0
    80004552:	6942                	ld	s2,16(sp)
    80004554:	69a2                	ld	s3,8(sp)
    80004556:	a01d                	j	8000457c <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004558:	6088                	ld	a0,0(s1)
    8000455a:	c119                	beqz	a0,80004560 <pipealloc+0x9c>
    8000455c:	6942                	ld	s2,16(sp)
    8000455e:	a029                	j	80004568 <pipealloc+0xa4>
    80004560:	6942                	ld	s2,16(sp)
    80004562:	a029                	j	8000456c <pipealloc+0xa8>
    80004564:	6088                	ld	a0,0(s1)
    80004566:	c10d                	beqz	a0,80004588 <pipealloc+0xc4>
    fileclose(*f0);
    80004568:	c53ff0ef          	jal	800041ba <fileclose>
  if(*f1)
    8000456c:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004570:	557d                	li	a0,-1
  if(*f1)
    80004572:	c789                	beqz	a5,8000457c <pipealloc+0xb8>
    fileclose(*f1);
    80004574:	853e                	mv	a0,a5
    80004576:	c45ff0ef          	jal	800041ba <fileclose>
  return -1;
    8000457a:	557d                	li	a0,-1
}
    8000457c:	70a2                	ld	ra,40(sp)
    8000457e:	7402                	ld	s0,32(sp)
    80004580:	64e2                	ld	s1,24(sp)
    80004582:	6a02                	ld	s4,0(sp)
    80004584:	6145                	addi	sp,sp,48
    80004586:	8082                	ret
  return -1;
    80004588:	557d                	li	a0,-1
    8000458a:	bfcd                	j	8000457c <pipealloc+0xb8>

000000008000458c <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    8000458c:	1101                	addi	sp,sp,-32
    8000458e:	ec06                	sd	ra,24(sp)
    80004590:	e822                	sd	s0,16(sp)
    80004592:	e426                	sd	s1,8(sp)
    80004594:	e04a                	sd	s2,0(sp)
    80004596:	1000                	addi	s0,sp,32
    80004598:	84aa                	mv	s1,a0
    8000459a:	892e                	mv	s2,a1
  acquire(&pi->lock);
    8000459c:	e32fc0ef          	jal	80000bce <acquire>
  if(writable){
    800045a0:	02090763          	beqz	s2,800045ce <pipeclose+0x42>
    pi->writeopen = 0;
    800045a4:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800045a8:	21848513          	addi	a0,s1,536
    800045ac:	98bfd0ef          	jal	80001f36 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800045b0:	2204b783          	ld	a5,544(s1)
    800045b4:	e785                	bnez	a5,800045dc <pipeclose+0x50>
    release(&pi->lock);
    800045b6:	8526                	mv	a0,s1
    800045b8:	eaefc0ef          	jal	80000c66 <release>
    kfree((char*)pi);
    800045bc:	8526                	mv	a0,s1
    800045be:	c5efc0ef          	jal	80000a1c <kfree>
  } else
    release(&pi->lock);
}
    800045c2:	60e2                	ld	ra,24(sp)
    800045c4:	6442                	ld	s0,16(sp)
    800045c6:	64a2                	ld	s1,8(sp)
    800045c8:	6902                	ld	s2,0(sp)
    800045ca:	6105                	addi	sp,sp,32
    800045cc:	8082                	ret
    pi->readopen = 0;
    800045ce:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800045d2:	21c48513          	addi	a0,s1,540
    800045d6:	961fd0ef          	jal	80001f36 <wakeup>
    800045da:	bfd9                	j	800045b0 <pipeclose+0x24>
    release(&pi->lock);
    800045dc:	8526                	mv	a0,s1
    800045de:	e88fc0ef          	jal	80000c66 <release>
}
    800045e2:	b7c5                	j	800045c2 <pipeclose+0x36>

00000000800045e4 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800045e4:	711d                	addi	sp,sp,-96
    800045e6:	ec86                	sd	ra,88(sp)
    800045e8:	e8a2                	sd	s0,80(sp)
    800045ea:	e4a6                	sd	s1,72(sp)
    800045ec:	e0ca                	sd	s2,64(sp)
    800045ee:	fc4e                	sd	s3,56(sp)
    800045f0:	f852                	sd	s4,48(sp)
    800045f2:	f456                	sd	s5,40(sp)
    800045f4:	1080                	addi	s0,sp,96
    800045f6:	84aa                	mv	s1,a0
    800045f8:	8aae                	mv	s5,a1
    800045fa:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800045fc:	ad2fd0ef          	jal	800018ce <myproc>
    80004600:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004602:	8526                	mv	a0,s1
    80004604:	dcafc0ef          	jal	80000bce <acquire>
  while(i < n){
    80004608:	0b405a63          	blez	s4,800046bc <pipewrite+0xd8>
    8000460c:	f05a                	sd	s6,32(sp)
    8000460e:	ec5e                	sd	s7,24(sp)
    80004610:	e862                	sd	s8,16(sp)
  int i = 0;
    80004612:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004614:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004616:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    8000461a:	21c48b93          	addi	s7,s1,540
    8000461e:	a81d                	j	80004654 <pipewrite+0x70>
      release(&pi->lock);
    80004620:	8526                	mv	a0,s1
    80004622:	e44fc0ef          	jal	80000c66 <release>
      return -1;
    80004626:	597d                	li	s2,-1
    80004628:	7b02                	ld	s6,32(sp)
    8000462a:	6be2                	ld	s7,24(sp)
    8000462c:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000462e:	854a                	mv	a0,s2
    80004630:	60e6                	ld	ra,88(sp)
    80004632:	6446                	ld	s0,80(sp)
    80004634:	64a6                	ld	s1,72(sp)
    80004636:	6906                	ld	s2,64(sp)
    80004638:	79e2                	ld	s3,56(sp)
    8000463a:	7a42                	ld	s4,48(sp)
    8000463c:	7aa2                	ld	s5,40(sp)
    8000463e:	6125                	addi	sp,sp,96
    80004640:	8082                	ret
      wakeup(&pi->nread);
    80004642:	8562                	mv	a0,s8
    80004644:	8f3fd0ef          	jal	80001f36 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004648:	85a6                	mv	a1,s1
    8000464a:	855e                	mv	a0,s7
    8000464c:	89ffd0ef          	jal	80001eea <sleep>
  while(i < n){
    80004650:	05495b63          	bge	s2,s4,800046a6 <pipewrite+0xc2>
    if(pi->readopen == 0 || killed(pr)){
    80004654:	2204a783          	lw	a5,544(s1)
    80004658:	d7e1                	beqz	a5,80004620 <pipewrite+0x3c>
    8000465a:	854e                	mv	a0,s3
    8000465c:	ac7fd0ef          	jal	80002122 <killed>
    80004660:	f161                	bnez	a0,80004620 <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004662:	2184a783          	lw	a5,536(s1)
    80004666:	21c4a703          	lw	a4,540(s1)
    8000466a:	2007879b          	addiw	a5,a5,512
    8000466e:	fcf70ae3          	beq	a4,a5,80004642 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004672:	4685                	li	a3,1
    80004674:	01590633          	add	a2,s2,s5
    80004678:	faf40593          	addi	a1,s0,-81
    8000467c:	0509b503          	ld	a0,80(s3)
    80004680:	846fd0ef          	jal	800016c6 <copyin>
    80004684:	03650e63          	beq	a0,s6,800046c0 <pipewrite+0xdc>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004688:	21c4a783          	lw	a5,540(s1)
    8000468c:	0017871b          	addiw	a4,a5,1
    80004690:	20e4ae23          	sw	a4,540(s1)
    80004694:	1ff7f793          	andi	a5,a5,511
    80004698:	97a6                	add	a5,a5,s1
    8000469a:	faf44703          	lbu	a4,-81(s0)
    8000469e:	00e78c23          	sb	a4,24(a5)
      i++;
    800046a2:	2905                	addiw	s2,s2,1
    800046a4:	b775                	j	80004650 <pipewrite+0x6c>
    800046a6:	7b02                	ld	s6,32(sp)
    800046a8:	6be2                	ld	s7,24(sp)
    800046aa:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    800046ac:	21848513          	addi	a0,s1,536
    800046b0:	887fd0ef          	jal	80001f36 <wakeup>
  release(&pi->lock);
    800046b4:	8526                	mv	a0,s1
    800046b6:	db0fc0ef          	jal	80000c66 <release>
  return i;
    800046ba:	bf95                	j	8000462e <pipewrite+0x4a>
  int i = 0;
    800046bc:	4901                	li	s2,0
    800046be:	b7fd                	j	800046ac <pipewrite+0xc8>
    800046c0:	7b02                	ld	s6,32(sp)
    800046c2:	6be2                	ld	s7,24(sp)
    800046c4:	6c42                	ld	s8,16(sp)
    800046c6:	b7dd                	j	800046ac <pipewrite+0xc8>

00000000800046c8 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800046c8:	715d                	addi	sp,sp,-80
    800046ca:	e486                	sd	ra,72(sp)
    800046cc:	e0a2                	sd	s0,64(sp)
    800046ce:	fc26                	sd	s1,56(sp)
    800046d0:	f84a                	sd	s2,48(sp)
    800046d2:	f44e                	sd	s3,40(sp)
    800046d4:	f052                	sd	s4,32(sp)
    800046d6:	ec56                	sd	s5,24(sp)
    800046d8:	0880                	addi	s0,sp,80
    800046da:	84aa                	mv	s1,a0
    800046dc:	892e                	mv	s2,a1
    800046de:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800046e0:	9eefd0ef          	jal	800018ce <myproc>
    800046e4:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800046e6:	8526                	mv	a0,s1
    800046e8:	ce6fc0ef          	jal	80000bce <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800046ec:	2184a703          	lw	a4,536(s1)
    800046f0:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800046f4:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800046f8:	02f71563          	bne	a4,a5,80004722 <piperead+0x5a>
    800046fc:	2244a783          	lw	a5,548(s1)
    80004700:	cb85                	beqz	a5,80004730 <piperead+0x68>
    if(killed(pr)){
    80004702:	8552                	mv	a0,s4
    80004704:	a1ffd0ef          	jal	80002122 <killed>
    80004708:	ed19                	bnez	a0,80004726 <piperead+0x5e>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000470a:	85a6                	mv	a1,s1
    8000470c:	854e                	mv	a0,s3
    8000470e:	fdcfd0ef          	jal	80001eea <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004712:	2184a703          	lw	a4,536(s1)
    80004716:	21c4a783          	lw	a5,540(s1)
    8000471a:	fef701e3          	beq	a4,a5,800046fc <piperead+0x34>
    8000471e:	e85a                	sd	s6,16(sp)
    80004720:	a809                	j	80004732 <piperead+0x6a>
    80004722:	e85a                	sd	s6,16(sp)
    80004724:	a039                	j	80004732 <piperead+0x6a>
      release(&pi->lock);
    80004726:	8526                	mv	a0,s1
    80004728:	d3efc0ef          	jal	80000c66 <release>
      return -1;
    8000472c:	59fd                	li	s3,-1
    8000472e:	a8b9                	j	8000478c <piperead+0xc4>
    80004730:	e85a                	sd	s6,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004732:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004734:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004736:	05505363          	blez	s5,8000477c <piperead+0xb4>
    if(pi->nread == pi->nwrite)
    8000473a:	2184a783          	lw	a5,536(s1)
    8000473e:	21c4a703          	lw	a4,540(s1)
    80004742:	02f70d63          	beq	a4,a5,8000477c <piperead+0xb4>
    ch = pi->data[pi->nread % PIPESIZE];
    80004746:	1ff7f793          	andi	a5,a5,511
    8000474a:	97a6                	add	a5,a5,s1
    8000474c:	0187c783          	lbu	a5,24(a5)
    80004750:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004754:	4685                	li	a3,1
    80004756:	fbf40613          	addi	a2,s0,-65
    8000475a:	85ca                	mv	a1,s2
    8000475c:	050a3503          	ld	a0,80(s4)
    80004760:	e83fc0ef          	jal	800015e2 <copyout>
    80004764:	03650e63          	beq	a0,s6,800047a0 <piperead+0xd8>
      if(i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004768:	2184a783          	lw	a5,536(s1)
    8000476c:	2785                	addiw	a5,a5,1
    8000476e:	20f4ac23          	sw	a5,536(s1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004772:	2985                	addiw	s3,s3,1
    80004774:	0905                	addi	s2,s2,1
    80004776:	fd3a92e3          	bne	s5,s3,8000473a <piperead+0x72>
    8000477a:	89d6                	mv	s3,s5
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    8000477c:	21c48513          	addi	a0,s1,540
    80004780:	fb6fd0ef          	jal	80001f36 <wakeup>
  release(&pi->lock);
    80004784:	8526                	mv	a0,s1
    80004786:	ce0fc0ef          	jal	80000c66 <release>
    8000478a:	6b42                	ld	s6,16(sp)
  return i;
}
    8000478c:	854e                	mv	a0,s3
    8000478e:	60a6                	ld	ra,72(sp)
    80004790:	6406                	ld	s0,64(sp)
    80004792:	74e2                	ld	s1,56(sp)
    80004794:	7942                	ld	s2,48(sp)
    80004796:	79a2                	ld	s3,40(sp)
    80004798:	7a02                	ld	s4,32(sp)
    8000479a:	6ae2                	ld	s5,24(sp)
    8000479c:	6161                	addi	sp,sp,80
    8000479e:	8082                	ret
      if(i == 0)
    800047a0:	fc099ee3          	bnez	s3,8000477c <piperead+0xb4>
        i = -1;
    800047a4:	89aa                	mv	s3,a0
    800047a6:	bfd9                	j	8000477c <piperead+0xb4>

00000000800047a8 <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    800047a8:	1141                	addi	sp,sp,-16
    800047aa:	e422                	sd	s0,8(sp)
    800047ac:	0800                	addi	s0,sp,16
    800047ae:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    800047b0:	8905                	andi	a0,a0,1
    800047b2:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    800047b4:	8b89                	andi	a5,a5,2
    800047b6:	c399                	beqz	a5,800047bc <flags2perm+0x14>
      perm |= PTE_W;
    800047b8:	00456513          	ori	a0,a0,4
    return perm;
}
    800047bc:	6422                	ld	s0,8(sp)
    800047be:	0141                	addi	sp,sp,16
    800047c0:	8082                	ret

00000000800047c2 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800047c2:	df010113          	addi	sp,sp,-528
    800047c6:	20113423          	sd	ra,520(sp)
    800047ca:	20813023          	sd	s0,512(sp)
    800047ce:	ffa6                	sd	s1,504(sp)
    800047d0:	fbca                	sd	s2,496(sp)
    800047d2:	0c00                	addi	s0,sp,528
    800047d4:	892a                	mv	s2,a0
    800047d6:	dea43c23          	sd	a0,-520(s0)
    800047da:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800047de:	8f0fd0ef          	jal	800018ce <myproc>
    800047e2:	84aa                	mv	s1,a0

  begin_op();
    800047e4:	dcaff0ef          	jal	80003dae <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    800047e8:	854a                	mv	a0,s2
    800047ea:	bf0ff0ef          	jal	80003bda <namei>
    800047ee:	c931                	beqz	a0,80004842 <kexec+0x80>
    800047f0:	f3d2                	sd	s4,480(sp)
    800047f2:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800047f4:	bd1fe0ef          	jal	800033c4 <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800047f8:	04000713          	li	a4,64
    800047fc:	4681                	li	a3,0
    800047fe:	e5040613          	addi	a2,s0,-432
    80004802:	4581                	li	a1,0
    80004804:	8552                	mv	a0,s4
    80004806:	f4ffe0ef          	jal	80003754 <readi>
    8000480a:	04000793          	li	a5,64
    8000480e:	00f51a63          	bne	a0,a5,80004822 <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    80004812:	e5042703          	lw	a4,-432(s0)
    80004816:	464c47b7          	lui	a5,0x464c4
    8000481a:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    8000481e:	02f70663          	beq	a4,a5,8000484a <kexec+0x88>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004822:	8552                	mv	a0,s4
    80004824:	dabfe0ef          	jal	800035ce <iunlockput>
    end_op();
    80004828:	df0ff0ef          	jal	80003e18 <end_op>
  }
  return -1;
    8000482c:	557d                	li	a0,-1
    8000482e:	7a1e                	ld	s4,480(sp)
}
    80004830:	20813083          	ld	ra,520(sp)
    80004834:	20013403          	ld	s0,512(sp)
    80004838:	74fe                	ld	s1,504(sp)
    8000483a:	795e                	ld	s2,496(sp)
    8000483c:	21010113          	addi	sp,sp,528
    80004840:	8082                	ret
    end_op();
    80004842:	dd6ff0ef          	jal	80003e18 <end_op>
    return -1;
    80004846:	557d                	li	a0,-1
    80004848:	b7e5                	j	80004830 <kexec+0x6e>
    8000484a:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    8000484c:	8526                	mv	a0,s1
    8000484e:	986fd0ef          	jal	800019d4 <proc_pagetable>
    80004852:	8b2a                	mv	s6,a0
    80004854:	2c050b63          	beqz	a0,80004b2a <kexec+0x368>
    80004858:	f7ce                	sd	s3,488(sp)
    8000485a:	efd6                	sd	s5,472(sp)
    8000485c:	e7de                	sd	s7,456(sp)
    8000485e:	e3e2                	sd	s8,448(sp)
    80004860:	ff66                	sd	s9,440(sp)
    80004862:	fb6a                	sd	s10,432(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004864:	e7042d03          	lw	s10,-400(s0)
    80004868:	e8845783          	lhu	a5,-376(s0)
    8000486c:	12078963          	beqz	a5,8000499e <kexec+0x1dc>
    80004870:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004872:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004874:	4d81                	li	s11,0
    if(ph.vaddr % PGSIZE != 0)
    80004876:	6c85                	lui	s9,0x1
    80004878:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    8000487c:	def43823          	sd	a5,-528(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80004880:	6a85                	lui	s5,0x1
    80004882:	a085                	j	800048e2 <kexec+0x120>
      panic("loadseg: address should exist");
    80004884:	00003517          	auipc	a0,0x3
    80004888:	d3c50513          	addi	a0,a0,-708 # 800075c0 <etext+0x5c0>
    8000488c:	f55fb0ef          	jal	800007e0 <panic>
    if(sz - i < PGSIZE)
    80004890:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004892:	8726                	mv	a4,s1
    80004894:	012c06bb          	addw	a3,s8,s2
    80004898:	4581                	li	a1,0
    8000489a:	8552                	mv	a0,s4
    8000489c:	eb9fe0ef          	jal	80003754 <readi>
    800048a0:	2501                	sext.w	a0,a0
    800048a2:	24a49a63          	bne	s1,a0,80004af6 <kexec+0x334>
  for(i = 0; i < sz; i += PGSIZE){
    800048a6:	012a893b          	addw	s2,s5,s2
    800048aa:	03397363          	bgeu	s2,s3,800048d0 <kexec+0x10e>
    pa = walkaddr(pagetable, va + i);
    800048ae:	02091593          	slli	a1,s2,0x20
    800048b2:	9181                	srli	a1,a1,0x20
    800048b4:	95de                	add	a1,a1,s7
    800048b6:	855a                	mv	a0,s6
    800048b8:	ef8fc0ef          	jal	80000fb0 <walkaddr>
    800048bc:	862a                	mv	a2,a0
    if(pa == 0)
    800048be:	d179                	beqz	a0,80004884 <kexec+0xc2>
    if(sz - i < PGSIZE)
    800048c0:	412984bb          	subw	s1,s3,s2
    800048c4:	0004879b          	sext.w	a5,s1
    800048c8:	fcfcf4e3          	bgeu	s9,a5,80004890 <kexec+0xce>
    800048cc:	84d6                	mv	s1,s5
    800048ce:	b7c9                	j	80004890 <kexec+0xce>
    sz = sz1;
    800048d0:	e0843903          	ld	s2,-504(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800048d4:	2d85                	addiw	s11,s11,1
    800048d6:	038d0d1b          	addiw	s10,s10,56 # 1038 <_entry-0x7fffefc8>
    800048da:	e8845783          	lhu	a5,-376(s0)
    800048de:	08fdd063          	bge	s11,a5,8000495e <kexec+0x19c>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800048e2:	2d01                	sext.w	s10,s10
    800048e4:	03800713          	li	a4,56
    800048e8:	86ea                	mv	a3,s10
    800048ea:	e1840613          	addi	a2,s0,-488
    800048ee:	4581                	li	a1,0
    800048f0:	8552                	mv	a0,s4
    800048f2:	e63fe0ef          	jal	80003754 <readi>
    800048f6:	03800793          	li	a5,56
    800048fa:	1cf51663          	bne	a0,a5,80004ac6 <kexec+0x304>
    if(ph.type != ELF_PROG_LOAD)
    800048fe:	e1842783          	lw	a5,-488(s0)
    80004902:	4705                	li	a4,1
    80004904:	fce798e3          	bne	a5,a4,800048d4 <kexec+0x112>
    if(ph.memsz < ph.filesz)
    80004908:	e4043483          	ld	s1,-448(s0)
    8000490c:	e3843783          	ld	a5,-456(s0)
    80004910:	1af4ef63          	bltu	s1,a5,80004ace <kexec+0x30c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004914:	e2843783          	ld	a5,-472(s0)
    80004918:	94be                	add	s1,s1,a5
    8000491a:	1af4ee63          	bltu	s1,a5,80004ad6 <kexec+0x314>
    if(ph.vaddr % PGSIZE != 0)
    8000491e:	df043703          	ld	a4,-528(s0)
    80004922:	8ff9                	and	a5,a5,a4
    80004924:	1a079d63          	bnez	a5,80004ade <kexec+0x31c>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004928:	e1c42503          	lw	a0,-484(s0)
    8000492c:	e7dff0ef          	jal	800047a8 <flags2perm>
    80004930:	86aa                	mv	a3,a0
    80004932:	8626                	mv	a2,s1
    80004934:	85ca                	mv	a1,s2
    80004936:	855a                	mv	a0,s6
    80004938:	951fc0ef          	jal	80001288 <uvmalloc>
    8000493c:	e0a43423          	sd	a0,-504(s0)
    80004940:	1a050363          	beqz	a0,80004ae6 <kexec+0x324>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004944:	e2843b83          	ld	s7,-472(s0)
    80004948:	e2042c03          	lw	s8,-480(s0)
    8000494c:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004950:	00098463          	beqz	s3,80004958 <kexec+0x196>
    80004954:	4901                	li	s2,0
    80004956:	bfa1                	j	800048ae <kexec+0xec>
    sz = sz1;
    80004958:	e0843903          	ld	s2,-504(s0)
    8000495c:	bfa5                	j	800048d4 <kexec+0x112>
    8000495e:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004960:	8552                	mv	a0,s4
    80004962:	c6dfe0ef          	jal	800035ce <iunlockput>
  end_op();
    80004966:	cb2ff0ef          	jal	80003e18 <end_op>
  p = myproc();
    8000496a:	f65fc0ef          	jal	800018ce <myproc>
    8000496e:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004970:	04853c83          	ld	s9,72(a0)
  sz = PGROUNDUP(sz);
    80004974:	6985                	lui	s3,0x1
    80004976:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004978:	99ca                	add	s3,s3,s2
    8000497a:	77fd                	lui	a5,0xfffff
    8000497c:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004980:	4691                	li	a3,4
    80004982:	6609                	lui	a2,0x2
    80004984:	964e                	add	a2,a2,s3
    80004986:	85ce                	mv	a1,s3
    80004988:	855a                	mv	a0,s6
    8000498a:	8fffc0ef          	jal	80001288 <uvmalloc>
    8000498e:	892a                	mv	s2,a0
    80004990:	e0a43423          	sd	a0,-504(s0)
    80004994:	e519                	bnez	a0,800049a2 <kexec+0x1e0>
  if(pagetable)
    80004996:	e1343423          	sd	s3,-504(s0)
    8000499a:	4a01                	li	s4,0
    8000499c:	aab1                	j	80004af8 <kexec+0x336>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000499e:	4901                	li	s2,0
    800049a0:	b7c1                	j	80004960 <kexec+0x19e>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800049a2:	75f9                	lui	a1,0xffffe
    800049a4:	95aa                	add	a1,a1,a0
    800049a6:	855a                	mv	a0,s6
    800049a8:	ab7fc0ef          	jal	8000145e <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    800049ac:	7bfd                	lui	s7,0xfffff
    800049ae:	9bca                	add	s7,s7,s2
  for(argc = 0; argv[argc]; argc++) {
    800049b0:	e0043783          	ld	a5,-512(s0)
    800049b4:	6388                	ld	a0,0(a5)
    800049b6:	cd39                	beqz	a0,80004a14 <kexec+0x252>
    800049b8:	e9040993          	addi	s3,s0,-368
    800049bc:	f9040c13          	addi	s8,s0,-112
    800049c0:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    800049c2:	c50fc0ef          	jal	80000e12 <strlen>
    800049c6:	0015079b          	addiw	a5,a0,1
    800049ca:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    800049ce:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    800049d2:	11796e63          	bltu	s2,s7,80004aee <kexec+0x32c>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    800049d6:	e0043d03          	ld	s10,-512(s0)
    800049da:	000d3a03          	ld	s4,0(s10)
    800049de:	8552                	mv	a0,s4
    800049e0:	c32fc0ef          	jal	80000e12 <strlen>
    800049e4:	0015069b          	addiw	a3,a0,1
    800049e8:	8652                	mv	a2,s4
    800049ea:	85ca                	mv	a1,s2
    800049ec:	855a                	mv	a0,s6
    800049ee:	bf5fc0ef          	jal	800015e2 <copyout>
    800049f2:	10054063          	bltz	a0,80004af2 <kexec+0x330>
    ustack[argc] = sp;
    800049f6:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    800049fa:	0485                	addi	s1,s1,1
    800049fc:	008d0793          	addi	a5,s10,8
    80004a00:	e0f43023          	sd	a5,-512(s0)
    80004a04:	008d3503          	ld	a0,8(s10)
    80004a08:	c909                	beqz	a0,80004a1a <kexec+0x258>
    if(argc >= MAXARG)
    80004a0a:	09a1                	addi	s3,s3,8
    80004a0c:	fb899be3          	bne	s3,s8,800049c2 <kexec+0x200>
  ip = 0;
    80004a10:	4a01                	li	s4,0
    80004a12:	a0dd                	j	80004af8 <kexec+0x336>
  sp = sz;
    80004a14:	e0843903          	ld	s2,-504(s0)
  for(argc = 0; argv[argc]; argc++) {
    80004a18:	4481                	li	s1,0
  ustack[argc] = 0;
    80004a1a:	00349793          	slli	a5,s1,0x3
    80004a1e:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffdb5e8>
    80004a22:	97a2                	add	a5,a5,s0
    80004a24:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004a28:	00148693          	addi	a3,s1,1
    80004a2c:	068e                	slli	a3,a3,0x3
    80004a2e:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004a32:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004a36:	e0843983          	ld	s3,-504(s0)
  if(sp < stackbase)
    80004a3a:	f5796ee3          	bltu	s2,s7,80004996 <kexec+0x1d4>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004a3e:	e9040613          	addi	a2,s0,-368
    80004a42:	85ca                	mv	a1,s2
    80004a44:	855a                	mv	a0,s6
    80004a46:	b9dfc0ef          	jal	800015e2 <copyout>
    80004a4a:	0e054263          	bltz	a0,80004b2e <kexec+0x36c>
  p->trapframe->a1 = sp;
    80004a4e:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80004a52:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004a56:	df843783          	ld	a5,-520(s0)
    80004a5a:	0007c703          	lbu	a4,0(a5)
    80004a5e:	cf11                	beqz	a4,80004a7a <kexec+0x2b8>
    80004a60:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004a62:	02f00693          	li	a3,47
    80004a66:	a039                	j	80004a74 <kexec+0x2b2>
      last = s+1;
    80004a68:	def43c23          	sd	a5,-520(s0)
  for(last=s=path; *s; s++)
    80004a6c:	0785                	addi	a5,a5,1
    80004a6e:	fff7c703          	lbu	a4,-1(a5)
    80004a72:	c701                	beqz	a4,80004a7a <kexec+0x2b8>
    if(*s == '/')
    80004a74:	fed71ce3          	bne	a4,a3,80004a6c <kexec+0x2aa>
    80004a78:	bfc5                	j	80004a68 <kexec+0x2a6>
  safestrcpy(p->name, last, sizeof(p->name));
    80004a7a:	4641                	li	a2,16
    80004a7c:	df843583          	ld	a1,-520(s0)
    80004a80:	158a8513          	addi	a0,s5,344
    80004a84:	b5cfc0ef          	jal	80000de0 <safestrcpy>
  oldpagetable = p->pagetable;
    80004a88:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80004a8c:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80004a90:	e0843783          	ld	a5,-504(s0)
    80004a94:	04fab423          	sd	a5,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    80004a98:	058ab783          	ld	a5,88(s5)
    80004a9c:	e6843703          	ld	a4,-408(s0)
    80004aa0:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004aa2:	058ab783          	ld	a5,88(s5)
    80004aa6:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004aaa:	85e6                	mv	a1,s9
    80004aac:	fadfc0ef          	jal	80001a58 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004ab0:	0004851b          	sext.w	a0,s1
    80004ab4:	79be                	ld	s3,488(sp)
    80004ab6:	7a1e                	ld	s4,480(sp)
    80004ab8:	6afe                	ld	s5,472(sp)
    80004aba:	6b5e                	ld	s6,464(sp)
    80004abc:	6bbe                	ld	s7,456(sp)
    80004abe:	6c1e                	ld	s8,448(sp)
    80004ac0:	7cfa                	ld	s9,440(sp)
    80004ac2:	7d5a                	ld	s10,432(sp)
    80004ac4:	b3b5                	j	80004830 <kexec+0x6e>
    80004ac6:	e1243423          	sd	s2,-504(s0)
    80004aca:	7dba                	ld	s11,424(sp)
    80004acc:	a035                	j	80004af8 <kexec+0x336>
    80004ace:	e1243423          	sd	s2,-504(s0)
    80004ad2:	7dba                	ld	s11,424(sp)
    80004ad4:	a015                	j	80004af8 <kexec+0x336>
    80004ad6:	e1243423          	sd	s2,-504(s0)
    80004ada:	7dba                	ld	s11,424(sp)
    80004adc:	a831                	j	80004af8 <kexec+0x336>
    80004ade:	e1243423          	sd	s2,-504(s0)
    80004ae2:	7dba                	ld	s11,424(sp)
    80004ae4:	a811                	j	80004af8 <kexec+0x336>
    80004ae6:	e1243423          	sd	s2,-504(s0)
    80004aea:	7dba                	ld	s11,424(sp)
    80004aec:	a031                	j	80004af8 <kexec+0x336>
  ip = 0;
    80004aee:	4a01                	li	s4,0
    80004af0:	a021                	j	80004af8 <kexec+0x336>
    80004af2:	4a01                	li	s4,0
  if(pagetable)
    80004af4:	a011                	j	80004af8 <kexec+0x336>
    80004af6:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    80004af8:	e0843583          	ld	a1,-504(s0)
    80004afc:	855a                	mv	a0,s6
    80004afe:	f5bfc0ef          	jal	80001a58 <proc_freepagetable>
  return -1;
    80004b02:	557d                	li	a0,-1
  if(ip){
    80004b04:	000a1b63          	bnez	s4,80004b1a <kexec+0x358>
    80004b08:	79be                	ld	s3,488(sp)
    80004b0a:	7a1e                	ld	s4,480(sp)
    80004b0c:	6afe                	ld	s5,472(sp)
    80004b0e:	6b5e                	ld	s6,464(sp)
    80004b10:	6bbe                	ld	s7,456(sp)
    80004b12:	6c1e                	ld	s8,448(sp)
    80004b14:	7cfa                	ld	s9,440(sp)
    80004b16:	7d5a                	ld	s10,432(sp)
    80004b18:	bb21                	j	80004830 <kexec+0x6e>
    80004b1a:	79be                	ld	s3,488(sp)
    80004b1c:	6afe                	ld	s5,472(sp)
    80004b1e:	6b5e                	ld	s6,464(sp)
    80004b20:	6bbe                	ld	s7,456(sp)
    80004b22:	6c1e                	ld	s8,448(sp)
    80004b24:	7cfa                	ld	s9,440(sp)
    80004b26:	7d5a                	ld	s10,432(sp)
    80004b28:	b9ed                	j	80004822 <kexec+0x60>
    80004b2a:	6b5e                	ld	s6,464(sp)
    80004b2c:	b9dd                	j	80004822 <kexec+0x60>
  sz = sz1;
    80004b2e:	e0843983          	ld	s3,-504(s0)
    80004b32:	b595                	j	80004996 <kexec+0x1d4>

0000000080004b34 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004b34:	7179                	addi	sp,sp,-48
    80004b36:	f406                	sd	ra,40(sp)
    80004b38:	f022                	sd	s0,32(sp)
    80004b3a:	ec26                	sd	s1,24(sp)
    80004b3c:	e84a                	sd	s2,16(sp)
    80004b3e:	1800                	addi	s0,sp,48
    80004b40:	892e                	mv	s2,a1
    80004b42:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004b44:	fdc40593          	addi	a1,s0,-36
    80004b48:	e2bfd0ef          	jal	80002972 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004b4c:	fdc42703          	lw	a4,-36(s0)
    80004b50:	47bd                	li	a5,15
    80004b52:	02e7e963          	bltu	a5,a4,80004b84 <argfd+0x50>
    80004b56:	d79fc0ef          	jal	800018ce <myproc>
    80004b5a:	fdc42703          	lw	a4,-36(s0)
    80004b5e:	01a70793          	addi	a5,a4,26
    80004b62:	078e                	slli	a5,a5,0x3
    80004b64:	953e                	add	a0,a0,a5
    80004b66:	611c                	ld	a5,0(a0)
    80004b68:	c385                	beqz	a5,80004b88 <argfd+0x54>
    return -1;
  if(pfd)
    80004b6a:	00090463          	beqz	s2,80004b72 <argfd+0x3e>
    *pfd = fd;
    80004b6e:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004b72:	4501                	li	a0,0
  if(pf)
    80004b74:	c091                	beqz	s1,80004b78 <argfd+0x44>
    *pf = f;
    80004b76:	e09c                	sd	a5,0(s1)
}
    80004b78:	70a2                	ld	ra,40(sp)
    80004b7a:	7402                	ld	s0,32(sp)
    80004b7c:	64e2                	ld	s1,24(sp)
    80004b7e:	6942                	ld	s2,16(sp)
    80004b80:	6145                	addi	sp,sp,48
    80004b82:	8082                	ret
    return -1;
    80004b84:	557d                	li	a0,-1
    80004b86:	bfcd                	j	80004b78 <argfd+0x44>
    80004b88:	557d                	li	a0,-1
    80004b8a:	b7fd                	j	80004b78 <argfd+0x44>

0000000080004b8c <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004b8c:	1101                	addi	sp,sp,-32
    80004b8e:	ec06                	sd	ra,24(sp)
    80004b90:	e822                	sd	s0,16(sp)
    80004b92:	e426                	sd	s1,8(sp)
    80004b94:	1000                	addi	s0,sp,32
    80004b96:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004b98:	d37fc0ef          	jal	800018ce <myproc>
    80004b9c:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004b9e:	0d050793          	addi	a5,a0,208
    80004ba2:	4501                	li	a0,0
    80004ba4:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004ba6:	6398                	ld	a4,0(a5)
    80004ba8:	cb19                	beqz	a4,80004bbe <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004baa:	2505                	addiw	a0,a0,1
    80004bac:	07a1                	addi	a5,a5,8
    80004bae:	fed51ce3          	bne	a0,a3,80004ba6 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004bb2:	557d                	li	a0,-1
}
    80004bb4:	60e2                	ld	ra,24(sp)
    80004bb6:	6442                	ld	s0,16(sp)
    80004bb8:	64a2                	ld	s1,8(sp)
    80004bba:	6105                	addi	sp,sp,32
    80004bbc:	8082                	ret
      p->ofile[fd] = f;
    80004bbe:	01a50793          	addi	a5,a0,26
    80004bc2:	078e                	slli	a5,a5,0x3
    80004bc4:	963e                	add	a2,a2,a5
    80004bc6:	e204                	sd	s1,0(a2)
      return fd;
    80004bc8:	b7f5                	j	80004bb4 <fdalloc+0x28>

0000000080004bca <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004bca:	715d                	addi	sp,sp,-80
    80004bcc:	e486                	sd	ra,72(sp)
    80004bce:	e0a2                	sd	s0,64(sp)
    80004bd0:	fc26                	sd	s1,56(sp)
    80004bd2:	f84a                	sd	s2,48(sp)
    80004bd4:	f44e                	sd	s3,40(sp)
    80004bd6:	ec56                	sd	s5,24(sp)
    80004bd8:	e85a                	sd	s6,16(sp)
    80004bda:	0880                	addi	s0,sp,80
    80004bdc:	8b2e                	mv	s6,a1
    80004bde:	89b2                	mv	s3,a2
    80004be0:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004be2:	fb040593          	addi	a1,s0,-80
    80004be6:	80eff0ef          	jal	80003bf4 <nameiparent>
    80004bea:	84aa                	mv	s1,a0
    80004bec:	10050a63          	beqz	a0,80004d00 <create+0x136>
    return 0;

  ilock(dp);
    80004bf0:	fd4fe0ef          	jal	800033c4 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004bf4:	4601                	li	a2,0
    80004bf6:	fb040593          	addi	a1,s0,-80
    80004bfa:	8526                	mv	a0,s1
    80004bfc:	d79fe0ef          	jal	80003974 <dirlookup>
    80004c00:	8aaa                	mv	s5,a0
    80004c02:	c129                	beqz	a0,80004c44 <create+0x7a>
    iunlockput(dp);
    80004c04:	8526                	mv	a0,s1
    80004c06:	9c9fe0ef          	jal	800035ce <iunlockput>
    ilock(ip);
    80004c0a:	8556                	mv	a0,s5
    80004c0c:	fb8fe0ef          	jal	800033c4 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004c10:	4789                	li	a5,2
    80004c12:	02fb1463          	bne	s6,a5,80004c3a <create+0x70>
    80004c16:	044ad783          	lhu	a5,68(s5)
    80004c1a:	37f9                	addiw	a5,a5,-2
    80004c1c:	17c2                	slli	a5,a5,0x30
    80004c1e:	93c1                	srli	a5,a5,0x30
    80004c20:	4705                	li	a4,1
    80004c22:	00f76c63          	bltu	a4,a5,80004c3a <create+0x70>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004c26:	8556                	mv	a0,s5
    80004c28:	60a6                	ld	ra,72(sp)
    80004c2a:	6406                	ld	s0,64(sp)
    80004c2c:	74e2                	ld	s1,56(sp)
    80004c2e:	7942                	ld	s2,48(sp)
    80004c30:	79a2                	ld	s3,40(sp)
    80004c32:	6ae2                	ld	s5,24(sp)
    80004c34:	6b42                	ld	s6,16(sp)
    80004c36:	6161                	addi	sp,sp,80
    80004c38:	8082                	ret
    iunlockput(ip);
    80004c3a:	8556                	mv	a0,s5
    80004c3c:	993fe0ef          	jal	800035ce <iunlockput>
    return 0;
    80004c40:	4a81                	li	s5,0
    80004c42:	b7d5                	j	80004c26 <create+0x5c>
    80004c44:	f052                	sd	s4,32(sp)
  if((ip = ialloc(dp->dev, type)) == 0){
    80004c46:	85da                	mv	a1,s6
    80004c48:	4088                	lw	a0,0(s1)
    80004c4a:	e0afe0ef          	jal	80003254 <ialloc>
    80004c4e:	8a2a                	mv	s4,a0
    80004c50:	cd15                	beqz	a0,80004c8c <create+0xc2>
  ilock(ip);
    80004c52:	f72fe0ef          	jal	800033c4 <ilock>
  ip->major = major;
    80004c56:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80004c5a:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80004c5e:	4905                	li	s2,1
    80004c60:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80004c64:	8552                	mv	a0,s4
    80004c66:	eaafe0ef          	jal	80003310 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004c6a:	032b0763          	beq	s6,s2,80004c98 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004c6e:	004a2603          	lw	a2,4(s4)
    80004c72:	fb040593          	addi	a1,s0,-80
    80004c76:	8526                	mv	a0,s1
    80004c78:	ec9fe0ef          	jal	80003b40 <dirlink>
    80004c7c:	06054563          	bltz	a0,80004ce6 <create+0x11c>
  iunlockput(dp);
    80004c80:	8526                	mv	a0,s1
    80004c82:	94dfe0ef          	jal	800035ce <iunlockput>
  return ip;
    80004c86:	8ad2                	mv	s5,s4
    80004c88:	7a02                	ld	s4,32(sp)
    80004c8a:	bf71                	j	80004c26 <create+0x5c>
    iunlockput(dp);
    80004c8c:	8526                	mv	a0,s1
    80004c8e:	941fe0ef          	jal	800035ce <iunlockput>
    return 0;
    80004c92:	8ad2                	mv	s5,s4
    80004c94:	7a02                	ld	s4,32(sp)
    80004c96:	bf41                	j	80004c26 <create+0x5c>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004c98:	004a2603          	lw	a2,4(s4)
    80004c9c:	00003597          	auipc	a1,0x3
    80004ca0:	94458593          	addi	a1,a1,-1724 # 800075e0 <etext+0x5e0>
    80004ca4:	8552                	mv	a0,s4
    80004ca6:	e9bfe0ef          	jal	80003b40 <dirlink>
    80004caa:	02054e63          	bltz	a0,80004ce6 <create+0x11c>
    80004cae:	40d0                	lw	a2,4(s1)
    80004cb0:	00003597          	auipc	a1,0x3
    80004cb4:	93858593          	addi	a1,a1,-1736 # 800075e8 <etext+0x5e8>
    80004cb8:	8552                	mv	a0,s4
    80004cba:	e87fe0ef          	jal	80003b40 <dirlink>
    80004cbe:	02054463          	bltz	a0,80004ce6 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004cc2:	004a2603          	lw	a2,4(s4)
    80004cc6:	fb040593          	addi	a1,s0,-80
    80004cca:	8526                	mv	a0,s1
    80004ccc:	e75fe0ef          	jal	80003b40 <dirlink>
    80004cd0:	00054b63          	bltz	a0,80004ce6 <create+0x11c>
    dp->nlink++;  // for ".."
    80004cd4:	04a4d783          	lhu	a5,74(s1)
    80004cd8:	2785                	addiw	a5,a5,1
    80004cda:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004cde:	8526                	mv	a0,s1
    80004ce0:	e30fe0ef          	jal	80003310 <iupdate>
    80004ce4:	bf71                	j	80004c80 <create+0xb6>
  ip->nlink = 0;
    80004ce6:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004cea:	8552                	mv	a0,s4
    80004cec:	e24fe0ef          	jal	80003310 <iupdate>
  iunlockput(ip);
    80004cf0:	8552                	mv	a0,s4
    80004cf2:	8ddfe0ef          	jal	800035ce <iunlockput>
  iunlockput(dp);
    80004cf6:	8526                	mv	a0,s1
    80004cf8:	8d7fe0ef          	jal	800035ce <iunlockput>
  return 0;
    80004cfc:	7a02                	ld	s4,32(sp)
    80004cfe:	b725                	j	80004c26 <create+0x5c>
    return 0;
    80004d00:	8aaa                	mv	s5,a0
    80004d02:	b715                	j	80004c26 <create+0x5c>

0000000080004d04 <sys_dup>:
{
    80004d04:	7179                	addi	sp,sp,-48
    80004d06:	f406                	sd	ra,40(sp)
    80004d08:	f022                	sd	s0,32(sp)
    80004d0a:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004d0c:	fd840613          	addi	a2,s0,-40
    80004d10:	4581                	li	a1,0
    80004d12:	4501                	li	a0,0
    80004d14:	e21ff0ef          	jal	80004b34 <argfd>
    return -1;
    80004d18:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004d1a:	02054363          	bltz	a0,80004d40 <sys_dup+0x3c>
    80004d1e:	ec26                	sd	s1,24(sp)
    80004d20:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004d22:	fd843903          	ld	s2,-40(s0)
    80004d26:	854a                	mv	a0,s2
    80004d28:	e65ff0ef          	jal	80004b8c <fdalloc>
    80004d2c:	84aa                	mv	s1,a0
    return -1;
    80004d2e:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004d30:	00054d63          	bltz	a0,80004d4a <sys_dup+0x46>
  filedup(f);
    80004d34:	854a                	mv	a0,s2
    80004d36:	c3eff0ef          	jal	80004174 <filedup>
  return fd;
    80004d3a:	87a6                	mv	a5,s1
    80004d3c:	64e2                	ld	s1,24(sp)
    80004d3e:	6942                	ld	s2,16(sp)
}
    80004d40:	853e                	mv	a0,a5
    80004d42:	70a2                	ld	ra,40(sp)
    80004d44:	7402                	ld	s0,32(sp)
    80004d46:	6145                	addi	sp,sp,48
    80004d48:	8082                	ret
    80004d4a:	64e2                	ld	s1,24(sp)
    80004d4c:	6942                	ld	s2,16(sp)
    80004d4e:	bfcd                	j	80004d40 <sys_dup+0x3c>

0000000080004d50 <sys_read>:
{
    80004d50:	7179                	addi	sp,sp,-48
    80004d52:	f406                	sd	ra,40(sp)
    80004d54:	f022                	sd	s0,32(sp)
    80004d56:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004d58:	fd840593          	addi	a1,s0,-40
    80004d5c:	4505                	li	a0,1
    80004d5e:	c31fd0ef          	jal	8000298e <argaddr>
  argint(2, &n);
    80004d62:	fe440593          	addi	a1,s0,-28
    80004d66:	4509                	li	a0,2
    80004d68:	c0bfd0ef          	jal	80002972 <argint>
  if(argfd(0, 0, &f) < 0)
    80004d6c:	fe840613          	addi	a2,s0,-24
    80004d70:	4581                	li	a1,0
    80004d72:	4501                	li	a0,0
    80004d74:	dc1ff0ef          	jal	80004b34 <argfd>
    80004d78:	87aa                	mv	a5,a0
    return -1;
    80004d7a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004d7c:	0007ca63          	bltz	a5,80004d90 <sys_read+0x40>
  return fileread(f, p, n);
    80004d80:	fe442603          	lw	a2,-28(s0)
    80004d84:	fd843583          	ld	a1,-40(s0)
    80004d88:	fe843503          	ld	a0,-24(s0)
    80004d8c:	d4eff0ef          	jal	800042da <fileread>
}
    80004d90:	70a2                	ld	ra,40(sp)
    80004d92:	7402                	ld	s0,32(sp)
    80004d94:	6145                	addi	sp,sp,48
    80004d96:	8082                	ret

0000000080004d98 <sys_write>:
{
    80004d98:	7179                	addi	sp,sp,-48
    80004d9a:	f406                	sd	ra,40(sp)
    80004d9c:	f022                	sd	s0,32(sp)
    80004d9e:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004da0:	fd840593          	addi	a1,s0,-40
    80004da4:	4505                	li	a0,1
    80004da6:	be9fd0ef          	jal	8000298e <argaddr>
  argint(2, &n);
    80004daa:	fe440593          	addi	a1,s0,-28
    80004dae:	4509                	li	a0,2
    80004db0:	bc3fd0ef          	jal	80002972 <argint>
  if(argfd(0, 0, &f) < 0)
    80004db4:	fe840613          	addi	a2,s0,-24
    80004db8:	4581                	li	a1,0
    80004dba:	4501                	li	a0,0
    80004dbc:	d79ff0ef          	jal	80004b34 <argfd>
    80004dc0:	87aa                	mv	a5,a0
    return -1;
    80004dc2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004dc4:	0007ca63          	bltz	a5,80004dd8 <sys_write+0x40>
  return filewrite(f, p, n);
    80004dc8:	fe442603          	lw	a2,-28(s0)
    80004dcc:	fd843583          	ld	a1,-40(s0)
    80004dd0:	fe843503          	ld	a0,-24(s0)
    80004dd4:	dc4ff0ef          	jal	80004398 <filewrite>
}
    80004dd8:	70a2                	ld	ra,40(sp)
    80004dda:	7402                	ld	s0,32(sp)
    80004ddc:	6145                	addi	sp,sp,48
    80004dde:	8082                	ret

0000000080004de0 <sys_close>:
{
    80004de0:	1101                	addi	sp,sp,-32
    80004de2:	ec06                	sd	ra,24(sp)
    80004de4:	e822                	sd	s0,16(sp)
    80004de6:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004de8:	fe040613          	addi	a2,s0,-32
    80004dec:	fec40593          	addi	a1,s0,-20
    80004df0:	4501                	li	a0,0
    80004df2:	d43ff0ef          	jal	80004b34 <argfd>
    return -1;
    80004df6:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004df8:	02054063          	bltz	a0,80004e18 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004dfc:	ad3fc0ef          	jal	800018ce <myproc>
    80004e00:	fec42783          	lw	a5,-20(s0)
    80004e04:	07e9                	addi	a5,a5,26
    80004e06:	078e                	slli	a5,a5,0x3
    80004e08:	953e                	add	a0,a0,a5
    80004e0a:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004e0e:	fe043503          	ld	a0,-32(s0)
    80004e12:	ba8ff0ef          	jal	800041ba <fileclose>
  return 0;
    80004e16:	4781                	li	a5,0
}
    80004e18:	853e                	mv	a0,a5
    80004e1a:	60e2                	ld	ra,24(sp)
    80004e1c:	6442                	ld	s0,16(sp)
    80004e1e:	6105                	addi	sp,sp,32
    80004e20:	8082                	ret

0000000080004e22 <sys_fstat>:
{
    80004e22:	1101                	addi	sp,sp,-32
    80004e24:	ec06                	sd	ra,24(sp)
    80004e26:	e822                	sd	s0,16(sp)
    80004e28:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004e2a:	fe040593          	addi	a1,s0,-32
    80004e2e:	4505                	li	a0,1
    80004e30:	b5ffd0ef          	jal	8000298e <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004e34:	fe840613          	addi	a2,s0,-24
    80004e38:	4581                	li	a1,0
    80004e3a:	4501                	li	a0,0
    80004e3c:	cf9ff0ef          	jal	80004b34 <argfd>
    80004e40:	87aa                	mv	a5,a0
    return -1;
    80004e42:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004e44:	0007c863          	bltz	a5,80004e54 <sys_fstat+0x32>
  return filestat(f, st);
    80004e48:	fe043583          	ld	a1,-32(s0)
    80004e4c:	fe843503          	ld	a0,-24(s0)
    80004e50:	c2cff0ef          	jal	8000427c <filestat>
}
    80004e54:	60e2                	ld	ra,24(sp)
    80004e56:	6442                	ld	s0,16(sp)
    80004e58:	6105                	addi	sp,sp,32
    80004e5a:	8082                	ret

0000000080004e5c <sys_link>:
{
    80004e5c:	7169                	addi	sp,sp,-304
    80004e5e:	f606                	sd	ra,296(sp)
    80004e60:	f222                	sd	s0,288(sp)
    80004e62:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004e64:	08000613          	li	a2,128
    80004e68:	ed040593          	addi	a1,s0,-304
    80004e6c:	4501                	li	a0,0
    80004e6e:	b3dfd0ef          	jal	800029aa <argstr>
    return -1;
    80004e72:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004e74:	0c054e63          	bltz	a0,80004f50 <sys_link+0xf4>
    80004e78:	08000613          	li	a2,128
    80004e7c:	f5040593          	addi	a1,s0,-176
    80004e80:	4505                	li	a0,1
    80004e82:	b29fd0ef          	jal	800029aa <argstr>
    return -1;
    80004e86:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004e88:	0c054463          	bltz	a0,80004f50 <sys_link+0xf4>
    80004e8c:	ee26                	sd	s1,280(sp)
  begin_op();
    80004e8e:	f21fe0ef          	jal	80003dae <begin_op>
  if((ip = namei(old)) == 0){
    80004e92:	ed040513          	addi	a0,s0,-304
    80004e96:	d45fe0ef          	jal	80003bda <namei>
    80004e9a:	84aa                	mv	s1,a0
    80004e9c:	c53d                	beqz	a0,80004f0a <sys_link+0xae>
  ilock(ip);
    80004e9e:	d26fe0ef          	jal	800033c4 <ilock>
  if(ip->type == T_DIR){
    80004ea2:	04449703          	lh	a4,68(s1)
    80004ea6:	4785                	li	a5,1
    80004ea8:	06f70663          	beq	a4,a5,80004f14 <sys_link+0xb8>
    80004eac:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004eae:	04a4d783          	lhu	a5,74(s1)
    80004eb2:	2785                	addiw	a5,a5,1
    80004eb4:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004eb8:	8526                	mv	a0,s1
    80004eba:	c56fe0ef          	jal	80003310 <iupdate>
  iunlock(ip);
    80004ebe:	8526                	mv	a0,s1
    80004ec0:	db2fe0ef          	jal	80003472 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004ec4:	fd040593          	addi	a1,s0,-48
    80004ec8:	f5040513          	addi	a0,s0,-176
    80004ecc:	d29fe0ef          	jal	80003bf4 <nameiparent>
    80004ed0:	892a                	mv	s2,a0
    80004ed2:	cd21                	beqz	a0,80004f2a <sys_link+0xce>
  ilock(dp);
    80004ed4:	cf0fe0ef          	jal	800033c4 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004ed8:	00092703          	lw	a4,0(s2)
    80004edc:	409c                	lw	a5,0(s1)
    80004ede:	04f71363          	bne	a4,a5,80004f24 <sys_link+0xc8>
    80004ee2:	40d0                	lw	a2,4(s1)
    80004ee4:	fd040593          	addi	a1,s0,-48
    80004ee8:	854a                	mv	a0,s2
    80004eea:	c57fe0ef          	jal	80003b40 <dirlink>
    80004eee:	02054b63          	bltz	a0,80004f24 <sys_link+0xc8>
  iunlockput(dp);
    80004ef2:	854a                	mv	a0,s2
    80004ef4:	edafe0ef          	jal	800035ce <iunlockput>
  iput(ip);
    80004ef8:	8526                	mv	a0,s1
    80004efa:	e4cfe0ef          	jal	80003546 <iput>
  end_op();
    80004efe:	f1bfe0ef          	jal	80003e18 <end_op>
  return 0;
    80004f02:	4781                	li	a5,0
    80004f04:	64f2                	ld	s1,280(sp)
    80004f06:	6952                	ld	s2,272(sp)
    80004f08:	a0a1                	j	80004f50 <sys_link+0xf4>
    end_op();
    80004f0a:	f0ffe0ef          	jal	80003e18 <end_op>
    return -1;
    80004f0e:	57fd                	li	a5,-1
    80004f10:	64f2                	ld	s1,280(sp)
    80004f12:	a83d                	j	80004f50 <sys_link+0xf4>
    iunlockput(ip);
    80004f14:	8526                	mv	a0,s1
    80004f16:	eb8fe0ef          	jal	800035ce <iunlockput>
    end_op();
    80004f1a:	efffe0ef          	jal	80003e18 <end_op>
    return -1;
    80004f1e:	57fd                	li	a5,-1
    80004f20:	64f2                	ld	s1,280(sp)
    80004f22:	a03d                	j	80004f50 <sys_link+0xf4>
    iunlockput(dp);
    80004f24:	854a                	mv	a0,s2
    80004f26:	ea8fe0ef          	jal	800035ce <iunlockput>
  ilock(ip);
    80004f2a:	8526                	mv	a0,s1
    80004f2c:	c98fe0ef          	jal	800033c4 <ilock>
  ip->nlink--;
    80004f30:	04a4d783          	lhu	a5,74(s1)
    80004f34:	37fd                	addiw	a5,a5,-1
    80004f36:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004f3a:	8526                	mv	a0,s1
    80004f3c:	bd4fe0ef          	jal	80003310 <iupdate>
  iunlockput(ip);
    80004f40:	8526                	mv	a0,s1
    80004f42:	e8cfe0ef          	jal	800035ce <iunlockput>
  end_op();
    80004f46:	ed3fe0ef          	jal	80003e18 <end_op>
  return -1;
    80004f4a:	57fd                	li	a5,-1
    80004f4c:	64f2                	ld	s1,280(sp)
    80004f4e:	6952                	ld	s2,272(sp)
}
    80004f50:	853e                	mv	a0,a5
    80004f52:	70b2                	ld	ra,296(sp)
    80004f54:	7412                	ld	s0,288(sp)
    80004f56:	6155                	addi	sp,sp,304
    80004f58:	8082                	ret

0000000080004f5a <sys_unlink>:
{
    80004f5a:	7151                	addi	sp,sp,-240
    80004f5c:	f586                	sd	ra,232(sp)
    80004f5e:	f1a2                	sd	s0,224(sp)
    80004f60:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004f62:	08000613          	li	a2,128
    80004f66:	f3040593          	addi	a1,s0,-208
    80004f6a:	4501                	li	a0,0
    80004f6c:	a3ffd0ef          	jal	800029aa <argstr>
    80004f70:	16054063          	bltz	a0,800050d0 <sys_unlink+0x176>
    80004f74:	eda6                	sd	s1,216(sp)
  begin_op();
    80004f76:	e39fe0ef          	jal	80003dae <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004f7a:	fb040593          	addi	a1,s0,-80
    80004f7e:	f3040513          	addi	a0,s0,-208
    80004f82:	c73fe0ef          	jal	80003bf4 <nameiparent>
    80004f86:	84aa                	mv	s1,a0
    80004f88:	c945                	beqz	a0,80005038 <sys_unlink+0xde>
  ilock(dp);
    80004f8a:	c3afe0ef          	jal	800033c4 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004f8e:	00002597          	auipc	a1,0x2
    80004f92:	65258593          	addi	a1,a1,1618 # 800075e0 <etext+0x5e0>
    80004f96:	fb040513          	addi	a0,s0,-80
    80004f9a:	9c5fe0ef          	jal	8000395e <namecmp>
    80004f9e:	10050e63          	beqz	a0,800050ba <sys_unlink+0x160>
    80004fa2:	00002597          	auipc	a1,0x2
    80004fa6:	64658593          	addi	a1,a1,1606 # 800075e8 <etext+0x5e8>
    80004faa:	fb040513          	addi	a0,s0,-80
    80004fae:	9b1fe0ef          	jal	8000395e <namecmp>
    80004fb2:	10050463          	beqz	a0,800050ba <sys_unlink+0x160>
    80004fb6:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004fb8:	f2c40613          	addi	a2,s0,-212
    80004fbc:	fb040593          	addi	a1,s0,-80
    80004fc0:	8526                	mv	a0,s1
    80004fc2:	9b3fe0ef          	jal	80003974 <dirlookup>
    80004fc6:	892a                	mv	s2,a0
    80004fc8:	0e050863          	beqz	a0,800050b8 <sys_unlink+0x15e>
  ilock(ip);
    80004fcc:	bf8fe0ef          	jal	800033c4 <ilock>
  if(ip->nlink < 1)
    80004fd0:	04a91783          	lh	a5,74(s2)
    80004fd4:	06f05763          	blez	a5,80005042 <sys_unlink+0xe8>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004fd8:	04491703          	lh	a4,68(s2)
    80004fdc:	4785                	li	a5,1
    80004fde:	06f70963          	beq	a4,a5,80005050 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80004fe2:	4641                	li	a2,16
    80004fe4:	4581                	li	a1,0
    80004fe6:	fc040513          	addi	a0,s0,-64
    80004fea:	cb9fb0ef          	jal	80000ca2 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004fee:	4741                	li	a4,16
    80004ff0:	f2c42683          	lw	a3,-212(s0)
    80004ff4:	fc040613          	addi	a2,s0,-64
    80004ff8:	4581                	li	a1,0
    80004ffa:	8526                	mv	a0,s1
    80004ffc:	855fe0ef          	jal	80003850 <writei>
    80005000:	47c1                	li	a5,16
    80005002:	08f51b63          	bne	a0,a5,80005098 <sys_unlink+0x13e>
  if(ip->type == T_DIR){
    80005006:	04491703          	lh	a4,68(s2)
    8000500a:	4785                	li	a5,1
    8000500c:	08f70d63          	beq	a4,a5,800050a6 <sys_unlink+0x14c>
  iunlockput(dp);
    80005010:	8526                	mv	a0,s1
    80005012:	dbcfe0ef          	jal	800035ce <iunlockput>
  ip->nlink--;
    80005016:	04a95783          	lhu	a5,74(s2)
    8000501a:	37fd                	addiw	a5,a5,-1
    8000501c:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80005020:	854a                	mv	a0,s2
    80005022:	aeefe0ef          	jal	80003310 <iupdate>
  iunlockput(ip);
    80005026:	854a                	mv	a0,s2
    80005028:	da6fe0ef          	jal	800035ce <iunlockput>
  end_op();
    8000502c:	dedfe0ef          	jal	80003e18 <end_op>
  return 0;
    80005030:	4501                	li	a0,0
    80005032:	64ee                	ld	s1,216(sp)
    80005034:	694e                	ld	s2,208(sp)
    80005036:	a849                	j	800050c8 <sys_unlink+0x16e>
    end_op();
    80005038:	de1fe0ef          	jal	80003e18 <end_op>
    return -1;
    8000503c:	557d                	li	a0,-1
    8000503e:	64ee                	ld	s1,216(sp)
    80005040:	a061                	j	800050c8 <sys_unlink+0x16e>
    80005042:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    80005044:	00002517          	auipc	a0,0x2
    80005048:	5ac50513          	addi	a0,a0,1452 # 800075f0 <etext+0x5f0>
    8000504c:	f94fb0ef          	jal	800007e0 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005050:	04c92703          	lw	a4,76(s2)
    80005054:	02000793          	li	a5,32
    80005058:	f8e7f5e3          	bgeu	a5,a4,80004fe2 <sys_unlink+0x88>
    8000505c:	e5ce                	sd	s3,200(sp)
    8000505e:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005062:	4741                	li	a4,16
    80005064:	86ce                	mv	a3,s3
    80005066:	f1840613          	addi	a2,s0,-232
    8000506a:	4581                	li	a1,0
    8000506c:	854a                	mv	a0,s2
    8000506e:	ee6fe0ef          	jal	80003754 <readi>
    80005072:	47c1                	li	a5,16
    80005074:	00f51c63          	bne	a0,a5,8000508c <sys_unlink+0x132>
    if(de.inum != 0)
    80005078:	f1845783          	lhu	a5,-232(s0)
    8000507c:	efa1                	bnez	a5,800050d4 <sys_unlink+0x17a>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000507e:	29c1                	addiw	s3,s3,16
    80005080:	04c92783          	lw	a5,76(s2)
    80005084:	fcf9efe3          	bltu	s3,a5,80005062 <sys_unlink+0x108>
    80005088:	69ae                	ld	s3,200(sp)
    8000508a:	bfa1                	j	80004fe2 <sys_unlink+0x88>
      panic("isdirempty: readi");
    8000508c:	00002517          	auipc	a0,0x2
    80005090:	57c50513          	addi	a0,a0,1404 # 80007608 <etext+0x608>
    80005094:	f4cfb0ef          	jal	800007e0 <panic>
    80005098:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    8000509a:	00002517          	auipc	a0,0x2
    8000509e:	58650513          	addi	a0,a0,1414 # 80007620 <etext+0x620>
    800050a2:	f3efb0ef          	jal	800007e0 <panic>
    dp->nlink--;
    800050a6:	04a4d783          	lhu	a5,74(s1)
    800050aa:	37fd                	addiw	a5,a5,-1
    800050ac:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800050b0:	8526                	mv	a0,s1
    800050b2:	a5efe0ef          	jal	80003310 <iupdate>
    800050b6:	bfa9                	j	80005010 <sys_unlink+0xb6>
    800050b8:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800050ba:	8526                	mv	a0,s1
    800050bc:	d12fe0ef          	jal	800035ce <iunlockput>
  end_op();
    800050c0:	d59fe0ef          	jal	80003e18 <end_op>
  return -1;
    800050c4:	557d                	li	a0,-1
    800050c6:	64ee                	ld	s1,216(sp)
}
    800050c8:	70ae                	ld	ra,232(sp)
    800050ca:	740e                	ld	s0,224(sp)
    800050cc:	616d                	addi	sp,sp,240
    800050ce:	8082                	ret
    return -1;
    800050d0:	557d                	li	a0,-1
    800050d2:	bfdd                	j	800050c8 <sys_unlink+0x16e>
    iunlockput(ip);
    800050d4:	854a                	mv	a0,s2
    800050d6:	cf8fe0ef          	jal	800035ce <iunlockput>
    goto bad;
    800050da:	694e                	ld	s2,208(sp)
    800050dc:	69ae                	ld	s3,200(sp)
    800050de:	bff1                	j	800050ba <sys_unlink+0x160>

00000000800050e0 <sys_open>:

uint64
sys_open(void)
{
    800050e0:	7131                	addi	sp,sp,-192
    800050e2:	fd06                	sd	ra,184(sp)
    800050e4:	f922                	sd	s0,176(sp)
    800050e6:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800050e8:	f4c40593          	addi	a1,s0,-180
    800050ec:	4505                	li	a0,1
    800050ee:	885fd0ef          	jal	80002972 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800050f2:	08000613          	li	a2,128
    800050f6:	f5040593          	addi	a1,s0,-176
    800050fa:	4501                	li	a0,0
    800050fc:	8affd0ef          	jal	800029aa <argstr>
    80005100:	87aa                	mv	a5,a0
    return -1;
    80005102:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80005104:	0a07c263          	bltz	a5,800051a8 <sys_open+0xc8>
    80005108:	f526                	sd	s1,168(sp)

  begin_op();
    8000510a:	ca5fe0ef          	jal	80003dae <begin_op>

  if(omode & O_CREATE){
    8000510e:	f4c42783          	lw	a5,-180(s0)
    80005112:	2007f793          	andi	a5,a5,512
    80005116:	c3d5                	beqz	a5,800051ba <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80005118:	4681                	li	a3,0
    8000511a:	4601                	li	a2,0
    8000511c:	4589                	li	a1,2
    8000511e:	f5040513          	addi	a0,s0,-176
    80005122:	aa9ff0ef          	jal	80004bca <create>
    80005126:	84aa                	mv	s1,a0
    if(ip == 0){
    80005128:	c541                	beqz	a0,800051b0 <sys_open+0xd0>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    8000512a:	04449703          	lh	a4,68(s1)
    8000512e:	478d                	li	a5,3
    80005130:	00f71763          	bne	a4,a5,8000513e <sys_open+0x5e>
    80005134:	0464d703          	lhu	a4,70(s1)
    80005138:	47a5                	li	a5,9
    8000513a:	0ae7ed63          	bltu	a5,a4,800051f4 <sys_open+0x114>
    8000513e:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80005140:	fd7fe0ef          	jal	80004116 <filealloc>
    80005144:	892a                	mv	s2,a0
    80005146:	c179                	beqz	a0,8000520c <sys_open+0x12c>
    80005148:	ed4e                	sd	s3,152(sp)
    8000514a:	a43ff0ef          	jal	80004b8c <fdalloc>
    8000514e:	89aa                	mv	s3,a0
    80005150:	0a054a63          	bltz	a0,80005204 <sys_open+0x124>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80005154:	04449703          	lh	a4,68(s1)
    80005158:	478d                	li	a5,3
    8000515a:	0cf70263          	beq	a4,a5,8000521e <sys_open+0x13e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000515e:	4789                	li	a5,2
    80005160:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80005164:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80005168:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    8000516c:	f4c42783          	lw	a5,-180(s0)
    80005170:	0017c713          	xori	a4,a5,1
    80005174:	8b05                	andi	a4,a4,1
    80005176:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000517a:	0037f713          	andi	a4,a5,3
    8000517e:	00e03733          	snez	a4,a4
    80005182:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80005186:	4007f793          	andi	a5,a5,1024
    8000518a:	c791                	beqz	a5,80005196 <sys_open+0xb6>
    8000518c:	04449703          	lh	a4,68(s1)
    80005190:	4789                	li	a5,2
    80005192:	08f70d63          	beq	a4,a5,8000522c <sys_open+0x14c>
    itrunc(ip);
  }

  iunlock(ip);
    80005196:	8526                	mv	a0,s1
    80005198:	adafe0ef          	jal	80003472 <iunlock>
  end_op();
    8000519c:	c7dfe0ef          	jal	80003e18 <end_op>

  return fd;
    800051a0:	854e                	mv	a0,s3
    800051a2:	74aa                	ld	s1,168(sp)
    800051a4:	790a                	ld	s2,160(sp)
    800051a6:	69ea                	ld	s3,152(sp)
}
    800051a8:	70ea                	ld	ra,184(sp)
    800051aa:	744a                	ld	s0,176(sp)
    800051ac:	6129                	addi	sp,sp,192
    800051ae:	8082                	ret
      end_op();
    800051b0:	c69fe0ef          	jal	80003e18 <end_op>
      return -1;
    800051b4:	557d                	li	a0,-1
    800051b6:	74aa                	ld	s1,168(sp)
    800051b8:	bfc5                	j	800051a8 <sys_open+0xc8>
    if((ip = namei(path)) == 0){
    800051ba:	f5040513          	addi	a0,s0,-176
    800051be:	a1dfe0ef          	jal	80003bda <namei>
    800051c2:	84aa                	mv	s1,a0
    800051c4:	c11d                	beqz	a0,800051ea <sys_open+0x10a>
    ilock(ip);
    800051c6:	9fefe0ef          	jal	800033c4 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800051ca:	04449703          	lh	a4,68(s1)
    800051ce:	4785                	li	a5,1
    800051d0:	f4f71de3          	bne	a4,a5,8000512a <sys_open+0x4a>
    800051d4:	f4c42783          	lw	a5,-180(s0)
    800051d8:	d3bd                	beqz	a5,8000513e <sys_open+0x5e>
      iunlockput(ip);
    800051da:	8526                	mv	a0,s1
    800051dc:	bf2fe0ef          	jal	800035ce <iunlockput>
      end_op();
    800051e0:	c39fe0ef          	jal	80003e18 <end_op>
      return -1;
    800051e4:	557d                	li	a0,-1
    800051e6:	74aa                	ld	s1,168(sp)
    800051e8:	b7c1                	j	800051a8 <sys_open+0xc8>
      end_op();
    800051ea:	c2ffe0ef          	jal	80003e18 <end_op>
      return -1;
    800051ee:	557d                	li	a0,-1
    800051f0:	74aa                	ld	s1,168(sp)
    800051f2:	bf5d                	j	800051a8 <sys_open+0xc8>
    iunlockput(ip);
    800051f4:	8526                	mv	a0,s1
    800051f6:	bd8fe0ef          	jal	800035ce <iunlockput>
    end_op();
    800051fa:	c1ffe0ef          	jal	80003e18 <end_op>
    return -1;
    800051fe:	557d                	li	a0,-1
    80005200:	74aa                	ld	s1,168(sp)
    80005202:	b75d                	j	800051a8 <sys_open+0xc8>
      fileclose(f);
    80005204:	854a                	mv	a0,s2
    80005206:	fb5fe0ef          	jal	800041ba <fileclose>
    8000520a:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    8000520c:	8526                	mv	a0,s1
    8000520e:	bc0fe0ef          	jal	800035ce <iunlockput>
    end_op();
    80005212:	c07fe0ef          	jal	80003e18 <end_op>
    return -1;
    80005216:	557d                	li	a0,-1
    80005218:	74aa                	ld	s1,168(sp)
    8000521a:	790a                	ld	s2,160(sp)
    8000521c:	b771                	j	800051a8 <sys_open+0xc8>
    f->type = FD_DEVICE;
    8000521e:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    80005222:	04649783          	lh	a5,70(s1)
    80005226:	02f91223          	sh	a5,36(s2)
    8000522a:	bf3d                	j	80005168 <sys_open+0x88>
    itrunc(ip);
    8000522c:	8526                	mv	a0,s1
    8000522e:	a84fe0ef          	jal	800034b2 <itrunc>
    80005232:	b795                	j	80005196 <sys_open+0xb6>

0000000080005234 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005234:	7175                	addi	sp,sp,-144
    80005236:	e506                	sd	ra,136(sp)
    80005238:	e122                	sd	s0,128(sp)
    8000523a:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000523c:	b73fe0ef          	jal	80003dae <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80005240:	08000613          	li	a2,128
    80005244:	f7040593          	addi	a1,s0,-144
    80005248:	4501                	li	a0,0
    8000524a:	f60fd0ef          	jal	800029aa <argstr>
    8000524e:	02054363          	bltz	a0,80005274 <sys_mkdir+0x40>
    80005252:	4681                	li	a3,0
    80005254:	4601                	li	a2,0
    80005256:	4585                	li	a1,1
    80005258:	f7040513          	addi	a0,s0,-144
    8000525c:	96fff0ef          	jal	80004bca <create>
    80005260:	c911                	beqz	a0,80005274 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005262:	b6cfe0ef          	jal	800035ce <iunlockput>
  end_op();
    80005266:	bb3fe0ef          	jal	80003e18 <end_op>
  return 0;
    8000526a:	4501                	li	a0,0
}
    8000526c:	60aa                	ld	ra,136(sp)
    8000526e:	640a                	ld	s0,128(sp)
    80005270:	6149                	addi	sp,sp,144
    80005272:	8082                	ret
    end_op();
    80005274:	ba5fe0ef          	jal	80003e18 <end_op>
    return -1;
    80005278:	557d                	li	a0,-1
    8000527a:	bfcd                	j	8000526c <sys_mkdir+0x38>

000000008000527c <sys_mknod>:

uint64
sys_mknod(void)
{
    8000527c:	7135                	addi	sp,sp,-160
    8000527e:	ed06                	sd	ra,152(sp)
    80005280:	e922                	sd	s0,144(sp)
    80005282:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005284:	b2bfe0ef          	jal	80003dae <begin_op>
  argint(1, &major);
    80005288:	f6c40593          	addi	a1,s0,-148
    8000528c:	4505                	li	a0,1
    8000528e:	ee4fd0ef          	jal	80002972 <argint>
  argint(2, &minor);
    80005292:	f6840593          	addi	a1,s0,-152
    80005296:	4509                	li	a0,2
    80005298:	edafd0ef          	jal	80002972 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000529c:	08000613          	li	a2,128
    800052a0:	f7040593          	addi	a1,s0,-144
    800052a4:	4501                	li	a0,0
    800052a6:	f04fd0ef          	jal	800029aa <argstr>
    800052aa:	02054563          	bltz	a0,800052d4 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800052ae:	f6841683          	lh	a3,-152(s0)
    800052b2:	f6c41603          	lh	a2,-148(s0)
    800052b6:	458d                	li	a1,3
    800052b8:	f7040513          	addi	a0,s0,-144
    800052bc:	90fff0ef          	jal	80004bca <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800052c0:	c911                	beqz	a0,800052d4 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800052c2:	b0cfe0ef          	jal	800035ce <iunlockput>
  end_op();
    800052c6:	b53fe0ef          	jal	80003e18 <end_op>
  return 0;
    800052ca:	4501                	li	a0,0
}
    800052cc:	60ea                	ld	ra,152(sp)
    800052ce:	644a                	ld	s0,144(sp)
    800052d0:	610d                	addi	sp,sp,160
    800052d2:	8082                	ret
    end_op();
    800052d4:	b45fe0ef          	jal	80003e18 <end_op>
    return -1;
    800052d8:	557d                	li	a0,-1
    800052da:	bfcd                	j	800052cc <sys_mknod+0x50>

00000000800052dc <sys_chdir>:

uint64
sys_chdir(void)
{
    800052dc:	7135                	addi	sp,sp,-160
    800052de:	ed06                	sd	ra,152(sp)
    800052e0:	e922                	sd	s0,144(sp)
    800052e2:	e14a                	sd	s2,128(sp)
    800052e4:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800052e6:	de8fc0ef          	jal	800018ce <myproc>
    800052ea:	892a                	mv	s2,a0
  
  begin_op();
    800052ec:	ac3fe0ef          	jal	80003dae <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800052f0:	08000613          	li	a2,128
    800052f4:	f6040593          	addi	a1,s0,-160
    800052f8:	4501                	li	a0,0
    800052fa:	eb0fd0ef          	jal	800029aa <argstr>
    800052fe:	04054363          	bltz	a0,80005344 <sys_chdir+0x68>
    80005302:	e526                	sd	s1,136(sp)
    80005304:	f6040513          	addi	a0,s0,-160
    80005308:	8d3fe0ef          	jal	80003bda <namei>
    8000530c:	84aa                	mv	s1,a0
    8000530e:	c915                	beqz	a0,80005342 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005310:	8b4fe0ef          	jal	800033c4 <ilock>
  if(ip->type != T_DIR){
    80005314:	04449703          	lh	a4,68(s1)
    80005318:	4785                	li	a5,1
    8000531a:	02f71963          	bne	a4,a5,8000534c <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000531e:	8526                	mv	a0,s1
    80005320:	952fe0ef          	jal	80003472 <iunlock>
  iput(p->cwd);
    80005324:	15093503          	ld	a0,336(s2)
    80005328:	a1efe0ef          	jal	80003546 <iput>
  end_op();
    8000532c:	aedfe0ef          	jal	80003e18 <end_op>
  p->cwd = ip;
    80005330:	14993823          	sd	s1,336(s2)
  return 0;
    80005334:	4501                	li	a0,0
    80005336:	64aa                	ld	s1,136(sp)
}
    80005338:	60ea                	ld	ra,152(sp)
    8000533a:	644a                	ld	s0,144(sp)
    8000533c:	690a                	ld	s2,128(sp)
    8000533e:	610d                	addi	sp,sp,160
    80005340:	8082                	ret
    80005342:	64aa                	ld	s1,136(sp)
    end_op();
    80005344:	ad5fe0ef          	jal	80003e18 <end_op>
    return -1;
    80005348:	557d                	li	a0,-1
    8000534a:	b7fd                	j	80005338 <sys_chdir+0x5c>
    iunlockput(ip);
    8000534c:	8526                	mv	a0,s1
    8000534e:	a80fe0ef          	jal	800035ce <iunlockput>
    end_op();
    80005352:	ac7fe0ef          	jal	80003e18 <end_op>
    return -1;
    80005356:	557d                	li	a0,-1
    80005358:	64aa                	ld	s1,136(sp)
    8000535a:	bff9                	j	80005338 <sys_chdir+0x5c>

000000008000535c <sys_exec>:

uint64
sys_exec(void)
{
    8000535c:	7121                	addi	sp,sp,-448
    8000535e:	ff06                	sd	ra,440(sp)
    80005360:	fb22                	sd	s0,432(sp)
    80005362:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005364:	e4840593          	addi	a1,s0,-440
    80005368:	4505                	li	a0,1
    8000536a:	e24fd0ef          	jal	8000298e <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    8000536e:	08000613          	li	a2,128
    80005372:	f5040593          	addi	a1,s0,-176
    80005376:	4501                	li	a0,0
    80005378:	e32fd0ef          	jal	800029aa <argstr>
    8000537c:	87aa                	mv	a5,a0
    return -1;
    8000537e:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005380:	0c07c463          	bltz	a5,80005448 <sys_exec+0xec>
    80005384:	f726                	sd	s1,424(sp)
    80005386:	f34a                	sd	s2,416(sp)
    80005388:	ef4e                	sd	s3,408(sp)
    8000538a:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    8000538c:	10000613          	li	a2,256
    80005390:	4581                	li	a1,0
    80005392:	e5040513          	addi	a0,s0,-432
    80005396:	90dfb0ef          	jal	80000ca2 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    8000539a:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    8000539e:	89a6                	mv	s3,s1
    800053a0:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    800053a2:	02000a13          	li	s4,32
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800053a6:	00391513          	slli	a0,s2,0x3
    800053aa:	e4040593          	addi	a1,s0,-448
    800053ae:	e4843783          	ld	a5,-440(s0)
    800053b2:	953e                	add	a0,a0,a5
    800053b4:	d34fd0ef          	jal	800028e8 <fetchaddr>
    800053b8:	02054663          	bltz	a0,800053e4 <sys_exec+0x88>
      goto bad;
    }
    if(uarg == 0){
    800053bc:	e4043783          	ld	a5,-448(s0)
    800053c0:	c3a9                	beqz	a5,80005402 <sys_exec+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    800053c2:	f3cfb0ef          	jal	80000afe <kalloc>
    800053c6:	85aa                	mv	a1,a0
    800053c8:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800053cc:	cd01                	beqz	a0,800053e4 <sys_exec+0x88>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800053ce:	6605                	lui	a2,0x1
    800053d0:	e4043503          	ld	a0,-448(s0)
    800053d4:	d5efd0ef          	jal	80002932 <fetchstr>
    800053d8:	00054663          	bltz	a0,800053e4 <sys_exec+0x88>
    if(i >= NELEM(argv)){
    800053dc:	0905                	addi	s2,s2,1
    800053de:	09a1                	addi	s3,s3,8
    800053e0:	fd4913e3          	bne	s2,s4,800053a6 <sys_exec+0x4a>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800053e4:	f5040913          	addi	s2,s0,-176
    800053e8:	6088                	ld	a0,0(s1)
    800053ea:	c931                	beqz	a0,8000543e <sys_exec+0xe2>
    kfree(argv[i]);
    800053ec:	e30fb0ef          	jal	80000a1c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800053f0:	04a1                	addi	s1,s1,8
    800053f2:	ff249be3          	bne	s1,s2,800053e8 <sys_exec+0x8c>
  return -1;
    800053f6:	557d                	li	a0,-1
    800053f8:	74ba                	ld	s1,424(sp)
    800053fa:	791a                	ld	s2,416(sp)
    800053fc:	69fa                	ld	s3,408(sp)
    800053fe:	6a5a                	ld	s4,400(sp)
    80005400:	a0a1                	j	80005448 <sys_exec+0xec>
      argv[i] = 0;
    80005402:	0009079b          	sext.w	a5,s2
    80005406:	078e                	slli	a5,a5,0x3
    80005408:	fd078793          	addi	a5,a5,-48
    8000540c:	97a2                	add	a5,a5,s0
    8000540e:	e807b023          	sd	zero,-384(a5)
  int ret = kexec(path, argv);
    80005412:	e5040593          	addi	a1,s0,-432
    80005416:	f5040513          	addi	a0,s0,-176
    8000541a:	ba8ff0ef          	jal	800047c2 <kexec>
    8000541e:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005420:	f5040993          	addi	s3,s0,-176
    80005424:	6088                	ld	a0,0(s1)
    80005426:	c511                	beqz	a0,80005432 <sys_exec+0xd6>
    kfree(argv[i]);
    80005428:	df4fb0ef          	jal	80000a1c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000542c:	04a1                	addi	s1,s1,8
    8000542e:	ff349be3          	bne	s1,s3,80005424 <sys_exec+0xc8>
  return ret;
    80005432:	854a                	mv	a0,s2
    80005434:	74ba                	ld	s1,424(sp)
    80005436:	791a                	ld	s2,416(sp)
    80005438:	69fa                	ld	s3,408(sp)
    8000543a:	6a5a                	ld	s4,400(sp)
    8000543c:	a031                	j	80005448 <sys_exec+0xec>
  return -1;
    8000543e:	557d                	li	a0,-1
    80005440:	74ba                	ld	s1,424(sp)
    80005442:	791a                	ld	s2,416(sp)
    80005444:	69fa                	ld	s3,408(sp)
    80005446:	6a5a                	ld	s4,400(sp)
}
    80005448:	70fa                	ld	ra,440(sp)
    8000544a:	745a                	ld	s0,432(sp)
    8000544c:	6139                	addi	sp,sp,448
    8000544e:	8082                	ret

0000000080005450 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005450:	7139                	addi	sp,sp,-64
    80005452:	fc06                	sd	ra,56(sp)
    80005454:	f822                	sd	s0,48(sp)
    80005456:	f426                	sd	s1,40(sp)
    80005458:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000545a:	c74fc0ef          	jal	800018ce <myproc>
    8000545e:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005460:	fd840593          	addi	a1,s0,-40
    80005464:	4501                	li	a0,0
    80005466:	d28fd0ef          	jal	8000298e <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000546a:	fc840593          	addi	a1,s0,-56
    8000546e:	fd040513          	addi	a0,s0,-48
    80005472:	852ff0ef          	jal	800044c4 <pipealloc>
    return -1;
    80005476:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005478:	0a054463          	bltz	a0,80005520 <sys_pipe+0xd0>
  fd0 = -1;
    8000547c:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005480:	fd043503          	ld	a0,-48(s0)
    80005484:	f08ff0ef          	jal	80004b8c <fdalloc>
    80005488:	fca42223          	sw	a0,-60(s0)
    8000548c:	08054163          	bltz	a0,8000550e <sys_pipe+0xbe>
    80005490:	fc843503          	ld	a0,-56(s0)
    80005494:	ef8ff0ef          	jal	80004b8c <fdalloc>
    80005498:	fca42023          	sw	a0,-64(s0)
    8000549c:	06054063          	bltz	a0,800054fc <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800054a0:	4691                	li	a3,4
    800054a2:	fc440613          	addi	a2,s0,-60
    800054a6:	fd843583          	ld	a1,-40(s0)
    800054aa:	68a8                	ld	a0,80(s1)
    800054ac:	936fc0ef          	jal	800015e2 <copyout>
    800054b0:	00054e63          	bltz	a0,800054cc <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800054b4:	4691                	li	a3,4
    800054b6:	fc040613          	addi	a2,s0,-64
    800054ba:	fd843583          	ld	a1,-40(s0)
    800054be:	0591                	addi	a1,a1,4
    800054c0:	68a8                	ld	a0,80(s1)
    800054c2:	920fc0ef          	jal	800015e2 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800054c6:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800054c8:	04055c63          	bgez	a0,80005520 <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    800054cc:	fc442783          	lw	a5,-60(s0)
    800054d0:	07e9                	addi	a5,a5,26
    800054d2:	078e                	slli	a5,a5,0x3
    800054d4:	97a6                	add	a5,a5,s1
    800054d6:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800054da:	fc042783          	lw	a5,-64(s0)
    800054de:	07e9                	addi	a5,a5,26
    800054e0:	078e                	slli	a5,a5,0x3
    800054e2:	94be                	add	s1,s1,a5
    800054e4:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    800054e8:	fd043503          	ld	a0,-48(s0)
    800054ec:	ccffe0ef          	jal	800041ba <fileclose>
    fileclose(wf);
    800054f0:	fc843503          	ld	a0,-56(s0)
    800054f4:	cc7fe0ef          	jal	800041ba <fileclose>
    return -1;
    800054f8:	57fd                	li	a5,-1
    800054fa:	a01d                	j	80005520 <sys_pipe+0xd0>
    if(fd0 >= 0)
    800054fc:	fc442783          	lw	a5,-60(s0)
    80005500:	0007c763          	bltz	a5,8000550e <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    80005504:	07e9                	addi	a5,a5,26
    80005506:	078e                	slli	a5,a5,0x3
    80005508:	97a6                	add	a5,a5,s1
    8000550a:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    8000550e:	fd043503          	ld	a0,-48(s0)
    80005512:	ca9fe0ef          	jal	800041ba <fileclose>
    fileclose(wf);
    80005516:	fc843503          	ld	a0,-56(s0)
    8000551a:	ca1fe0ef          	jal	800041ba <fileclose>
    return -1;
    8000551e:	57fd                	li	a5,-1
}
    80005520:	853e                	mv	a0,a5
    80005522:	70e2                	ld	ra,56(sp)
    80005524:	7442                	ld	s0,48(sp)
    80005526:	74a2                	ld	s1,40(sp)
    80005528:	6121                	addi	sp,sp,64
    8000552a:	8082                	ret
    8000552c:	0000                	unimp
	...

0000000080005530 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005530:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005532:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005534:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005536:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005538:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000553a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000553c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000553e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005540:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005542:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005544:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005546:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005548:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000554a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000554c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000554e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005550:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005552:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005554:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005556:	a6cfd0ef          	jal	800027c2 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000555a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000555c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000555e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005560:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005562:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005564:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005566:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005568:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    8000556a:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000556c:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000556e:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005570:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005572:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005574:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005576:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005578:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    8000557a:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000557c:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000557e:	10200073          	sret
	...

000000008000558e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000558e:	1141                	addi	sp,sp,-16
    80005590:	e422                	sd	s0,8(sp)
    80005592:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005594:	0c0007b7          	lui	a5,0xc000
    80005598:	4705                	li	a4,1
    8000559a:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000559c:	0c0007b7          	lui	a5,0xc000
    800055a0:	c3d8                	sw	a4,4(a5)
}
    800055a2:	6422                	ld	s0,8(sp)
    800055a4:	0141                	addi	sp,sp,16
    800055a6:	8082                	ret

00000000800055a8 <plicinithart>:

void
plicinithart(void)
{
    800055a8:	1141                	addi	sp,sp,-16
    800055aa:	e406                	sd	ra,8(sp)
    800055ac:	e022                	sd	s0,0(sp)
    800055ae:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800055b0:	af2fc0ef          	jal	800018a2 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800055b4:	0085171b          	slliw	a4,a0,0x8
    800055b8:	0c0027b7          	lui	a5,0xc002
    800055bc:	97ba                	add	a5,a5,a4
    800055be:	40200713          	li	a4,1026
    800055c2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800055c6:	00d5151b          	slliw	a0,a0,0xd
    800055ca:	0c2017b7          	lui	a5,0xc201
    800055ce:	97aa                	add	a5,a5,a0
    800055d0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800055d4:	60a2                	ld	ra,8(sp)
    800055d6:	6402                	ld	s0,0(sp)
    800055d8:	0141                	addi	sp,sp,16
    800055da:	8082                	ret

00000000800055dc <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800055dc:	1141                	addi	sp,sp,-16
    800055de:	e406                	sd	ra,8(sp)
    800055e0:	e022                	sd	s0,0(sp)
    800055e2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800055e4:	abefc0ef          	jal	800018a2 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800055e8:	00d5151b          	slliw	a0,a0,0xd
    800055ec:	0c2017b7          	lui	a5,0xc201
    800055f0:	97aa                	add	a5,a5,a0
  return irq;
}
    800055f2:	43c8                	lw	a0,4(a5)
    800055f4:	60a2                	ld	ra,8(sp)
    800055f6:	6402                	ld	s0,0(sp)
    800055f8:	0141                	addi	sp,sp,16
    800055fa:	8082                	ret

00000000800055fc <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800055fc:	1101                	addi	sp,sp,-32
    800055fe:	ec06                	sd	ra,24(sp)
    80005600:	e822                	sd	s0,16(sp)
    80005602:	e426                	sd	s1,8(sp)
    80005604:	1000                	addi	s0,sp,32
    80005606:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005608:	a9afc0ef          	jal	800018a2 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    8000560c:	00d5151b          	slliw	a0,a0,0xd
    80005610:	0c2017b7          	lui	a5,0xc201
    80005614:	97aa                	add	a5,a5,a0
    80005616:	c3c4                	sw	s1,4(a5)
}
    80005618:	60e2                	ld	ra,24(sp)
    8000561a:	6442                	ld	s0,16(sp)
    8000561c:	64a2                	ld	s1,8(sp)
    8000561e:	6105                	addi	sp,sp,32
    80005620:	8082                	ret

0000000080005622 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005622:	1141                	addi	sp,sp,-16
    80005624:	e406                	sd	ra,8(sp)
    80005626:	e022                	sd	s0,0(sp)
    80005628:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000562a:	479d                	li	a5,7
    8000562c:	04a7ca63          	blt	a5,a0,80005680 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005630:	0001e797          	auipc	a5,0x1e
    80005634:	23878793          	addi	a5,a5,568 # 80023868 <disk>
    80005638:	97aa                	add	a5,a5,a0
    8000563a:	0187c783          	lbu	a5,24(a5)
    8000563e:	e7b9                	bnez	a5,8000568c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005640:	00451693          	slli	a3,a0,0x4
    80005644:	0001e797          	auipc	a5,0x1e
    80005648:	22478793          	addi	a5,a5,548 # 80023868 <disk>
    8000564c:	6398                	ld	a4,0(a5)
    8000564e:	9736                	add	a4,a4,a3
    80005650:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005654:	6398                	ld	a4,0(a5)
    80005656:	9736                	add	a4,a4,a3
    80005658:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000565c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005660:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005664:	97aa                	add	a5,a5,a0
    80005666:	4705                	li	a4,1
    80005668:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000566c:	0001e517          	auipc	a0,0x1e
    80005670:	21450513          	addi	a0,a0,532 # 80023880 <disk+0x18>
    80005674:	8c3fc0ef          	jal	80001f36 <wakeup>
}
    80005678:	60a2                	ld	ra,8(sp)
    8000567a:	6402                	ld	s0,0(sp)
    8000567c:	0141                	addi	sp,sp,16
    8000567e:	8082                	ret
    panic("free_desc 1");
    80005680:	00002517          	auipc	a0,0x2
    80005684:	fb050513          	addi	a0,a0,-80 # 80007630 <etext+0x630>
    80005688:	958fb0ef          	jal	800007e0 <panic>
    panic("free_desc 2");
    8000568c:	00002517          	auipc	a0,0x2
    80005690:	fb450513          	addi	a0,a0,-76 # 80007640 <etext+0x640>
    80005694:	94cfb0ef          	jal	800007e0 <panic>

0000000080005698 <virtio_disk_init>:
{
    80005698:	1101                	addi	sp,sp,-32
    8000569a:	ec06                	sd	ra,24(sp)
    8000569c:	e822                	sd	s0,16(sp)
    8000569e:	e426                	sd	s1,8(sp)
    800056a0:	e04a                	sd	s2,0(sp)
    800056a2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800056a4:	00002597          	auipc	a1,0x2
    800056a8:	fac58593          	addi	a1,a1,-84 # 80007650 <etext+0x650>
    800056ac:	0001e517          	auipc	a0,0x1e
    800056b0:	2e450513          	addi	a0,a0,740 # 80023990 <disk+0x128>
    800056b4:	c9afb0ef          	jal	80000b4e <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800056b8:	100017b7          	lui	a5,0x10001
    800056bc:	4398                	lw	a4,0(a5)
    800056be:	2701                	sext.w	a4,a4
    800056c0:	747277b7          	lui	a5,0x74727
    800056c4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800056c8:	18f71063          	bne	a4,a5,80005848 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800056cc:	100017b7          	lui	a5,0x10001
    800056d0:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    800056d2:	439c                	lw	a5,0(a5)
    800056d4:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800056d6:	4709                	li	a4,2
    800056d8:	16e79863          	bne	a5,a4,80005848 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800056dc:	100017b7          	lui	a5,0x10001
    800056e0:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    800056e2:	439c                	lw	a5,0(a5)
    800056e4:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800056e6:	16e79163          	bne	a5,a4,80005848 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800056ea:	100017b7          	lui	a5,0x10001
    800056ee:	47d8                	lw	a4,12(a5)
    800056f0:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800056f2:	554d47b7          	lui	a5,0x554d4
    800056f6:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800056fa:	14f71763          	bne	a4,a5,80005848 <virtio_disk_init+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    800056fe:	100017b7          	lui	a5,0x10001
    80005702:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005706:	4705                	li	a4,1
    80005708:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000570a:	470d                	li	a4,3
    8000570c:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000570e:	10001737          	lui	a4,0x10001
    80005712:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005714:	c7ffe737          	lui	a4,0xc7ffe
    80005718:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fdadb7>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    8000571c:	8ef9                	and	a3,a3,a4
    8000571e:	10001737          	lui	a4,0x10001
    80005722:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005724:	472d                	li	a4,11
    80005726:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005728:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    8000572c:	439c                	lw	a5,0(a5)
    8000572e:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005732:	8ba1                	andi	a5,a5,8
    80005734:	12078063          	beqz	a5,80005854 <virtio_disk_init+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005738:	100017b7          	lui	a5,0x10001
    8000573c:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005740:	100017b7          	lui	a5,0x10001
    80005744:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005748:	439c                	lw	a5,0(a5)
    8000574a:	2781                	sext.w	a5,a5
    8000574c:	10079a63          	bnez	a5,80005860 <virtio_disk_init+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005750:	100017b7          	lui	a5,0x10001
    80005754:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    80005758:	439c                	lw	a5,0(a5)
    8000575a:	2781                	sext.w	a5,a5
  if(max == 0)
    8000575c:	10078863          	beqz	a5,8000586c <virtio_disk_init+0x1d4>
  if(max < NUM)
    80005760:	471d                	li	a4,7
    80005762:	10f77b63          	bgeu	a4,a5,80005878 <virtio_disk_init+0x1e0>
  disk.desc = kalloc();
    80005766:	b98fb0ef          	jal	80000afe <kalloc>
    8000576a:	0001e497          	auipc	s1,0x1e
    8000576e:	0fe48493          	addi	s1,s1,254 # 80023868 <disk>
    80005772:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005774:	b8afb0ef          	jal	80000afe <kalloc>
    80005778:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000577a:	b84fb0ef          	jal	80000afe <kalloc>
    8000577e:	87aa                	mv	a5,a0
    80005780:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005782:	6088                	ld	a0,0(s1)
    80005784:	10050063          	beqz	a0,80005884 <virtio_disk_init+0x1ec>
    80005788:	0001e717          	auipc	a4,0x1e
    8000578c:	0e873703          	ld	a4,232(a4) # 80023870 <disk+0x8>
    80005790:	0e070a63          	beqz	a4,80005884 <virtio_disk_init+0x1ec>
    80005794:	0e078863          	beqz	a5,80005884 <virtio_disk_init+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    80005798:	6605                	lui	a2,0x1
    8000579a:	4581                	li	a1,0
    8000579c:	d06fb0ef          	jal	80000ca2 <memset>
  memset(disk.avail, 0, PGSIZE);
    800057a0:	0001e497          	auipc	s1,0x1e
    800057a4:	0c848493          	addi	s1,s1,200 # 80023868 <disk>
    800057a8:	6605                	lui	a2,0x1
    800057aa:	4581                	li	a1,0
    800057ac:	6488                	ld	a0,8(s1)
    800057ae:	cf4fb0ef          	jal	80000ca2 <memset>
  memset(disk.used, 0, PGSIZE);
    800057b2:	6605                	lui	a2,0x1
    800057b4:	4581                	li	a1,0
    800057b6:	6888                	ld	a0,16(s1)
    800057b8:	ceafb0ef          	jal	80000ca2 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800057bc:	100017b7          	lui	a5,0x10001
    800057c0:	4721                	li	a4,8
    800057c2:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800057c4:	4098                	lw	a4,0(s1)
    800057c6:	100017b7          	lui	a5,0x10001
    800057ca:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800057ce:	40d8                	lw	a4,4(s1)
    800057d0:	100017b7          	lui	a5,0x10001
    800057d4:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800057d8:	649c                	ld	a5,8(s1)
    800057da:	0007869b          	sext.w	a3,a5
    800057de:	10001737          	lui	a4,0x10001
    800057e2:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800057e6:	9781                	srai	a5,a5,0x20
    800057e8:	10001737          	lui	a4,0x10001
    800057ec:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800057f0:	689c                	ld	a5,16(s1)
    800057f2:	0007869b          	sext.w	a3,a5
    800057f6:	10001737          	lui	a4,0x10001
    800057fa:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800057fe:	9781                	srai	a5,a5,0x20
    80005800:	10001737          	lui	a4,0x10001
    80005804:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005808:	10001737          	lui	a4,0x10001
    8000580c:	4785                	li	a5,1
    8000580e:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005810:	00f48c23          	sb	a5,24(s1)
    80005814:	00f48ca3          	sb	a5,25(s1)
    80005818:	00f48d23          	sb	a5,26(s1)
    8000581c:	00f48da3          	sb	a5,27(s1)
    80005820:	00f48e23          	sb	a5,28(s1)
    80005824:	00f48ea3          	sb	a5,29(s1)
    80005828:	00f48f23          	sb	a5,30(s1)
    8000582c:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005830:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005834:	100017b7          	lui	a5,0x10001
    80005838:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    8000583c:	60e2                	ld	ra,24(sp)
    8000583e:	6442                	ld	s0,16(sp)
    80005840:	64a2                	ld	s1,8(sp)
    80005842:	6902                	ld	s2,0(sp)
    80005844:	6105                	addi	sp,sp,32
    80005846:	8082                	ret
    panic("could not find virtio disk");
    80005848:	00002517          	auipc	a0,0x2
    8000584c:	e1850513          	addi	a0,a0,-488 # 80007660 <etext+0x660>
    80005850:	f91fa0ef          	jal	800007e0 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005854:	00002517          	auipc	a0,0x2
    80005858:	e2c50513          	addi	a0,a0,-468 # 80007680 <etext+0x680>
    8000585c:	f85fa0ef          	jal	800007e0 <panic>
    panic("virtio disk should not be ready");
    80005860:	00002517          	auipc	a0,0x2
    80005864:	e4050513          	addi	a0,a0,-448 # 800076a0 <etext+0x6a0>
    80005868:	f79fa0ef          	jal	800007e0 <panic>
    panic("virtio disk has no queue 0");
    8000586c:	00002517          	auipc	a0,0x2
    80005870:	e5450513          	addi	a0,a0,-428 # 800076c0 <etext+0x6c0>
    80005874:	f6dfa0ef          	jal	800007e0 <panic>
    panic("virtio disk max queue too short");
    80005878:	00002517          	auipc	a0,0x2
    8000587c:	e6850513          	addi	a0,a0,-408 # 800076e0 <etext+0x6e0>
    80005880:	f61fa0ef          	jal	800007e0 <panic>
    panic("virtio disk kalloc");
    80005884:	00002517          	auipc	a0,0x2
    80005888:	e7c50513          	addi	a0,a0,-388 # 80007700 <etext+0x700>
    8000588c:	f55fa0ef          	jal	800007e0 <panic>

0000000080005890 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005890:	7159                	addi	sp,sp,-112
    80005892:	f486                	sd	ra,104(sp)
    80005894:	f0a2                	sd	s0,96(sp)
    80005896:	eca6                	sd	s1,88(sp)
    80005898:	e8ca                	sd	s2,80(sp)
    8000589a:	e4ce                	sd	s3,72(sp)
    8000589c:	e0d2                	sd	s4,64(sp)
    8000589e:	fc56                	sd	s5,56(sp)
    800058a0:	f85a                	sd	s6,48(sp)
    800058a2:	f45e                	sd	s7,40(sp)
    800058a4:	f062                	sd	s8,32(sp)
    800058a6:	ec66                	sd	s9,24(sp)
    800058a8:	1880                	addi	s0,sp,112
    800058aa:	8a2a                	mv	s4,a0
    800058ac:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800058ae:	00c52c83          	lw	s9,12(a0)
    800058b2:	001c9c9b          	slliw	s9,s9,0x1
    800058b6:	1c82                	slli	s9,s9,0x20
    800058b8:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    800058bc:	0001e517          	auipc	a0,0x1e
    800058c0:	0d450513          	addi	a0,a0,212 # 80023990 <disk+0x128>
    800058c4:	b0afb0ef          	jal	80000bce <acquire>
  for(int i = 0; i < 3; i++){
    800058c8:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    800058ca:	44a1                	li	s1,8
      disk.free[i] = 0;
    800058cc:	0001eb17          	auipc	s6,0x1e
    800058d0:	f9cb0b13          	addi	s6,s6,-100 # 80023868 <disk>
  for(int i = 0; i < 3; i++){
    800058d4:	4a8d                	li	s5,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800058d6:	0001ec17          	auipc	s8,0x1e
    800058da:	0bac0c13          	addi	s8,s8,186 # 80023990 <disk+0x128>
    800058de:	a8b9                	j	8000593c <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    800058e0:	00fb0733          	add	a4,s6,a5
    800058e4:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    800058e8:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    800058ea:	0207c563          	bltz	a5,80005914 <virtio_disk_rw+0x84>
  for(int i = 0; i < 3; i++){
    800058ee:	2905                	addiw	s2,s2,1
    800058f0:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800058f2:	05590963          	beq	s2,s5,80005944 <virtio_disk_rw+0xb4>
    idx[i] = alloc_desc();
    800058f6:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    800058f8:	0001e717          	auipc	a4,0x1e
    800058fc:	f7070713          	addi	a4,a4,-144 # 80023868 <disk>
    80005900:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80005902:	01874683          	lbu	a3,24(a4)
    80005906:	fee9                	bnez	a3,800058e0 <virtio_disk_rw+0x50>
  for(int i = 0; i < NUM; i++){
    80005908:	2785                	addiw	a5,a5,1
    8000590a:	0705                	addi	a4,a4,1
    8000590c:	fe979be3          	bne	a5,s1,80005902 <virtio_disk_rw+0x72>
    idx[i] = alloc_desc();
    80005910:	57fd                	li	a5,-1
    80005912:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80005914:	01205d63          	blez	s2,8000592e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005918:	f9042503          	lw	a0,-112(s0)
    8000591c:	d07ff0ef          	jal	80005622 <free_desc>
      for(int j = 0; j < i; j++)
    80005920:	4785                	li	a5,1
    80005922:	0127d663          	bge	a5,s2,8000592e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005926:	f9442503          	lw	a0,-108(s0)
    8000592a:	cf9ff0ef          	jal	80005622 <free_desc>
    sleep(&disk.free[0], &disk.vdisk_lock);
    8000592e:	85e2                	mv	a1,s8
    80005930:	0001e517          	auipc	a0,0x1e
    80005934:	f5050513          	addi	a0,a0,-176 # 80023880 <disk+0x18>
    80005938:	db2fc0ef          	jal	80001eea <sleep>
  for(int i = 0; i < 3; i++){
    8000593c:	f9040613          	addi	a2,s0,-112
    80005940:	894e                	mv	s2,s3
    80005942:	bf55                	j	800058f6 <virtio_disk_rw+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005944:	f9042503          	lw	a0,-112(s0)
    80005948:	00451693          	slli	a3,a0,0x4

  if(write)
    8000594c:	0001e797          	auipc	a5,0x1e
    80005950:	f1c78793          	addi	a5,a5,-228 # 80023868 <disk>
    80005954:	00a50713          	addi	a4,a0,10
    80005958:	0712                	slli	a4,a4,0x4
    8000595a:	973e                	add	a4,a4,a5
    8000595c:	01703633          	snez	a2,s7
    80005960:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005962:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005966:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    8000596a:	6398                	ld	a4,0(a5)
    8000596c:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000596e:	0a868613          	addi	a2,a3,168
    80005972:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005974:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005976:	6390                	ld	a2,0(a5)
    80005978:	00d605b3          	add	a1,a2,a3
    8000597c:	4741                	li	a4,16
    8000597e:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005980:	4805                	li	a6,1
    80005982:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005986:	f9442703          	lw	a4,-108(s0)
    8000598a:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    8000598e:	0712                	slli	a4,a4,0x4
    80005990:	963a                	add	a2,a2,a4
    80005992:	058a0593          	addi	a1,s4,88
    80005996:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005998:	0007b883          	ld	a7,0(a5)
    8000599c:	9746                	add	a4,a4,a7
    8000599e:	40000613          	li	a2,1024
    800059a2:	c710                	sw	a2,8(a4)
  if(write)
    800059a4:	001bb613          	seqz	a2,s7
    800059a8:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800059ac:	00166613          	ori	a2,a2,1
    800059b0:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    800059b4:	f9842583          	lw	a1,-104(s0)
    800059b8:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    800059bc:	00250613          	addi	a2,a0,2
    800059c0:	0612                	slli	a2,a2,0x4
    800059c2:	963e                	add	a2,a2,a5
    800059c4:	577d                	li	a4,-1
    800059c6:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    800059ca:	0592                	slli	a1,a1,0x4
    800059cc:	98ae                	add	a7,a7,a1
    800059ce:	03068713          	addi	a4,a3,48
    800059d2:	973e                	add	a4,a4,a5
    800059d4:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    800059d8:	6398                	ld	a4,0(a5)
    800059da:	972e                	add	a4,a4,a1
    800059dc:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    800059e0:	4689                	li	a3,2
    800059e2:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    800059e6:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    800059ea:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    800059ee:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    800059f2:	6794                	ld	a3,8(a5)
    800059f4:	0026d703          	lhu	a4,2(a3)
    800059f8:	8b1d                	andi	a4,a4,7
    800059fa:	0706                	slli	a4,a4,0x1
    800059fc:	96ba                	add	a3,a3,a4
    800059fe:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005a02:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005a06:	6798                	ld	a4,8(a5)
    80005a08:	00275783          	lhu	a5,2(a4)
    80005a0c:	2785                	addiw	a5,a5,1
    80005a0e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005a12:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005a16:	100017b7          	lui	a5,0x10001
    80005a1a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80005a1e:	004a2783          	lw	a5,4(s4)
    sleep(b, &disk.vdisk_lock);
    80005a22:	0001e917          	auipc	s2,0x1e
    80005a26:	f6e90913          	addi	s2,s2,-146 # 80023990 <disk+0x128>
  while(b->disk == 1) {
    80005a2a:	4485                	li	s1,1
    80005a2c:	01079a63          	bne	a5,a6,80005a40 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005a30:	85ca                	mv	a1,s2
    80005a32:	8552                	mv	a0,s4
    80005a34:	cb6fc0ef          	jal	80001eea <sleep>
  while(b->disk == 1) {
    80005a38:	004a2783          	lw	a5,4(s4)
    80005a3c:	fe978ae3          	beq	a5,s1,80005a30 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005a40:	f9042903          	lw	s2,-112(s0)
    80005a44:	00290713          	addi	a4,s2,2
    80005a48:	0712                	slli	a4,a4,0x4
    80005a4a:	0001e797          	auipc	a5,0x1e
    80005a4e:	e1e78793          	addi	a5,a5,-482 # 80023868 <disk>
    80005a52:	97ba                	add	a5,a5,a4
    80005a54:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005a58:	0001e997          	auipc	s3,0x1e
    80005a5c:	e1098993          	addi	s3,s3,-496 # 80023868 <disk>
    80005a60:	00491713          	slli	a4,s2,0x4
    80005a64:	0009b783          	ld	a5,0(s3)
    80005a68:	97ba                	add	a5,a5,a4
    80005a6a:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005a6e:	854a                	mv	a0,s2
    80005a70:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005a74:	bafff0ef          	jal	80005622 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005a78:	8885                	andi	s1,s1,1
    80005a7a:	f0fd                	bnez	s1,80005a60 <virtio_disk_rw+0x1d0>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005a7c:	0001e517          	auipc	a0,0x1e
    80005a80:	f1450513          	addi	a0,a0,-236 # 80023990 <disk+0x128>
    80005a84:	9e2fb0ef          	jal	80000c66 <release>
}
    80005a88:	70a6                	ld	ra,104(sp)
    80005a8a:	7406                	ld	s0,96(sp)
    80005a8c:	64e6                	ld	s1,88(sp)
    80005a8e:	6946                	ld	s2,80(sp)
    80005a90:	69a6                	ld	s3,72(sp)
    80005a92:	6a06                	ld	s4,64(sp)
    80005a94:	7ae2                	ld	s5,56(sp)
    80005a96:	7b42                	ld	s6,48(sp)
    80005a98:	7ba2                	ld	s7,40(sp)
    80005a9a:	7c02                	ld	s8,32(sp)
    80005a9c:	6ce2                	ld	s9,24(sp)
    80005a9e:	6165                	addi	sp,sp,112
    80005aa0:	8082                	ret

0000000080005aa2 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005aa2:	1101                	addi	sp,sp,-32
    80005aa4:	ec06                	sd	ra,24(sp)
    80005aa6:	e822                	sd	s0,16(sp)
    80005aa8:	e426                	sd	s1,8(sp)
    80005aaa:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005aac:	0001e497          	auipc	s1,0x1e
    80005ab0:	dbc48493          	addi	s1,s1,-580 # 80023868 <disk>
    80005ab4:	0001e517          	auipc	a0,0x1e
    80005ab8:	edc50513          	addi	a0,a0,-292 # 80023990 <disk+0x128>
    80005abc:	912fb0ef          	jal	80000bce <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005ac0:	100017b7          	lui	a5,0x10001
    80005ac4:	53b8                	lw	a4,96(a5)
    80005ac6:	8b0d                	andi	a4,a4,3
    80005ac8:	100017b7          	lui	a5,0x10001
    80005acc:	d3f8                	sw	a4,100(a5)

  __sync_synchronize();
    80005ace:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005ad2:	689c                	ld	a5,16(s1)
    80005ad4:	0204d703          	lhu	a4,32(s1)
    80005ad8:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005adc:	04f70663          	beq	a4,a5,80005b28 <virtio_disk_intr+0x86>
    __sync_synchronize();
    80005ae0:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005ae4:	6898                	ld	a4,16(s1)
    80005ae6:	0204d783          	lhu	a5,32(s1)
    80005aea:	8b9d                	andi	a5,a5,7
    80005aec:	078e                	slli	a5,a5,0x3
    80005aee:	97ba                	add	a5,a5,a4
    80005af0:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005af2:	00278713          	addi	a4,a5,2
    80005af6:	0712                	slli	a4,a4,0x4
    80005af8:	9726                	add	a4,a4,s1
    80005afa:	01074703          	lbu	a4,16(a4)
    80005afe:	e321                	bnez	a4,80005b3e <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005b00:	0789                	addi	a5,a5,2
    80005b02:	0792                	slli	a5,a5,0x4
    80005b04:	97a6                	add	a5,a5,s1
    80005b06:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005b08:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005b0c:	c2afc0ef          	jal	80001f36 <wakeup>

    disk.used_idx += 1;
    80005b10:	0204d783          	lhu	a5,32(s1)
    80005b14:	2785                	addiw	a5,a5,1
    80005b16:	17c2                	slli	a5,a5,0x30
    80005b18:	93c1                	srli	a5,a5,0x30
    80005b1a:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005b1e:	6898                	ld	a4,16(s1)
    80005b20:	00275703          	lhu	a4,2(a4)
    80005b24:	faf71ee3          	bne	a4,a5,80005ae0 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005b28:	0001e517          	auipc	a0,0x1e
    80005b2c:	e6850513          	addi	a0,a0,-408 # 80023990 <disk+0x128>
    80005b30:	936fb0ef          	jal	80000c66 <release>
}
    80005b34:	60e2                	ld	ra,24(sp)
    80005b36:	6442                	ld	s0,16(sp)
    80005b38:	64a2                	ld	s1,8(sp)
    80005b3a:	6105                	addi	sp,sp,32
    80005b3c:	8082                	ret
      panic("virtio_disk_intr status");
    80005b3e:	00002517          	auipc	a0,0x2
    80005b42:	bda50513          	addi	a0,a0,-1062 # 80007718 <etext+0x718>
    80005b46:	c9bfa0ef          	jal	800007e0 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
